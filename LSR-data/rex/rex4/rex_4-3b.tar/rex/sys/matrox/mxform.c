#include "../../hdr/matrox.h"

/* MXFORM -- set up margin and top of form */
void
mxform(int mar, int itop)
{
	mxmrgn = mar;
	mxoldx = mar;
	mxtopf = itop;
	mxoldy = itop;
}
