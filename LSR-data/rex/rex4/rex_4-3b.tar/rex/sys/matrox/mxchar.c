/*
 * MXCHAR
 *	'C' language version of S.G. Lisberger's assembly language
 * character writer for matrox.
 *
 * REVISION HISTORY
 *
 * Jan 8, 87	LMO	Convert to 'C' under 4.2BSD on VAX
 */

#include "../../hdr/matrox.h"

#define dot_(a, b)	mxfast((a), (b), mxcolor)

/*
 *	Character patterns
 *
 *	the following is the list of 95
 *	characters decoded by 'dchar'.
 *
 *
 *
 *	the following are the 5 x 8 patterns for the ascii
 *	characters encoded from 1 to "177. codes 1 to "37
 *	are set to blanks and may be redefined
 *	dynamically. codes "11 to "22 are interpreted
 *	as control characters by mxtext().
 *	a single zero byte is non-printing and non-spacing
 *	two consecutive bytes of zero constitute an 'end of string'
 *
 *	other codes include:
 *
 *	"16 decimal conversion code (next full word converted to string)
 *	"17 octal       "       "
 *	"20 floating    "       "
 *	"21 set left margin
 *	"22 set top of page
 *	"23 set character size
 *	"24 set field width
 *	"25 set field justification
 *	"26 set leading character(zero or blank)
 *
 *
 *	the 5 x 8 patterns only use the topmost 7 positions
 *	for most characters. the bottom row is used only for
 *	comma,semicolon and some lower case characters.
 */

static int mxpatt[] = {
  00, 00, 00, 00, 00, 00
, 00, 00, 00, 00, 00, 00
, 00, 00, 00, 00, 00, 00
, 00, 00, 00, 00, 00, 00
, 00, 00, 00, 00, 00, 00
, 00, 00, 00, 00, 00, 00
, 00, 00, 00, 00, 00, 00
, 00, 00, 00, 00, 00, 00
, 00, 00, 00, 00, 00, 00
, 00, 00, 00, 00, 00, 00
, 00, 00, 00, 00, 00, 00
, 00, 00, 00, 00, 00, 00
, 00, 00, 00, 00, 00, 00
, 00, 00, 00, 0372, 00, 0340
, 0340, 0177050, 0177050, 022050, 0177124, 044124
, 0144306, 023020, 066306, 065222, 05004, 00
, 0340, 00, 042070, 0202, 0101000, 034104
, 042000, 0177050, 042050, 010020, 010174, 020
, 03001, 00, 010020, 010020, 020, 01000
, 00, 04006, 020020, 076300, 0111212, 076242
, 041000, 01376, 043000, 0111212, 061222, 0101204
, 0131222, 014314, 044050, 04376, 0121344, 0121242
, 036234, 0111122, 06222, 0107200, 0120220, 066300
, 0111222, 066222, 0111140, 0112222, 0170, 024000
, 00, 0400, 046, 010000, 042050, 0202
, 024000, 024050, 00, 042202, 010050, 0100100
, 0120232, 076100, 0135202, 075252, 044076, 044210
, 0177076, 0111222, 066222, 0101174, 0101202, 0177104
, 0101202, 076202, 0111376, 0111222, 0177202, 0110220
, 0100220, 0101174, 0111202, 0177234, 010020, 0177020
, 0101000, 0101376, 02000, 01002, 0176002, 010376
, 042050, 0177202, 01002, 01002, 040376, 040060
, 0177376, 010140, 0177014, 0101174, 0101202, 0177174
, 0110220, 060220, 0101174, 0102212, 0177172, 0114220
, 061224, 0111144, 0111222, 0100114, 0177200, 0100200
, 01374, 01002, 0170374, 01014, 0170014, 02376
, 02030, 0143376, 010050, 0143050, 020300, 020036
, 0103300, 0111212, 0141242, 0177000, 0101376, 0140202
, 010040, 03010, 0101202, 0177376, 010000, 040040
, 010040, 0401, 0401, 01, 040200, 040
, 025004, 017052, 01002, 011376, 06022, 021034
, 021042, 06042, 011022, 01376, 025034, 025052
, 030, 077010, 040210, 022430, 022445, 0177036
, 010020, 07020, 01000, 01136, 00, 0402
, 0276, 02376, 012010, 042, 0177202, 02
, 020076, 020036, 037036, 020020, 017040, 021034
, 021042, 037434, 022044, 014044, 022030, 037444
, 037001, 010010, 020040, 025022, 025052, 044
, 0176040, 042, 01074, 02002, 030076, 01014
, 030014, 01074, 01014, 021076, 04024, 021024
, 02070, 04405, 021076, 025046, 021062, 010000
, 0101154, 00, 0167000, 00, 0101000, 010154
, 010000, 020040, 040040, 0177777, 0177777, 0377
};

static char bits[] = {
	  01
	, 02
	, 04
	, 010
	, 020
	, 040
	, 0100
	, 0200
};

void
mxchar(char c)
{
	char next, *pbits;
	int row;
	char *patt;
	int col;

	c &= 0377;
	if (c == 040) {
		mxoldx += mxcrwd + mxcrsp;
		goto l60;
	}

	patt = (char *) mxpatt;
	patt += 5 * (--c);

	if (mxangl == 0) for (col = 0; col < 5; col++) { /* horizontal */
		mxnewx(mxoldx);	/* set horizontal coordinate */
		if (next = *patt++) {
			pbits = bits;
			for (row = 0; row < 8; row++) {
				if (next & *pbits++) mxonlyy(mxoldy);
				mxoldy += mxcsiz;
			}
			if ((mxoldy -= mxcrht + mxcsiz) < 0) mxoldy = mxtopf;
		}
		mxoldx += mxcsiz;
	}
	else for (col = 0; col < 5; col++) { /* vertical */
		mxnewy(mxoldx);	/* set vertical coordinate */
		if (next = *patt++) {
			pbits = bits;
			for (row = 0; row < 8; row++) {
				if (next & *pbits++) mxonlyx(511 - mxoldy);
				mxoldy += mxcsiz;
			}
			if ((mxoldy -= mxcrht + mxcsiz) < 0) mxoldy = mxtopf;
		}
		mxoldx += mxcsiz;
	}
	mxoldx += mxcrsp - mxcsiz;
l60:
	if ((mxoldx + mxcrwd) > 512) {
		mxoldx = mxmrgn;
		if ((mxoldy -= mxlnsp + mxcrht) < 0) mxoldy = mxtopf;
	}
}

void
mxsize(int fac) 
{
	mxcsiz = fac;
	mxcrwd = 4 * fac;
	mxcrht = 7 * fac;
	mxcrsp = 2 * fac;
	mxlnsp = 2 * fac;
}
