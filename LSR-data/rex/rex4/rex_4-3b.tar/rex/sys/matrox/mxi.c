
/* DATA DEFINITIONS ----------------------------------------------------- */
/*
 * June 16, 1980
 *
 * Unified globals for NIH distribution of matrox functions
 *	L. M. Optican and S. G. Lisberger
 */

#include "../../hdr/matrox.h"

/* global variables for matrox subroutines */
int mxcolor= MXBRT;	/* color drawn, initialize to on */
int mxback= MXDRK;	/* color of background, initialize to off */
int lastx= 0;
int lasty= 0;

/* save locations for last point of vector generator
 * set with mxmove(x,y) or mxvect(x,y), returned by mxwhere(&x,&y);
 * also set by mxtext()
 */
int mxoldx= 0;
int mxoldy= 0;
int mxwrap= 0;		/* if true, wrap display */

/* globals for text generator */
int mxcsiz= 1;	/* character size */
int mxcrwd= 4;	/* character width */
int mxcrht= 7;	/* character height */
int mxcrsp= 2;	/* character spacing */
int mxlnsp= 2;	/* line spacing */
int mxmrgn= 0; 	/* left margin */
int mxtopf= 496;	/* top of form */
int mxline= 0;	/* scroll line at top of page */
int mxangl= 0;	/* horizontal/vertical - 1 means vertical */

