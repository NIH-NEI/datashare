#include "../../hdr/matrox.h"

void
mxwhere(int *px, int *py)
{
	/* return current matrox position */
	extern int mxoldx, mxoldy;

	*px = mxoldx;
	*py = mxoldy;
}
