#include "../../hdr/matrox.h"
#include <stdlib.h>

/* definitions of moves */
#define m1	x++; delta += (x << 1) + 1;
#define m2	x++; y--; delta += (x - y + 1) << 1;
#define m3	y--; delta -= (y << 1) -1;

void
mxcircle(int xoff,int yoff,int radius)
{
	int x, y, delta;

	/* initialize */
	radius = abs(radius);
	x = 0;
	y = radius;
	delta = 1, delta -= radius, delta <<= 1;

	/* loop for one quadrant, reflect about x and y axes
	 * to give four-fold symmetry
	 */

	do {
		/* output */
		mxfast(xoff + x, yoff + y, mxcolor);
		mxfast(xoff + x, yoff - y, mxcolor);
		mxfast(xoff - x, yoff - y, mxcolor);
		mxfast(xoff - x, yoff + y, mxcolor);

		/* check for point in interior */
		if (delta <= 0) {
			if (((delta + y) << 1) <= 0) { m1 }
			else { m2 }
		}
		else {
			if ((((delta - x) << 1) - 1) <= 0) { m2 }
			else { m3 }
		}
	} while(y >= 0);
}
