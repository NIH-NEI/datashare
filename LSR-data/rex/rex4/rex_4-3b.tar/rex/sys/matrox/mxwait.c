#include "../../hdr/matrox.h"

void
mxwait(void)
{
}
