#include "../../hdr/matrox.h"
#include <stdlib.h>

#define change swap(x1,mxoldx,error); swap(y1,mxoldy,error)

/* draws vector from oldx, oldy, to x1,y1 in a highly optimized fashion.
 * NOTE:  NO RANGE TESTS ARE MADE, USER MUST SCALE TO BE WITHIN [0,511].
 */

void
mxvect(int x1, int y1)
{
	int error;
	int dx, dy, inc;
	int savex, savey;

	/* save x1 and y1 */
	savex = x1;
	savey = y1;

	/* is it a single dot ? */

	if ((x1 == mxoldx) && (y1 == mxoldy)) {
		mxfast(x1,y1,mxcolor);
		return;
	}

	/* is it a vertical line ? */
	if (x1 == mxoldx) {
		if (mxoldy < y1) {
			error = y1;
			y1 = mxoldy;
		} 
		else error = mxoldy;
		mxnewx(x1);
		while (y1 < error) mxonlyy(y1++);
	}

	/* is it a horizontal line ? */

	else if (y1 == mxoldy) {
		if (mxoldx < x1) {
			error = x1;
			x1 = mxoldx;
		} 
		else error = mxoldx;
		mxnewy(y1);
		while (x1 < error) mxonlyx(x1++);
	}

	/* is it a line with abs(slope) <= 1 ? */
	else if (abs(mxoldx-x1) >= abs(mxoldy-y1)) {
		if (x1 > mxoldx) { change; }
		dx = mxoldx - x1;
		dy = mxoldy - y1;
		inc = sgn(dy);
		dy = abs(dy);
		/* get error */
		error = dx / 2;
		/* do first dot */
		mxfast(x1,y1,mxcolor);
		while (x1 < mxoldx) {
			error += dy;
			if (error >= dx) {
				error -= dx;
				y1 += inc;
				mxnewy(y1);
			}
			mxonlyx(++x1);
		}
	}

	/* this is a line with abs(slope) > 1 */
	else if (y1 > mxoldy) { change; }
	dx = mxoldx - x1;
	dy = mxoldy - y1;
	inc = sgn(dx);
	dx = abs(dx);
		/* get error */
		error = dy / 2;
		/* do first dot */
		mxfast(x1,y1,mxcolor);
		while (y1 < mxoldy) {
			error += dx;
			if (error >= dy) {
				error -= dy;
				x1 += inc;
				mxnewx(x1);
			}
			mxonlyy(++y1);
		}

	/* reset old values */
	mxoldx = savex;
	mxoldy = savey;
}
