/* math.h -- header for math library functions
 *
 * copyright 1979 by Lance M. Optican
 *
 *	NOTE:  This file contains constants which are use to compute
 *		the values of the math functions.  If any errors are
 *		detected, please contact:
 *			L. M. Optican
 *			Laboratory of Sensorimotor Research
 *			Building 36, Room 1-D-15
 *			National Eye Institute
 *			National Institutes of Health
 *			Bethesda, Maryland 21205
 */

/* PDP-11 MACHINE-DEPENDENT DEFINITIONS:
 *	the format for double precision variables, and a
 *	macro to retrieve the exponent of a double precision number.
 *	macros are also provided to set the exponent to zero, or to an arbitrary
 *	value
 */
struct dformat {
	int d1, d2, d3, d4;
};
#define expon(z)	(((z.d1 & ~(01 << 15)) >> 7) - 0200)
#define exponoff(z)	(z.d1 &= ~(0377 << 7), z.d1 |= 0200 << 7)
#define exponto(z,e)	(z.d1 &= ~(0377 << 7), z.d1 |= (((e) + 0200) << 7))

/* macro to return if odd or even */
#define iseven(x)	(((x) & 01) == 0)
#define isodd(x)	((x) & 01)

/* macro for rounding numbers */
#define round(z)	( (int)( (z) < 0 ? (z) - .5 : (z) + .5 ) )

/* square function */
#define sqr(z)	((z) * (z))

/* macro for sign function (signum(x)) */
#define sgn(x)	(((x) < 0) ? (-1) : (+1))

#define MAXINT	32767

/* SQRT -- definitions for the sqrt function:
 *	coefficients for fourth order polynomial approximation to
 *	sqrt(x) on the interval [.5, 1]
 */
#define SQP00	0.22906994529
#define SQP01	1.3006690496
#define SQP02	-0.90932104982
#define SQP03	0.50104207633
#define SQP04	-0.12146838249

/* the approximation to sqrt of x */
#define sqapprox(z)	(SQP00 + (SQP01 + (SQP02 + (SQP03 + SQP04*(z)) \
			* (z)) * (z)) * (z))

/* the precision criterion */
#define SQERROR 1.0E-16



/* definitions for logarithm */
#define LNTERMS	23

/* definitions for exponential */
#define NTEXP	18
#define MAXEXP	88.02969193
#define MAXNUM	1.70141183e+38
#define MINNUM	5.87747175e-39


/* definitions for sine */
#define NTSINE	6

/* definitions for cosine */
#define NTCOS	7


/* definitions for tangent */
#define TANNUM	31

/* definitions for arctangent */
#define NTATAN	21

/* high precision constants */
#define LN2	0.69314718055994530941
#define LN10	2.30258509299404568401
#define LOG10E	0.43429448190325182765
#define EULER	2.71828182845904523536
#define SQRT2	1.41421356237309504880
#define HALFSQRT2	.70710678118654752440
#define PI	3.14159265358979323846
#define HALFPI	1.57079632679489661923
#define TWOPI	6.28318530717958647692
#define BIGPI	(32766*PI)	/* must be an even multiple of PI */
#define RADPDEG	0.01745329251994329576

