#ifdef GOO
#ifdef NEED_FAR
    u_char far *p;
#else
    u_char *p;
#endif
    long i;

    p= fb_p;
    for(i= 0; i < FBSIZE; i++, p++) {
	*p= 0377;
    }
