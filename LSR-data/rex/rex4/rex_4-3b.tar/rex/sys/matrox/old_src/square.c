#
/* plot.c:	Matrox test program.
 *
 *	AVH; Mar 80
 */

struct mat {
	int com;
	int xreg;
	int yreg;
	int sf;
} ;

/* Matrox address in 64 byte clicks */
#define MAT 07740

main(argc, argv)
char *argv[];
{
	register int  i, matcom;
	register int *p;

	/* Declare end() so that loader will define it.
	 */
	extern end();

	/* Get address of last used location of program.
	 * Round it up to 4k multiple to get first unused
	 * page register.
	 * Note: must cast p as char * for arithmetic to be
	 * accurate; but need p as int * for accesses to
	 * matrox to work.
	 */
	p= &end;
	(char *)p= ((char *)p + 017777) & ~017777;
	if(p == 0160000) {
		printf("No free registers.\n");
		exit();
	}

	/* Now map that page to the physical address of the
	 * matrox; make the page lentgh the minimum of 64 bytes.
	 */
	if(phys((char *)p >> 13, 0, MAT) == -1) {
		printf("Error on phys mapping.\n");
		exit();
	}

	/* White on black, black on white? */
	if(argc == 1) matcom= 0541;
	else matcom= 0540;

	/* Now draw a simple square */
	for(i=200; i<300; i++) {
		p->yreg= i;
		p->xreg= 200 << 1;
		p->com= matcom;
		p->xreg= 300 << 1;
		p->com= matcom;
	}
	for(i=200; i<300; i++) {
		p->xreg= i << 1;
		p->yreg= 200;
		p->com= matcom;
		p->yreg= 300;
		p->com= matcom;
	}
}

