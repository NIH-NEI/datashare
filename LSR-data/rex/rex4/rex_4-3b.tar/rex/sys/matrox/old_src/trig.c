#include "lance.h"
#include <stdio.h>
#include <matrox.g>

#define SINOFF	25
#define ASIN	50
#define COSOFF	MXMAX - 5
#define ACOS	50
#define CXOFF	350
#define CYOFF	185
#define CXOFF2	150
#define CYOFF2	350
#define RADIUS	50
#define DELTA	1
#define CYCLE	1
#define NUMFIG 5
#define NUMFIG2 6
int foo[8000] 0;

struct point {
	double vec[2];
	int x[2], y[2];
} fig[] {   {  RADIUS,   RADIUS, 0, 0, 0, 0}
		, {- RADIUS,   RADIUS, 0, 0, 0, 0}
		, {- RADIUS, - RADIUS, 0, 0, 0, 0}
		, {  RADIUS, - RADIUS, 0, 0, 0, 0}
		, {  RADIUS,   RADIUS, 0, 0, 0, 0}
		};

struct point fig2[] { { RADIUS, 0, 0, 0, 0}
			, { - RADIUS, 0, 0, 0, 0}
			, {  0, 2 * RADIUS, 0, 0, 0, 0}
			, {  RADIUS, 0, 0, 0, 0, 0}
			, { 0, -2 * RADIUS, 0, 0, 0, 0}
			, { - RADIUS, 0, 0, 0, 0, 0}
		};

struct point *pfig fig, *pfigp &fig[1], *pfigm fig;

int new 1, old 0;
main()
{
	static double  omega, fac;
	double sin(), cos();
	static double c, s;
		static double sine[400], cosine[400];
	register int t, x, y;
	static int delta DELTA;
	static int cycle CYCLE;
	static int r RADIUS;
	int nfig;
		static int i;
		static double rot[2][2];
		static double newvec[2];

	/* map matrox */
	if (mxphys() == 0) {
		printf("Error\n");
		exit();
	}


	/* initialize scroll */
	mxscroll(0);
	mxerase;
	mxwait();

	/* clear screen */
	mxerase;
	mxwait();

	/* set factor for radians */
	fac = (double) cycle * TWOPI / MXMAX;

	/* set up table */

	for (t = 0, i = 0; t < 360; t += delta) {
		/* calculate omega */
		omega = fac * t;

		/* get sin(omega), cos(omega) */
		sine[i] = sin(omega);
		cosine[i++] = cos(omega);
	}


	for( ; ; ) {
		for (t = 0; t < i; t++) {
	
			/* get sin(omega), cos(omega) */
			s = sine[t];
			c = cosine[t];

			/* get rotation matrix */
			rot[0][0] = c;
			rot[1][1] = c;
			rot[0][1] = s;
			rot[1][0] = -s;

	
			/* rotate vectors */

			/* initialize first point */
			pfig = fig;
			vecmpy(pfig->vec,rot,newvec,2);
			pfig->x[new] = newvec[0] + CXOFF;
			pfig->y[new] = newvec[1] + CYOFF;

			for(nfig = 1; nfig < NUMFIG; nfig++) {
				pfigm = pfig++;
				vecmpy(pfig->vec,rot,newvec,2);

				/* get x, y */
				x = newvec[0] + CXOFF;
				y = newvec[1] + CYOFF;

				/* reset color of screen */
				mxcolor = 1;

				/* wait for vertical blanking */

				/* draw vector */
				mxmove(pfigm->x[new],pfigm->y[new]);
				mxvect(x,y);

	
				/* save coordinates */
				pfig->x[new] = x;
				pfig->y[new] = y;


				/* erase old image */
				mxcolor = 0;
				/* wait for vertical blanking */

				mxmove(pfigm->x[old],pfigm->y[old]);
				mxvect(pfig->x[old],pfig->y[old]);
			}

			/* initialize first point */
			pfig = fig2;
			vecmpy(pfig->vec,rot,newvec,2);
			pfig->x[new] = newvec[0] + CXOFF2;
			pfig->y[new] = newvec[1] + CYOFF2;


			for(nfig = 1; nfig < NUMFIG2; nfig++) {
				pfigm = pfig++;
				vecmpy(pfig->vec,rot,newvec,2);
			/* reset color of screen */
			mxcolor = 1;

				/* get x, y */
				x = newvec[0] + CXOFF2;
				y = newvec[1] + CYOFF2;

				/* wait for vertical blanking */

				/* draw vector */
				mxmove(pfigm->x[new],pfigm->y[new]);
				mxvect(x,y);

	
				/* save coordinates */
				pfig->x[new] = x;
				pfig->y[new] = y;
				mxcolor = 0;
				/* wait for vertical blanking */

				mxmove(pfigm->x[old],pfigm->y[old]);
				mxvect(pfig->x[old],pfig->y[old]);
			}



			/* now, copy new points to old points */
			old = new;
			new = (new == 0 ? 1 : 0);
		}

	}
}
/* VECMPY -- vector - matrix multiplication
 *
 * written 1979 by Lance M. Optican
 *
 */

vecmpy(a, b, c, n)
	double *a, *b, *c;
	int n;
{
	/* VECTOR MULTIPLY
	 * c = a * b;
	 *
	 * a is 1 x n
	 * b is n x n
	 * c is therefore 1 x n
	 */

	register int j;
	register double *aptr, *bptr;
	static int i, k;
	static double sum;

	/* do for all elements of c, columns increment faster than rows */

	for (k = 0; k < n; k++) {
		aptr = a;	/* start in col 1 */
		bptr = b + k;	/* get kth column */
		for (sum = 0, j = 0; j < n; j++) {
			sum += *aptr * *bptr;
			aptr++;	/* next col in jth row */
			bptr += n;	/* next row in jth column */
		}
		*c++ = sum;
	}
}
