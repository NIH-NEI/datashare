/*
 * Initialization routines for graphics display.  Device
 * dependant.
 */

#include "../../hdr/matrox.h"

static int a;

int *
mxphys(void)
{
    return(&a);
}
