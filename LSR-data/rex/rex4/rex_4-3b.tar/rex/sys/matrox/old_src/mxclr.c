#include "matrox.g"

main()
{
	/* erase matrox */

	mxphys();
	mxscroll(0);
	mxerase;
}
