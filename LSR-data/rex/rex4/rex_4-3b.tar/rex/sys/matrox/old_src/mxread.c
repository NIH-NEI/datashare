#include "../../hdr/matrox.h"


/* function to read a point from the MATROX screen. */
/* assume that x and y are within range [0,511] */

mxread(int x,int y)
{

	/* first set x and y registers */
	mxnewx(x);
	mxnewy(y);

	/* return value */
	return(mxptr->dr & 01);
}
