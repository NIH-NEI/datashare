#include "../../hdr/matrox.h"

void
mxover(int *pcurs, int newx, int newy)
{
	/* mxover -- overlay a figure on the matrox
	 * pcurs -- a pointer to an array of integers of the form:
	 *	z, z
	 *	a, b, +1
	 *	a, b, +1
	 *	a, b, -1
	 * where a, b specify the x and y offsets of the figure
	 * and z is any integer value
	 * newx and newy are assumed to be in range [0,511]
	 */


	int *ptr, x, y;
	int xold, yold;

	/* get old x and y values, save new ones */
	xold = *pcurs;
	*pcurs++ = newx;
	yold = *pcurs;
	*pcurs++ = newy;

	/* restore old positions by reseting to background any
	 * old color which was backcolor
	 */
	for (ptr = pcurs; ptr[2] >= 0; ptr++) {
		/* get relative offset */
		x = *ptr++;
		y = *ptr++;

		/* restore old color */
		if (*ptr == mxback )
			mxfast(x + xold, y + yold, mxback);

		/* now, redraw in new location, saving old color */
		x += newx;
		y += newy;
		/* get old color, and change back if necessary */
		if ((*ptr = mxread(x,y)) != mxcolor) mxwrite(mxcolor);
	}
}
