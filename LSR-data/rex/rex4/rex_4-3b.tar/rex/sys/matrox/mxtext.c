#include "../../hdr/matrox.h"

#define HT	011		/* horizontal tab */
#define NL	012		/* new line */
#define VT	013		/* vertical tab */
#define FF	014		/* form feed */
#define CR	015		/* carriage return */

/* display lines of text on the scope.  Rewritten from a macro
 * program, so forgive the bad code!
 */

void
mxtext(char *p)
{
	static int col= 0;
	char c;
	


	for ( ; *p != '\0'; p++) {

			if (*p > CR) mxchar(*p);
			else switch(*p) {

			case HT:		/* horizontal tab */
				c = 8 - (col & 07) ;
				col += c;
				while(c--) mxchar(' ');
				break;

			case NL:		/* new line */
				col = 0;
				mxoldy -= (mxcrht + mxlnsp);
				if (mxoldy < 0) goto formfeed;
				mxoldx = mxmrgn;
				break;

			case VT:		/* vertical tab */
				mxoldy += mxcrht;
				if (mxoldy > mxtopf) goto formfeed;
				break;

			case CR:	/* carriage return */
				col = 0;
				mxoldx = mxmrgn;
				break;
			formfeed:
			case FF:	/* form feed */
				mxerase(0);
				mxoldx = mxmrgn;
				mxoldy = mxtopf;
				col = 0;
				mxwait();
				break;
			default:
				mxchar(' ');
				break;
			}
	}
}
