#include "../../hdr/matrox.h"
#include <stdlib.h>
#include <stdio.h>

char *msg = "A B C D E F G H I J K L M N O P Q R S T U";
char *msg2 = "Hello, World!\nNow is the Time For All Good men\nto come";
main()
{
	char *p;
	char i;

	/* map matrox */
	if (mxinit(1)) {
		mxinit(0);
		printf("Error\n");
		exit(0);
	}


	/* initialize scroll */
	mxscroll(0);
	mxerase(0);
	mxwait();
	setmxcolor(1);

	for(p = msg; *p;) mxchar(*p++);
	mxmove(0,100); mxtext(msg);
	mxmove(0,200); mxtext(msg2);
	mxsize(3);
	mxmove(0, 400);
	for (i = 'A'; i <= 'Z'; i++) {
		mxchar(i);
		mxchar('\b');
	}

	getchar();
	mxinit(0);
}
