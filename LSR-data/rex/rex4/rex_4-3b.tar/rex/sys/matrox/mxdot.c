#include "../../hdr/matrox.h"

void
mxdot(int x,int y)
{
	mxfast(x, y, mxcolor);
}
