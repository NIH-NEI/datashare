/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government.  The original
 * versions, REX 1.0-3.12, were developed for the pdp11 architecture and
 * distributed without restrictions.  This version, REX 4.0, is a port of
 * the original version to the Intel 80x86 architecture.  This version is
 * distributed only under license agreement from the National Institutes 
 * of Health, Laboratory of Sensorimotor Research, Bldg 10 Rm 10C101, 
 * 9000 Rockville Pike, Bethesda, MD, 20892, (301) 496-9375.
 *-----------------------------------------------------------------------*
 */

/*
 * Low level (adapter dependent) routines for Matrox API.
 */
#include <string.h>
#include <stdlib.h>
#include "../../hdr/sys.h"
#include "../../hdr/cdsp.h"
#include "../../hdr/matrox.h"

#ifdef VGA_640

#include <stdio.h>
#include <i86.h>
#include <sys/seginfo.h>

#ifdef __386__
#define REGWRD w
#define INTCALL int386
#else
#define REGWRD x
#define INTCALL int86
#endif /* 386 */

#define TX_MODE	0x03	    /* normal text mode */
#define GR_MODE	0x12	    /* graphics mode: 640x480 with 16 colors */
#define FBADDR	0xa0000	    /* frame buffer address */
#define FBSIZE	38400	    /* size in bytes of frame buffer */

int fb_sel= -1;		    /* frame buffer selector */
#ifdef NEED_FAR
u_char far *fb_p;	    /* pointer to frame buffer */
#else
u_char *fb_p;
#endif

/*
 * Initialize, de-initialize adapter.
 */
int
mxinit(int flag)
{
    union REGS myregs, clear_regs= {0};
    
    if(flag) {	    /* initialize */
    
	/*
	 * Map frame buffer into address space.
	 */
	if(fb_sel == -1) {
	    if((fb_sel= qnx_segment_overlay(FBADDR, FBSIZE)) == -1) {
		return(-1);
	    }
	    fb_p= MK_FP(fb_sel, 0);
	}

	/*
	 * Change screen to graphics mode.  This is done via a
	 * INT 10 Video BIOS call.  The MetaWINDOWS shared library
	 * must be running for this to work.  If it is not running,
	 * however, no errors are returned.
	 */
	myregs= clear_regs;
	myregs.w.ax= GR_MODE;
	INTCALL(0x10, &myregs, &myregs);

    } else {

	/*
	 * De-initialize adapter.
	 */
	myregs= clear_regs;
	myregs.w.ax= TX_MODE;
	INTCALL(0x10, &myregs, &myregs);
	
	if(fb_sel != -1) {
	    if(qnx_segment_free(fb_sel) == -1) {
		return(-1);
	    }
	    fb_sel= -1;
	    fb_p= 0;
	}
    }
    return(0);
}

void
mxerase(int flag)
{
    if(flag) _fmemset(fb_p, ~0, FBSIZE);
    else _fmemset(fb_p, 0, FBSIZE);
}

#pragma off (unreferenced)
void
mxscroll(int z)
#pragma on (unreferenced)
{
}

void
mxfast(int x, int y, int z)
{
    u_int byte_add;
    u_char off;

    if(mxwrap) {

	/*
	 * Rudimentary support for wrapping display.
	 */
	x &= WDI_XWRAP;
	y &= WDI_YWRAP;
    }
    if(x < 0 || x > WDI_RIGHT) {
	if(x < 0) x= 0;
	else x= WDI_RIGHT;
    }
    if(y < 0 || y > WDI_TOP) {
	if(y < 0) y= 0;
	else y= WDI_TOP;
    }
    lastx= x;
    lasty= y;

    byte_add= ((479-y) * 80) + (x / 8);
    off= 0200 >> (x % 8);

    if(z) *(fb_p + byte_add) |= off;
    else  *(fb_p + byte_add) &= ~off;
}

int
mxread(void)
{
    u_int byte_add;
    u_char off;

    byte_add= ((479-lasty) * 80) + (lastx / 8);
    off= 0200 >> (lastx % 8);

    if(*(fb_p + byte_add) & off) return(1);
    else return(0);
}

void
mxonlyx(int x)
{
    mxfast(x, lasty, mxcolor);
}

void
mxonlyy(int y)
{
    mxfast(lastx, y, mxcolor);
}

void
mxnewx(int x)
{
    if(mxwrap) x &= WDI_XWRAP;
    if(x < 0 || x > WDI_RIGHT) {
	if(x < 0) x= 0;
	else x= WDI_RIGHT;
    }
    lastx= x;
}

void
mxnewy(int y)
{
    if(mxwrap) y &= WDI_YWRAP;
    if(y < 0 || y > WDI_TOP) {
	if(y < 0) y= 0;
	else y= WDI_TOP;
    }
    lasty= y;
}

void
mxwrite(int z)
{
    mxfast(lastx, lasty, z);
}

void
mxmove(int x, int y)
{
    if(mxwrap) {

	/*
	 * Rudimentary support for wrapping display.
	 */
	x &= WDI_XWRAP;
	y &= WDI_YWRAP;
    }
    if(x < 0 || x > WDI_RIGHT) {
	if(x < 0) x= 0;
	else x= WDI_RIGHT;
    }
    if(y < 0 || y > WDI_TOP) {
	if(y < 0) y= 0;
	else y= WDI_TOP;
    }
    mxoldx= x;
    mxoldy= y;
}

void
setmxcolor(int z)
{
    mxcolor= z;
}

#endif
