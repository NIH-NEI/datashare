/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government.  The original
 * versions, REX 1.0-3.12, were developed for the pdp11 architecture and
 * distributed without restrictions.  This version, REX 4.0, is a port of
 * the original version to the Intel 80x86 architecture.  This version is
 * distributed only under license agreement from the National Institutes 
 * of Health, Laboratory of Sensorimotor Research, Bldg 10 Rm 10C101, 
 * 9000 Rockville Pike, Bethesda, MD, 20892, (301) 496-9375.
 *-----------------------------------------------------------------------*
 */

#include <unistd.h>
#include "../../hdr/sys.h"
#include "../../hdr/proc.h"
#include "../../hdr/buf.h"

/*
 * Function p_rxerr() is a part of comm only and is only called by
 * rxerr() in comm.  Pointer is reinitialized by comm to point to
 * p_rxerr() function.
 */
extern int nullf();
int (*p_err)()= &nullf;
extern int inside_int;

/*
 * Rex error reporting.  If this process is not the comm process send
 * error message to comm thru shared area in INT_BLOCK.  If this process
 * is comm call error processor directly.
 *
 * If called from the interrupt level, a message is just printed
 * via 'dputs'.
 */
void
#ifdef NEED_FAR
/*
 * Pointers to local automatic storage must be far when routine is
 * called from interrupt level.
 */
rxerr(char far *s)
#else
rxerr(char *s)
#endif
{
	PROCTBL_P comm_p= COMM;

	if(myptx != 0) {	/* not comm process */

		if((myptx == i_b->int_pi) && inside_int) {

		    /*
		     * Can't do the rest of this function at interrupt
		     * level!  This wont print at top of screen.
		     */
		    dputs(s);
		    dputchar(' ');
		    return;
		}
		for(;;) {

			/*
			 * Wait for errstr[] to free.  This is a
			 * critical section with comm and must be
			 * protected.
			 */
			protect(&comm_p->p_sem);
			if(i_b->i_errstr[0] == '\0') break;	/* free */
			release_(&comm_p->p_sem);
			sleep(1);
		}
		i_b->i_errptx= myptx;		/* record who I am */
#ifdef NEED_FAR
		_fstufs(s, &i_b->i_errstr, &i_b->i_errstr[P_ISLEN]);
#else
		stufs(s, &i_b->i_errstr, &i_b->i_errstr[P_ISLEN]);
#endif
		release_(&comm_p->p_sem);
		sendmsg(comm_p, CM_RXERR);

	} else {

		/*
		 * COMM process.  Call p_rxerr() directly. 
		 */
		(*p_err)(s, 0);
	}
}
