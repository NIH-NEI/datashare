/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government.  The original
 * versions, REX 1.0-3.12, were developed for the pdp11 architecture and
 * distributed without restrictions.  This version, REX 4.0, is a port of
 * the original version to the Intel 80x86 architecture.  This version is
 * distributed only under license agreement from the National Institutes 
 * of Health, Laboratory of Sensorimotor Research, Bldg 10 Rm 10C101, 
 * 9000 Rockville Pike, Bethesda, MD, 20892, (301) 496-9375.
 *-----------------------------------------------------------------------*
 */

/*
 * Read in physical address parameters of shared data area from file
 * on disk.
 */

#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include "../../hdr/sys.h"
#include "../../hdr/phys.h"

void
getparam(int fd, PARAM *pm)
{

	/*
	 * Seek to beginning of file and read.
	 */
	if(lseek(fd, 0, SEEK_SET) == -1) {
	    perror("Cannot seek in 'getparam()'");
	    exit(1);
	}
	if(read(fd,pm,sizeof(PARAM)) < sizeof(PARAM)) {

		/*
		 * At this point, shared data area is not mapped.  Cannot
		 * do rxerr().
		 */
		fprintf(stderr,
			"getparam():  Cannot read param file, errno= %d\n",
					errno);
		exit(1);
	}
}

