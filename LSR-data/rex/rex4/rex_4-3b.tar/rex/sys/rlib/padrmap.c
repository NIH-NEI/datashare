/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government.  The original
 * versions, REX 1.0-3.12, were developed for the pdp11 architecture and
 * distributed without restrictions.  This version, REX 4.0, is a port of
 * the original version to the Intel 80x86 architecture.  This version is
 * distributed only under license agreement from the National Institutes 
 * of Health, Laboratory of Sensorimotor Research, Bldg 10 Rm 10C101, 
 * 9000 Rockville Pike, Bethesda, MD, 20892, (301) 496-9375.
 *-----------------------------------------------------------------------*
 */

/*
 * Get specified segment and map into process address space.
 */

#include <stdio.h>
#include <sys/seginfo.h>
#include <errno.h>
#include <i86.h>
#include "../../hdr/sys.h"
#include "../../hdr/phys.h"

#ifdef NEED_FAR
void far *
#else
void *
#endif
padr_map(PHYSADR *p)
{

    if(p->pa_flag != PA_ALLOC) {	/* dont map if already done */

	if((p->pa_my_sel= qnx_segment_get(p->pa_own_pid,
			p->pa_own_sel, 0)) == -1) {
			    perror("Cannot get segment");
			    fprintf(stderr, "errno: %#x\n", errno);
#ifdef GOO
{
    struct _seginfo sinfo;

    printf("after get\n");
    printf("par pid %d, par sel %#x\n", p->pa_own_pid, p->pa_own_sel);
    if(qnx_segment_info(0,p->pa_own_pid,p->pa_own_sel, &sinfo) == -1) perror("info");
    fprintf(stderr, "par: sel %#x, flags %#x\n", sinfo.selector, sinfo.flags);
    fprintf(stderr, "par: addr %#X, bytes %d\n", sinfo.addr, sinfo.nbytes);
}
#endif
			    return((void *)-1);
	}
    }
#ifdef NEED_FAR
    p->pa_my_p= (void far *)MK_FP(p->pa_my_sel, p->pa_off);
#else
    p->pa_my_p= p->pa_my_sel;
#endif	
    return(p->pa_my_p);
}
