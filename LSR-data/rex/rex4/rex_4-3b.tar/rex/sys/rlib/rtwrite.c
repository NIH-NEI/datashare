/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government.  The original
 * versions, REX 1.0-3.12, were developed for the pdp11 architecture and
 * distributed without restrictions.  This version, REX 4.0, is a port of
 * the original version to the Intel 80x86 architecture.  This version is
 * distributed only under license agreement from the National Institutes 
 * of Health, Laboratory of Sensorimotor Research, Bldg 10 Rm 10C101, 
 * 9000 Rockville Pike, Bethesda, MD, 20892, (301) 496-9375.
 *-----------------------------------------------------------------------*
 */

/*
 * Root write processing.
 */

#include <string.h>
#include <stdio.h>
#include <sys/types.h>
#include "../../hdr/sys.h"
#include "../../hdr/proc.h"
#include "../../hdr/buf.h"
#include "../../hdr/tty.h"
#include "../../hdr/menu.h"

extern FILE *rtout;

/*
 * Only the int process calls mksroot() to write state list variables to
 * root file.  Following pointer is initialized by int to point to mksroot()
 * function.  For other REX processes it is initialized to point to a
 * null function that is never called.
 */
extern int nullf();
int (*p_mksroot)() = &nullf;

/*
 * Called from alert() to write root file for this process.
 */
int rt_write(void)
{
	INT_BLOCK_P I_b= i_b;
	MENU *mp;
#ifdef NEED_FAR
	char far *begp;
	char far *endp;
#else
	char *begp;
	char *endp;
#endif
	int error= 0, argc, mx;
	char *argv[P_NARG];
	
#ifdef NEED_FAR
	char tmp[P_ISLEN];

	_fstrncpy(tmp, I_b->i_rtname, P_ISLEN);
	if((rtout= fopen(tmp, "a")) == NULL) {
#else
	if((rtout= fopen(I_B->i_rtname, "a")) == NULL) {
#endif
		rxerr("rt_write(): Cannot open root file");
		return(-1);
	}

	if(I_b->i_rtflag & RT_WMENU) {
	    if(I_b->i_rtmenus[0] == '\0') {	/* do all menus */
		argv[0]= NP;
		for(mp= &menus; *mp->me_name != '\0'; mp++) {
		    if(mkroot(mp, argv, NP) < 0) {
			error= 1;
			goto out;
		    }
		}
	    } else {

		/*
		 * Parse menu arguments for write root command.
		 */
		for(begp= I_b->i_rtmenus; begp != NP; begp= endp) {
#ifdef NEED_FAR
		    char tmp[P_ISLEN];
#endif		    
		    /*
		     * Look for comma and replace with null termination.
		     */
#ifdef NEED_FAR
		    if((endp= _findex_RL(',', begp)) != NP) *endp++ = '\0';
#else
		    if((endp= index_RL(',', begp)) != NP) *endp++ = '\0';
#endif
#ifdef NEED_FAR
		    _fstrncpy(tmp, begp, P_ISLEN);
		    if((argc= parse(1, tmp, argv, P_NARG)) < 0) {
#else
		    if((argc= parse(1, begp, argv, P_NARG)) < 0) {
#endif
			error= 1;
			goto out;
		    }
		    if((mx= sindex(*argv, &menus[0].me_name, sizeof(MENU)))
					< 0) {
			rxerr("rt_write(): Bad menu name");
			error= 1;
			goto out;
		    }
		    mp= &menus[mx];
		    if(mkroot(mp, &argv[1], NP) < 0) {
			error= 1;
			goto out;
		    }
		}
	    }
	}

	if(I_b->i_rtflag & RT_WSTATE
	&& myptx == I_b->int_pi) if((*p_mksroot)() < 0) error= 1;

out:
	fflush(rtout);
	fclose(rtout);
	return(error);
}

/*
 * Write specified menu to root file.
 * If tvlp != NP, mkroot() has been called recursively to write a submenu;
 * name of submenu is tvlp->vl_name.  Otherwise mkroot() has been called
 * to write a top level menu and will output the full syntax for the menu
 * name with the .process extension.
 */
int mkroot(MENU *mp, char *argv[], VLIST *tvlp)
{
	VLIST *vlp;
	int call_cnt= 0;
	int (*fp)(), (*afp)();
	char astr[P_ISLEN];
	char *nullarg[1]= {0};

	/*
	 * If called with no args and there is an argument
	 * generation function, initialize fp.
	 */
	if(*argv == NP && (mp->me_rtagen != NP)) fp= mp->me_rtagen;
	else fp= NP;

	for(;;) {

	    if(fp != NP) {
		if((*fp)(call_cnt++, mp, astr) < 0) {
		    rxerr("mkroot(): Bad return from me_rtagen()");
		    return(-1);
		}
		if(astr[0] == '\0') break;	/* done */
		*argv= astr;
	    }
	    if(mp->me_flag & ME_BEF) {
		afp= mp->me_accf;
		if((*afp)(ME_BEF|ME_ROOT, mp, *argv, NP, NP) < 0) {
		    rxerr("mkroot(): Illegal menu access");
		    return(-1);
		}
	    }

	    /*
	     * Print menu name.
	     */
	    if(tvlp == NP) {
		fputs("~\n~Menu:\n", rtout);
		fputs(mp->me_name, rtout);
		if(myptx == i_b->int_pi) fputs(".int", rtout);
		else {
#ifdef NEED_FAR
			char tmp[P_LPROCNAME];

			_fstrncpy(tmp, myptp->p_name, P_LPROCNAME);
			putc('.', rtout);
			fputs(tmp, rtout);
#else
			putc('.', rtout);
			fputs(myptp->p_name, rtout);
#endif
		}
	    } else fputs(tvlp->vl_name, rtout);
	    if(*argv != NP) {
		putc(' ', rtout);
		fputs(*argv, rtout);
	    }
	    if(tvlp == NP) {
		if(myptx == i_b->int_pi) {
#ifdef NEED_FAR
		    char tmp[P_LPROCNAME];
#endif

		    fputs("\t~Int proc name: ", rtout);
#ifdef NEED_FAR
		    _fstrncpy(tmp, myptp->p_name, P_LPROCNAME);
		    fputs(tmp, rtout);
#else
		    fputs(myptp->p_name, rtout);
#endif
		}
	    } else {
		fputs("\t~--Submenu begins-->", rtout);
	    }
	    putc('\n', rtout);

	    /*
	     * Print entries and values.
	     */
	    for(vlp= mp->me_vlp; *vlp->vl_name != '\0'; vlp++) {

		/*
		 * If entry is a submenu, recurse and call mkroot again.
		 * Arg passed is always ptr to NP for submenus;  all
		 * submenus will be written.
		 */
		if(vlp->vl_type == ME_SUBMENU) {
		    if(mkroot((MENU *)vlp->vl_add, &nullarg, vlp) < 0) return(-1);
		    fputs("~--End submenu-->\n", rtout);
		} else pr_line(mp, vlp, 0, rtout);
	    }

	    /*
	     * Following terminates loop when args are not supplied by
	     * me_rtagen().  First statement is for case when mkroot() is
	     * called with no arg strings, second for case in which an
	     * array of arg strings is passed.
	     */
	    if(fp == NP) {
		if(*argv == NP) break;
		if(*++argv == NP) break;
	    }
	}
	return(0);
}
