/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government.  The original
 * versions, REX 1.0-3.12, were developed for the pdp11 architecture and
 * distributed without restrictions.  This version, REX 4.0, is a port of
 * the original version to the Intel 80x86 architecture.  This version is
 * distributed only under license agreement from the National Institutes 
 * of Health, Laboratory of Sensorimotor Research, Bldg 10 Rm 10C101, 
 * 9000 Rockville Pike, Bethesda, MD, 20892, (301) 496-9375.
 *-----------------------------------------------------------------------*
 */

/*
 * Send interprocess communication messages.
 */

#include <signal.h>
#include <stdio.h>
#include "../../hdr/sys.h"
#include "../../hdr/proc.h"
#include "../../hdr/buf.h"

#undef  A_DEBUG			/* define for debugging info */

#define BLANKS 18
static char noproc[] = "Process has died:                ";

int
sendmsg(PROCTBL_P p, u_int msg)
{
	u_int msgbit;


#ifdef A_DEBUG
dprintf("-smsg: p %D, msg 0%o-", p, s_(msg));
#endif
	if(p->p_id <= 0) {
		rxerr("sendmsg(): Attempt to send msg to non-existant proc");
		return(-1);
	}
	msgbit= s_(msg);

	/*
	 * Procs that are stopped can receive only certain messages.
	 */
	if(p != COMM && ((p->p_state & P_RUN_ST) == 0)
	&& ((msgbit & (s_(G_KILL)|s_(G_STOP)|s_(G_RUN))) == 0) ) {
		rxerr("sendmsg(): Cannot send msg; process is in stop state");
		return(-1);
	}

	/*
	 * Message sending involves critical sections with the message
	 * receiver in each process, alert(), and must be protected.
	 */
	protect(&p->p_sem);
	p->p_msg |= msgbit;		/* set message bit */

	/*
	 * Signal sending is interlocked so that a signal is sent only
	 * when necessary to wake up the receiving process, OR re-interrupt
	 * a lower priority message currently executing in the receiving
	 * process.
	 */
	if( ! (p->p_state & P_NOSIG_ST)) {	/* signalling allowed */

		/*
		 * If the receiving process is currently not asleep but
		 * processing a message that has allowed re-interrupts, the
		 * re-interrupt mask will specify which messages are permitted
		 * to signal and cause a re-interrupt.
		 */
		if(msgbit & ~p->p_rmask) {
			p->p_state |= P_NOSIG_ST;
			release_(&p->p_sem);
#ifdef A_DEBUG
dprintf("-smsg: killing %d-", p->p_id);
#endif
			if(kill(p->p_id, S_ALERT) == -1) {

#ifdef NEED_FAR
				_fstufs(p->p_name, &noproc[BLANKS], &noproc[0] +
								sizeof(noproc));
#else
				stufs(p->p_name, &noproc[BLANKS], &noproc[0] +
								sizeof(noproc));
#endif
				rxerr(noproc);
				p->p_state &= ~P_NOSIG_ST;
				return(-1);
			}
			return(0);
		}
	}
	release_(&p->p_sem);
	return(0);
}
