/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government, is in the
 * public domain, and cannot be copywrited.  For further information
 * contact:  Laboratory of Sensorimotor Research, National Eye Institute,
 * National Institutes of Health, Bldg 10 Rm 6C420, Bethesda, MD, 20205.
 *-----------------------------------------------------------------------*
 */

#include <conio.h>
#include <stdlib.h>
#include "../../hdr/sys.h"

/*
 * Convert integer to ascii.  Accepts flags for decimal, unsigned decimal,
 * hex, and octal.  Returns pointer to null termination.
 */

/*
 * Flag: 'd' signed decimal, 'u' unsigned decimal, 'o' unsigned octal,
 * 'x' hex.
 */
char
*itoa_RL(int num, char flag, char *to, char *ep)
{
	char tmp[100];
	char *p= &tmp[0];

	switch(flag) {
	case 'd':
		itoa(num, tmp, 10);
		break;
	case 'o':
		itoa(num, tmp, 8);
		break;
	case 'u':
		utoa((unsigned)num, tmp, 10);
		break;
	case 'x':
		itoa(num, tmp, 16);
		break;
	}

	if(to >= ep) {
		to= ep;
		goto out;
	}
	for(p= tmp; *p != '\0';) {
		*to++ = *p++;

		/*
		 * Leave to pointing at ep when string is full.
		 */
		if(to == ep) {
			*(to - 1) = '\0';
			goto out;
		}
	}
	*to= '\0';

out:
	return(to);
}
