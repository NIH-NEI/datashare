/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government, is in the
 * public domain, and cannot be copywrited.  For further information
 * contact:  Laboratory of Sensorimotor Research, National Eye Institute,
 * National Institutes of Health, Bldg 10 Rm 6C420, Bethesda, MD, 20205.
 *-----------------------------------------------------------------------*
 */

#include "../../hdr/sys.h"
#include <stdlib.h>

/*
 * Convert long to ascii.
 * Returns pointer to null terimination.
 */
char *
ltoa_RL(long num, char *to, char *ep)
{
	char tmp[100];
	char *p= &tmp[0];
  
	ltoa(num, tmp, 10);

	if(to >= ep) {
		to= ep;
		goto out;
	}
	for(p= tmp; *p != '\0';) {
		*to++ = *p++;

		/*
		 * Leave to pointing at ep when string is full.
		 */
		if(to == ep) {
			*(to - 1) = '\0';
			goto out;
		}
	}
	*to= '\0';

out:
	return(to);
}
