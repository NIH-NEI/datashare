/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government, is in the
 * public domain, and cannot be copywrited.  For further information
 * contact:  Laboratory of Sensorimotor Research, National Eye Institute,
 * National Institutes of Health, Bldg 10 Rm 6C420, Bethesda, MD, 20205.
 *-----------------------------------------------------------------------*
 */

/*
 * Map the I/O page.  Returns an offset based on the specified memory
 * management register.  This offest is then subtracted from the desired
 * page 7 physical address by the calling routine to yield the virtual
 * address that now maps that physical address.
 */

#define H "../../hdr
#include H/sys.h"
#include H/phys.h"
#include H/device.h"

char *
io_map(mmr, size)
register mmr;
{
	if( phys(mmr, size, PH_IOPAGE) == -1 )  {
		rxerr("iomap(): error on phys sys call");
		return(-1);	/* 0177777 would not be a legal return */
	}
	return( (7 - mmr) * 020000 );
}
