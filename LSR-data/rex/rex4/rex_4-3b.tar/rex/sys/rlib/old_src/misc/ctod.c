/*
 * ctod.c:	Convert an object image with relocation bits intact to
 *		an image with no text segment.
 *
 * Idea: make text size 0 and increase initialized data size by old text size.
 * Then change all text symbols in symbol table to data symbols.  Finally,
 * change relocation info from text references to data.
 *
 * Why anyone would ever want to do this is a long story.
 *
 *	AVH; 20 Aug 81;
 */

struct head {
	int	magic;
	int	tsize;
	int	dsize;
	int	unsize;
	int	symsiz;
	int	dum[2];
	int	rflag;
} head;

struct sym {
	int	name[4];
	int	type;
	int	val;
};

#define TXT	02
#define DATA	03
#define ETXT	042
#define EDATA	043
#define RDATA	04

int	buf[256];
int	sbuf[150];
int	tsize;
int	dsize;

main(argc, argv)
char *argv[];
{
	register int fd;

	if(argc == 1) {
		printf("ctod (convert text to data):  Move text in ");
		printf("a Unix object with\n");
		printf("relocation bits intact to the initialized ");
		printf("data segment.\n");
		printf("\tUsage: ctod files\n");
		exit(1);
	}
	while(argc-- > 1)  {
		argv++;
		if((fd= open(*argv, 2)) == -1) {
			printf("Cannot open %s\n", *argv);
		} else {
			printf("%s:\n", *argv);
			change(fd, *argv);
		}
		close(fd);
	}
	exit(0);
}

change(fd, argv)
char *argv;
{
	register int loopcnt, *ptr;
	register struct sym *sptr;
	int doneflg, rcnt, symsiz, relsize;
	int readcnt;

	if(read(fd, &head, sizeof(head)) != sizeof(head)) {
		printf("Error on read, %s\n", argv);
		return(0);
	}
	if(head.magic != 0407) {
		printf("Object must be type 0407, %s\n", argv);
		return(0);
	}
	if(head.rflag != 0) {
		printf("No relocation bits, %s\n", argv);
		return(0);
	}
	tsize= head.tsize;
	dsize= head.dsize;
	head.dsize += tsize;
	head.tsize= 0;
	seek(fd, 0, 0);
	if(write(fd, &head, sizeof(head)) != sizeof(head)) {
		printf("Error on write, %s\n", argv);
		return(0);
	}

	/*
	 * Now do relocation bits.
	 */
	relsize= tsize + dsize;
	seek(fd, 020+relsize, 0);
	rcnt= 0;
	doneflg= 0;
	for(;;) {
		if((readcnt= read(fd, &buf, 512)) == -1) {
			printf("Error on file read, %s\n", argv);
			return(0);
		}
		ptr= &buf;
		loopcnt= 256;
		do {
			if(rcnt++ == (relsize / 2)) {
				doneflg= 1;
				break;
			}
			if((*ptr & 016) == TXT)  {
				*ptr =& ~TXT;
				*ptr =| RDATA;
			}
			ptr++;
		} while(--loopcnt);
		seek(fd, -readcnt, 1);
		if(write(fd, &buf, readcnt) != readcnt) {
			printf("Error on write, %s\n", argv);
			return(0);
		}
		if( (readcnt != 512) && (doneflg == 0) ) {
			printf("Sync error on file, %s\n", argv);
			return(0);
		}
		if(doneflg) break;
	}

	/*
	 * Now do symbol table.
	 */
	seek(fd, 020 + (2 * relsize), 0);
	doneflg= 0;
	rcnt= 0;
	symsiz= head.symsiz / 12;
	for(;;)  {
		if((readcnt= read(fd, &sbuf, 300)) == -1) {
			printf("Error on file read, %s\n", argv);
			return(0);
		}
		sptr= &sbuf;
		loopcnt= 25;
		do {
			if(rcnt++ == symsiz) {
				doneflg= 1;
				break;
			}
			if(sptr->type == TXT) sptr->type= DATA;
			if(sptr->type == ETXT) sptr->type= EDATA;
			sptr++;
		} while(--loopcnt);
		seek(fd, -readcnt, 1);
		if(write(fd, &sbuf, readcnt) != readcnt) {
			printf("Error on write, %s\n", argv);
			return(0);
		}
		if( (readcnt != 300) && (doneflg == 0) ) {
			printf("Sync error on file, %s\n", argv);
			return(0);
		}
		if(doneflg) break;
	}
}
