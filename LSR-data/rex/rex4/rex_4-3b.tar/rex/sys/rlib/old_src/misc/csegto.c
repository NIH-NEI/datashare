/*
 * csegto.c:	Convert an object image with relocation bits intact to
 *		an image with either no text segment or no initialized
 *		data segment.  Object must be type 407.
 *
 * Idea: (assume converting to no text segment) Make text size 0 in header and
 * increase initialized data size by old text size.
 * Then change all text symbols in symbol table to data symbols.  Finally,
 * change relocation info from text references to data.
 *
 * Why anyone would ever want to do this is a long story.
 *
 *	AVH; 20 Aug 81;
 */

struct head {
	int	magic;
	int	tsize;
	int	dsize;
	int	unsize;
	int	symsiz;
	int	dum[2];
	int	rflag;
} head;

struct sym {
	int	name[4];
	int	type;
	int	val;
};

/*
 * Refer to desc of a.out format in section 5.
 */
#define S_TXT	02		/* txt type symbol */
#define S_DATA	03
#define S_ETXT	042
#define S_EDATA	043
#define R_TXT	02		/* relocation is for txt */
#define R_DATA	04

int	buf[256];
int	sbuf[150];
int	tsize;
int	dsize;

char helpmsg[] = "\
csegto (convert segment to): Convert text segment in Unix 407 type\n\
object file with relocation bits to initialzed data seg or vice versa.\n\
Usage:  csegto d files		convert text to data\n\
	csegto t files		convert data to text\n";

main(argc, argv)
char *argv[];
{
	register int fd;
	char toflag;

	if(argc <= 2) {
		printf("%s", helpmsg);
		exit(1);
	}
	argv++;
	toflag= *argv[0];
	if(toflag != 'd' && toflag != 't') {
		printf("Illegal flag: %c\n", toflag);
		exit(2);
	}
	argc--;
	while(argc-- > 1)  {
		argv++;
		if((fd= open(*argv, 2)) == -1) {
			printf("Cannot open %s\n", *argv);
		} else {
			printf("%s:\n", *argv);
			if(change(toflag, fd, *argv)) exit(3);
		}
		close(fd);
	}
	exit(0);
}

change(toflag, fd, argv)
char toflag;
char *argv;
{
	register int loopcnt, *ptr;
	register struct sym *sptr;
	int doneflg, rcnt, symsiz, relsize;
	int readcnt;

	if(read(fd, &head, sizeof(head)) != sizeof(head)) {
		printf("Error on read, %s\n", argv);
		return(1);
	}
	if(head.magic != 0407) {
		printf("Object must be type 0407, %s\n", argv);
		return(1);
	}
	if(head.rflag != 0) {
		printf("No relocation bits, %s\n", argv);
		return(1);
	}
	tsize= head.tsize;
	dsize= head.dsize;
	if(toflag == 'd') {
		head.dsize += tsize;
		head.tsize= 0;
	} else {
		head.tsize += dsize;
		head.dsize= 0;
	}
	seek(fd, 0, 0);
	if(write(fd, &head, sizeof(head)) != sizeof(head)) {
		printf("Error on write, %s\n", argv);
		return(1);
	}

	/*
	 * Now do relocation bits.
	 */
	relsize= tsize + dsize;
	seek(fd, 020+relsize, 0);
	rcnt= 0;
	doneflg= 0;
	for(;;) {
		if((readcnt= read(fd, &buf, 512)) == -1) {
			printf("Error on file read, %s\n", argv);
			return(1);
		}
		ptr= &buf;
		loopcnt= 256;
		do {
			if(rcnt++ == (relsize / 2)) {
				doneflg= 1;
				break;
			}
			if(toflag == 'd') {
			    if((*ptr & 016) == R_TXT)  {
				*ptr =& ~R_TXT;
				*ptr =| R_DATA;
			    }
			} else {
			    if((*ptr & 016) == R_DATA) {
				*ptr =& ~R_DATA;
				*ptr |= R_TXT;
			    }
			}
			ptr++;
		} while(--loopcnt);
		seek(fd, -readcnt, 1);
		if(write(fd, &buf, readcnt) != readcnt) {
			printf("Error on write, %s\n", argv);
			return(1);
		}
		if( (readcnt != 512) && (doneflg == 0) ) {
			printf("Sync error on file, %s\n", argv);
			return(1);
		}
		if(doneflg) break;
	}

	/*
	 * Now do symbol table.
	 */
	seek(fd, 020 + (2 * relsize), 0);
	doneflg= 0;
	rcnt= 0;
	symsiz= head.symsiz / 12;
	for(;;)  {
		if((readcnt= read(fd, &sbuf, 300)) == -1) {
			printf("Error on file read, %s\n", argv);
			return(1);
		}
		sptr= &sbuf;
		loopcnt= 25;
		do {
			if(rcnt++ == symsiz) {
				doneflg= 1;
				break;
			}
			if(toflag == 'd') {
			    if(sptr->type == S_TXT) sptr->type= S_DATA;
			    if(sptr->type == S_ETXT) sptr->type= S_EDATA;
			} else {
			    if(sptr->type == S_DATA) sptr->type= S_TXT;
			    if(sptr->type == S_EDATA) sptr->type= S_ETXT;
			}
			sptr++;
		} while(--loopcnt);
		seek(fd, -readcnt, 1);
		if(write(fd, &sbuf, readcnt) != readcnt) {
			printf("Error on write, %s\n", argv);
			return(1);
		}
		if( (readcnt != 300) && (doneflg == 0) ) {
			printf("Sync error on file, %s\n", argv);
			return(1);
		}
		if(doneflg) break;
	}
	return(0);
}
