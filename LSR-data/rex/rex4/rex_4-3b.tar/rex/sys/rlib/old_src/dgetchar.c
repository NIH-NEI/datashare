/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government, is in the
 * public domain, and cannot be copywrited.  For further information
 * contact:  Laboratory of Sensorimotor Research, National Eye Institute,
 * National Institutes of Health, Bldg 10 Rm 6C420, Bethesda, MD, 20205.
 *-----------------------------------------------------------------------*
 */

/*
 * Printing functions useful for debugging the lower level of int.
 * These routines access the I/O page to use the tty device registers
 * directly without going through the operating system.  They
 * can only be used from the interrupt level!
 *
 *	dgetchar()-	Returns single char & 0177.
 *
 */

#define H "../../hdr
#include H/sys.h"
#include H/device.h"
#include H/int.h"

#define KLADDR	d_(0177560)
#define DONE	0200
#define CNTLS	023

struct kl {
	int	rcsr;
	int	rbuf;
	int	xcsr;
	int	xbuf;
};

dgetchar()
{
	register int *klp= KLADDR;
	register int savps;
	register int c;

	savps= PSW->word;
	spl7L_;

	while( ! (klp->rcsr & 0200));
	c= klp->rbuf & 0177;

	PSW->word= savps;
	return(c);
}
