/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government.  The original
 * versions, REX 1.0-3.12, were developed for the pdp11 architecture and
 * distributed without restrictions.  This version, REX 4.0, is a port of
 * the original version to the Intel 80x86 architecture.  This version is
 * distributed only under license agreement from the National Institutes 
 * of Health, Laboratory of Sensorimotor Research, Bldg 10 Rm 10C101, 
 * 9000 Rockville Pike, Bethesda, MD, 20892, (301) 496-9375.
 *-----------------------------------------------------------------------*
 */

/*
 *	Calibration initializations.
 */

#include <sys/types.h>
#include "../../hdr/sys.h"
#include "../../hdr/proc.h"
#include "../../hdr/buf.h"

struct calib calib[MAXCAL] = {
	40,	0,	/* 0: 12bit, 40 steps/deg, 102.4 deg full scale */
	80,	1,	/* 1: 12bit, 51.2 FS */
	160,	2,	/* 2: 12bit, 25.6 FS */
	320,	3,	/* 3: 12bit, 12.8 FS */
	640,	4,	/* 4: 12bit, 6.4 FS */
	10,	-2,	/* 5: 10bit, 102.4 FS */
	20,	-1,	/* 6: 10bit, 51.4 FS */
	40,	0,	/* 7: 10bit, 25.4 FS */
	80,	1,	/* 8: 10bit, 12.8 FS */
	160, 	2,	/* 9: 10bit, 6.4 FS */
};
