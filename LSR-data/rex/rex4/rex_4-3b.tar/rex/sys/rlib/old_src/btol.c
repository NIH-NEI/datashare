/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government, is in the
 * public domain, and cannot be copywrited.  For further information
 * contact:  Laboratory of Sensorimotor Research, National Eye Institute,
 * National Institutes of Health, Bldg 10 Rm 6C420, Bethesda, MD, 20205.
 *-----------------------------------------------------------------------*
 */

/*
 * An 'ltoi' with base specification.
 */

#include "../../hdr/sys.h"
#include <ctype.h>

long
btol_RL(char *string, int base)
{
	long collect;

	for (collect= 0; isdigit(*string); string++)
		collect= (collect * base) + *string - '0';
	return(collect);
}
