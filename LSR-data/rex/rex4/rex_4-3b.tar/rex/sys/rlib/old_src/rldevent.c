/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government, is in the
 * public domain, and cannot be copywrited.  For further information
 * contact:  Laboratory of Sensorimotor Research, National Eye Institute,
 * National Institutes of Health, Bldg 10 Rm 10C101, Bethesda, MD, 20892
 *-----------------------------------------------------------------------*
 */

/*
 * Remote load event.  Used by processes other than int to load events.
 */

#include <unistd.h>
#include "../../hdr/sys.h"
#include "../../hdr/proc.h"
#include "../../hdr/buf.h"

void
rldevent(EVENT *evp)
{
	int clkflag= 0;
	INT_BLOCK_P i_br= i_b;

	/*
	 * Check if another rldevent is in progress.
	 */
	for(;;) {
		protect(&i_br->rev_sem);
		if( ! (i_br->i_flags & I_REVACTIVE)) break;
		release_(&i_br->rev_sem);
		sleep(1);
	}
	i_br->i_flags |= I_REVACTIVE;
	release_(&i_br->rev_sem);

	/*
	 * Prevent clock from either starting or stopping during rev.
	 */
	protect(&i_br->clk_sem);
	i_br->clkwait++;		/* inc count of things delaying clk */
	if(i_br->i_flags & I_GO) clkflag++;	/* save state of clock */
	release_(&i_br->clk_sem);

	/*
	 * If clock is going int will load the event, otherwise it must
	 * done here.
	 */
	if(clkflag) {

		/*
		 * Order of copy important;  int loads the rev when e_code
		 * becomes non-zero.  The int process will clear I_REVACTIVE
		 * and decrement clkwait when event is loaded.
		 */
		i_br->rev.e_key= evp->e_key;
		i_br->rev.e_code= evp->e_code;
	} else {
		i_br->bevent[i_br->evlx]= *evp;
		if(++i_br->evlx >= EBUFNUM) i_br->evlx= 0;
		if(i_br->evlx == i_br->evdx) sendmsg(SCRB, SC_EVERR);
		if(i_br->evlx == i_br->evdump) {    /* time to set new dump? */

			i_br->evdump += EDUMPINC;
			if(i_br->evdump >= EBUFNUM) i_br->evdump -= EBUFNUM;

			/*
			 * If writing to disk, alert scribe.
			 */
			if(i_br->i_flags & I_EOUT)
				sendmsg(SCRB, SC_EDUMP);
		}
		i_br->i_flags &= ~I_REVACTIVE;
		i_br->clkwait--;
	}
}
