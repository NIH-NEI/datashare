/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government.  The original
 * versions, REX 1.0-3.12, were developed for the pdp11 architecture and
 * distributed without restrictions.  This version, REX 4.0, is a port of
 * the original version to the Intel 80x86 architecture.  This version is
 * distributed only under license agreement from the National Institutes 
 * of Health, Laboratory of Sensorimotor Research, Bldg 10 Rm 10C101, 
 * 9000 Rockville Pike, Bethesda, MD, 20892, (301) 496-9375.
 *-----------------------------------------------------------------------*
 */

/*
 * Load event.  Use 'int_ldevent_()' macro to load events at interrupt
 * level.
 */

#include <unistd.h>
#include <i86.h>
#include "../../hdr/sys.h"
#include "../../hdr/proc.h"
#include "../../hdr/buf.h"

void
ldevent(EVENT *evp)
{
	int scrb_msg0 = 0, scrb_msg1= 0;
	
	/*
	 * Must be done with interrupts disabled.  Critical
	 * sections with interrupt routine, or scheduling of other processes
	 * which might call ldevent().
	 */
	_disable();
	i_b->bevent[i_b->evlx]= *evp;
	if(++i_b->evlx >= EBUFNUM) i_b->evlx= 0;
	if(i_b->evlx == i_b->evdx) scrb_msg0= SC_EVERR;
	if(i_b->evlx == i_b->evdump) {    /* time to set new dump? */

		i_b->evdump += EDUMPINC;
		if(i_b->evdump >= EBUFNUM) i_b->evdump -= EBUFNUM;

		/*
		 * If writing to disk, alert scribe.
		 */
		if(i_b->i_flags & I_EOUT) scrb_msg1= SC_EDUMP;

	}
	_enable();
	if(scrb_msg0) sendmsg(SCRB, scrb_msg0);
	if(scrb_msg1) sendmsg(SCRB, scrb_msg1);
}
