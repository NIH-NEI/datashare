/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government.  The original
 * versions, REX 1.0-3.12, were developed for the pdp11 architecture and
 * are in the public domain.  This version, REX 4.0, is a port of the
 * original version to the Intel 80x86 architecture.  This version is
 * copyright (C) 1992 by the National Institutes of Health, Laboratory
 * of Sensorimotor Research, Bldg 10 Rm 10C101, 9000 Rockville Pike,
 * Bethesda, MD, 20892, (301) 496-9375.  All rights reserved.
 *-----------------------------------------------------------------------*
 */

/*
 * Digitial I/O.
 */

/*
 * These routines are used in Spot files for interfacing to digital I/O:
 * dio_set(DIO_ID), dio_clr(DIO_ID), dio_out(DIO_ID, data) and
 * dio_in(DIO_ID).  The argument 'DIO_ID' is a 32 bit long with the
 * following description:
 *
 *       31		    HIGH WORD                 16
 *	 ___________-___________-___________-___________
 *	|__|__|__|__|__|__|__|__|__|__|__|__|__|__|__|__|
 *		Device id      	|       Port id
 *
 *       15		     LOW WORD                  0
 *	 ___________-___________-___________-___________
 *	|__|__|__|__|__|__|__|__|__|__|__|__|__|__|__|__|
 *			    bit mask
 *
 * This programming interface yields 8 bits for 'device_id', which is
 * typically a card in the PC, and 8 bits to select the port for cards
 * that implement multiple ports.
 *
 * At the beginning of a Spot file, one typically includes a header that
 * defines the 'DIO_ID' of devices in the laboratory by using the
 * following macro:
 *
 *	Dio_id(device_id, port_id, bit_mask)
 *
 * As an example, suppose an LED is connected in one laboratory to
 * the digital I/O port on a Data Translation DT2821 a/d converter
 * as bit 4.  This LED would be defined as:
 *
 *  #define LED_FP0	Dio_id(DIO_DT2821, 0, 0x40)
 * 
 * In another laboratory, this LED might be connected to bit 2 on port B
 * on a Metrabyte PIO-12 card.  It would then be defined as:
 *
 *  #define LED_FP0	Dio_id(DIO_KMPIO12, 1, 0x4)
 *
 * The following example is for 2 12 bit d/a converters:
 *
 *  #define DA_X	Dio_id(DIO_DT2821_DA, 0, 0x0)
 *  #define DA_Y	Dio_id(DIO_DT2821_DA, 1, 0x0)
 *
 * The 'bit_mask' field is ignored with the functions 'dio_out', and
 * 'dio_in'.  The d/a converter would be driven as follows:
 *
 *	    dio_out(DA_X, output_data);
 *
 * This programming interface allows the body of Spot files to remain
 * unchanged when used in different laboratories, requiring only
 * the device defines in a header to be modified.
 */
#define DIO_DID_MASK	(0xff000000)    /* device id mask and shift factor */
#define DIO_DID_SHIFT	24
#define DIO_PID_MASK	(0xff0000)	/* port id mask and shift factor */
#define DIO_PID_SHIFT	16

/*
 * Macros to assemble port selectors.
 */
#define Dio_did(x)	((((long)x) << DIO_DID_SHIFT) & DIO_DID_MASK)
#define Dio_pid(x)	((((long)x) << DIO_PID_SHIFT) & DIO_PID_MASK)
#define Dio_id(dev_id, port_id, bit_pat) \
		((Dio_did(dev_id)) | (Dio_pid(port_id)) | (bit_pat))L

/*
 * Device id's.  Must be > 0 and < 255.
 */
#define DIO_DT2821	1
#define DIO_KMPIO12	2

/*
 * The following array of structures gives specific info about
 * each device.
 */
#define DIO_IGNORE	0
#define DIO_INPORT	1   /* values for the 'dio_pinit' array below */
#define DIO_OUTPORT	2

typedef struct DIO_DEV {
    int	    dio_devid;	    /* device id for this device; array terminates
			       when this field is zero */
    int	    dio_init_flag;  /* zero when device has not been initialized */
    int	    dio_port_base;  /* port base address */
    void    (*dio_init)();  /* function to call for initialization */
    void    (*dio_access)();/* if not null, function to call for access
			       to device;  used for devices that require
			       special access procedures */
    int	    dio_portcnt;    /* number of dio ports on this device */
    u_char  dio_pinit[16];  /* for cards whose ports need to be configured
			       for input or output;  these cards usually
			       don't have more than 16 8-bit ports */
};
