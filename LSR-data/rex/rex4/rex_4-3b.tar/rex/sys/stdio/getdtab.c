/*
 * On QNX, this BSD function doesnt exist.
 */

#include <unistd.h>
#include <limits.h>
	
int
getdtablesize(void)
{
    long ltmp;
    int tmp;

    ltmp= sysconf(_SC_OPEN_MAX);
    tmp= (ltmp & 0xffff);
    return(tmp);
}
