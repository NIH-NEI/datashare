/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government.  The original
 * versions, REX 1.0-3.12, were developed for the pdp11 architecture and
 * distributed without restrictions.  This version, REX 4.0, is a port of
 * the original version to the Intel 80x86 architecture.  This version is
 * distributed only under license agreement from the National Institutes 
 * of Health, Laboratory of Sensorimotor Research, Bldg 10 Rm 10C101, 
 * 9000 Rockville Pike, Bethesda, MD, 20892, (301) 496-9375.
 *-----------------------------------------------------------------------*
 */

/*
 * Disp noun processing.
 */

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include "../hdr/sys.h"
#include "../hdr/proc.h"
#include "../hdr/buf.h"
#include "../hdr/menu.h"
#include "../hdr/matrox.h"
#include "../hdr/disp.h"


/*
 * Noun 'raster'.
 */
void
n_ras(char *vstr, char *astr)
{
	RASTH *rhp;
	int ix;
	int sav_flags;
	extern int ras_newf, ras_oldf;

	switch(*vstr) {

	case 'i':		/* init raster, hist */

		if(match("ia", vstr)) {
		    sav_flags= i_b->d_flags;
		    i_b->d_flags &= ~D_RHACT;
		    if(sav_flags & D_RASTH) {
			endact();
			clhist(NP, 1);
			if(i_b->i_flags & I_GO) begras();
			else i_b->d_flags |= (sav_flags & D_RHACT);
		    } else {
			clhist(NP, 1);
			i_b->d_flags |= (sav_flags & D_RHACT);
		    }
		} else {
			if(*astr == '\0') {
			    rxerr("n_ras(): Rast, hist number not specified");
			    break;
			}
			ix= atoi(astr);
			if(ix < 0 || ix >= conf[confnum].c_rhnum) {
			    rxerr("n_ras(): Illegal rast, hist number");
			    break;
			}
			rhp= conf[confnum].c_rhp + ix;
			ras_newf= ras_oldf= rhp->rh_flag;
			rhp->rh_flag &= ~(RH_RAST|RH_HIST);

			/*
			 * Clear current rast, hist on screen and reinit,
			 * using same function that is used when the raster
			 * menu is changed.
			 */
			rhnew(rhp, 1);
		}
		break;

	default:
		badverb();
		break;
	}
}


/*
 * Noun 'hist'.
 */
#pragma off (unreferenced)
void
n_hist(char *vstr, char *astr)
{
#pragma on (unreferenced)

	switch(*vstr) {

	case 'o':
		i_b->d_flags |= D_HISTON|D_HSIG;
		break;

	case 'e':
		i_b->d_flags &= ~D_HISTON|D_HSIG;
		break;

	default:
		badverb();
		break;
	}
}

/*
 * Noun 'dsplay'.
 */
#pragma off (unreferenced)
void
n_dsp(char *vstr, char *astr)
{
#pragma on (unreferenced)

	switch(*vstr) {

	case 'c':	/* clear matrox */
		endact();
		break;

	case 'm':	/* switch to moving (running) line */
		endact();
		i_b->d_flags |= D_RLINE;
		break;

	case 'r':	/* switch to raster display */
		if(i_b->d_flags & D_RASTH) {
			rxerr("n_dsp(): Raster is already running");
			break;
		}
		endact();
		begras();
		break;

	case 'w':	/* switch to moving window display */
		endact();
		i_b->d_flags |= D_WMOV;
		set_wind();
		go_wind();
		break;

	case 's':	/* switch to stationary window display */
		endact();
		i_b->d_flags &= ~D_WMOV;
		set_wind();
		go_wind();
		break;

	default:
		badverb();
		break;
	}
}

/*
 * Begin raster display.  This function starts raster assuming screen is
 * blank, redisplaying past units still in event buffer.
 */
void
begras(void)
{
	/*
	 * Clock must be on for raster display to start properly.
	 * Otherwise dras() will get confused searching for triggers
	 * when there are no valid times in event buffer.
	 */
	if( ! (i_b->i_flags & I_GO)) {
		rxerr("begras(): clock must be on for raster display");
		return;
	}

	i_b->d_flags |= D_RASTH|D_RHDRAW;
	loc_msg |= s_(DS_DRAS);		/* jab raster locally */
}

/*
 * End current active screen display, clear screen.
 */
void
endact(void)
{
	i_b->d_flags &= ~(D_SCACT);
	mxerase(0);
	mxwait();
	mxscroll(0);
}
