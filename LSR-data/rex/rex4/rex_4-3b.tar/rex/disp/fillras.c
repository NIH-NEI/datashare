/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government.  The original
 * versions, REX 1.0-3.12, were developed for the pdp11 architecture and
 * distributed without restrictions.  This version, REX 4.0, is a port of
 * the original version to the Intel 80x86 architecture.  This version is
 * distributed only under license agreement from the National Institutes 
 * of Health, Laboratory of Sensorimotor Research, Bldg 10 Rm 10C101, 
 * 9000 Rockville Pike, Bethesda, MD, 20892, (301) 496-9375.
 *-----------------------------------------------------------------------*
 */

/*
 * Draw raster lines and update histograms on a matrox display.
 */

#include <stdio.h>
#include <sys/types.h>
#include "../hdr/sys.h"
#include "../hdr/proc.h"
#include "../hdr/buf.h"
#include "../hdr/ecode.h"
#include "../hdr/matrox.h"
#include "../hdr/tty.h"
#include "../hdr/menu.h"
#include "../hdr/disp.h"

extern int diag;

/*
 * fillras() is passed an array of triggers from dras() to display.
 * This function was written to be time efficient and minimize function
 * calls;  accordingly it is somewhat complex and readability suffers.
 */
void
fillras(TLIST *tlp)
{
    EVENT_P ep;
    RASTH *rhp;
    BIN *bp;
    int trig_xa, oldbin, einc, bin, pass;
    int dot_xo, dorast, dohist, hscaled, hsfact, htotsf;
    int bcnt, acc;
    int shift_tmp;
    long tless, tgreat, utime, trigtime;
    EVENT_P ebufwrap, ebufnewx, trigp;
    BIN *tbp;
    char tcnt[7];
    char *ep_tcnt= &tcnt[7];
    
    for(; (trigp= tlp->tl_trig) != NP; tlp--) {			/* Level A */

if(diag) tputs("T");
	rhp= tlp->tl_rasth;

	/*
	 * Triggers earlier than r_ltime are not processed for raster
	 * display (and therefore also for hist).
	 */
	if((trigtime= tlp->tl_time) <= rhp->r_ltime) continue;
	rhp->r_ltime= trigtime;

	trig_xa= rhp->r_xadd + rhp->rh_trig_xo;		/* trig line add */
	oldbin= -1;
	hscaled= 0;			/* flag set true if hist is scaled */
	htotsf= 0;			/* total amount hist is scaled */

	/*
	 * Check if raster display needs scrolling.
	 */
	if( i_b->d_flags & D_RASTH && (rhp->rh_flag & RH_RAST)) {
		dorast= 1;
		if(rhp->r_cline_yo <= rhp->r_bot_yo) {

			/*
			 * Scroll raster.
			 */
			rscroll(rhp->r_yadd + rhp->r_bot_yo,
			  rhp->r_yadd + rhp->r_top_yo, rhp->r_dely,
			  rhp->r_xadd, rhp->r_xadd + rhp->rh_xlen);
		} else rhp->r_cline_yo -= rhp->r_dely;
	} else dorast= 0;

	/*
	 * Determine if hist is processed for this trigger.
 	 * Triggers earlier than h_ltime have already been added to histogram
	 * and are not processed.
	 */
	if(rhp->rh_flag & RH_HIST
	&& i_b->d_flags & D_HISTON
	&& trigtime > rhp->h_ltime) {
		dohist= 1;
		rhp->h_ltime= trigtime;
		rhp->h_tcnt++;
	} else dohist= 0;

	/*
	 * Each trigger is processed in three passes below.
	 */
	for(pass= 0; pass <= 2; pass++) {			/* Level B */
	    if(pass == 0) {

		/*
		 * Units before trigger.
		 */
		ep= tlp->tl_trig;
		tless= trigtime - rhp->r_tminus;
		tgreat= trigtime;
		ebufwrap= &i_b->bevent;
		ebufnewx= &i_b->bevent[EBUFNUM-1];
		einc= -1;

	    } else if(pass == 1) {

		/*
		 * Units after trigger.
		 */
		ep= tlp->tl_trig;
		tless= trigtime;
		tgreat= trigtime + rhp->r_tplus;
		ebufwrap= &i_b->bevent[EBUFNUM];
		ebufnewx= &i_b->bevent;
		einc= 1;

	    } else {

		/*
		 * Flush last histogram bin for this raster line
		 * if necessary before moving on to next trigger.
		 */
		if(oldbin >= 0) goto hflush;
		else break;
	    }

	    for(;;) {						/* Level C */
		if((ep += einc) == ebufwrap) ep= ebufnewx;
		if(ep->e_code > 0) {	/* regular event */

		    /*
		     * Check for valid unit.  Tests determine
		     * whether the time of the unit falls within the time
		     * range of the raster line, and whether search has
		     * passed the event buffer load index (evlx) or
		     * evlx has come all the way around and passed the
		     * search pointer.
		     */
		    utime= ep->e_key;		/* get time once incase evlx
						   wraps during processing */
		    if(utime < tless
		    || utime > tgreat

		    /*
		     * Next test checks for evlx comming full circle
		     * and passing trigger when searching forward on pass 1.
		     * Not useful on pass 0.
		     */
		    || trigp->e_key != trigtime) break;

		    /* Comment out stopping on init_code; see dras() also.
		    || ep->e_code & INIT_MASK) break;
		     */

		    if(ep->e_code == rhp->r_unitcode) {
			dot_xo= (utime - trigtime) >> rhp->r_sf_ms_P_dot;

			/*
			 * Raster.
			 */
			if(dorast) {
if(diag) printf("\ndot_xo %d ", dot_xo);
			  mxfast(dot_xo + trig_xa,
				rhp->r_cline_yo + rhp->r_yadd, 1);
			}

			/*
			 * Check for histogram.
			 */
			if(dohist) {

if(diag) tputs("A");
			  bin= (dot_xo + rhp->rh_trig_xo) >>
					rhp->h_sf_dots_P_bin;

			  /*
			   * If first time through for this trigger, initialize
			   * histogram temporary variables.
			   */
			  if(oldbin < 0) {
			    oldbin= bin;
			    bp= rhp->h_sbp + bin;
			    acc= (unsign) bp->b_acc;
			    bcnt= (unsign) bp->b_bcnt;
			  }

			  /*
			   * Bins are not redrawn for each unit, for there
			   * may be more than one unit per bin per raster line.
			   * The bin is redrawn only after all units that fall
			   * in it on a raster line are found.
			   */
			  if(bin != oldbin) {

			  hflush:
if(diag) tputs("B");

			    /*
			     * This unit falls in a new bin- assume that we
			     * have found all the units in the previous bin and
			     * redraw it.  Check to see if rescaling necessary.
			     * If htogether flag is true scale all histograms.
			     * Then prepare to process new bin.
			     */
			    if(bcnt >= rhp->h_btop) {
			      int rhnum, scnt;
			      RASTH *rhp_sav= rhp;

			      hscaled= 1;		/* set hscaled flag */

if(diag) tputs("C");
			      /*
			       * Erase old histogram.
			       */
			      if(i_b->d_flags & D_RASTH) {
				dhist((htogether ? NP : rhp), MXDRK);
			      }
			      
			      /*
			       * Determine amount of scaling needed.
			       */
			      hsfact= 1;
			      while((bcnt >>= 1) >= rhp->h_btop) hsfact++;
			      htotsf += hsfact;		/* add to total count */
			      if(htogether) {
				rhp= conf[confnum].c_rhp;
				rhnum= conf[confnum].c_rhnum;
			      } else {
				rhnum= 1;
			      }
			      for(; rhnum > 0; rhp++, rhnum--) {
			       for(scnt= hsfact; scnt > 0; scnt--) {

				/*
				 * Scale hist.
				 */
				if(++rhp->h_sfact > 7) {
				  rxerr("fillras(): Histogram overflow");
				  rhp->h_sfact= 7;
				}
				rhp->h_smask= shift_(rhp->h_sfact, ~0);

				/*
				 * Scale hist by dividing each bin by 2.
				 */
				for(tbp= rhp->h_sbp; tbp < rhp->h_ebp; tbp++) {
				  tbp->b_bcnt >>= 1;
				  tbp->b_bcnt &= 0177;	/* prevent sign ext */
				}
			       }
			      }
			      if(i_b->d_flags & D_RASTH) {
				if(htogether) rhp= NP;
				else rhp= rhp_sav;
				dtrig(rhp, 1, RH_HIST);
				dhist(rhp, MXBRT);
			      }
			      rhp= rhp_sav;
			    }

			    /*
			     * Draw previous bin if current display is raster.
			     */
			    if(i_b->d_flags & D_RASTH) {
				int width, xa, xend, ya_bot, ya_top, ya;

if(diag) tputs("D");
				ya_bot= ya_top= (rhp->h_bbot_yo + rhp->h_yadd);
				ya_bot= ya_bot + (unsign) bp->b_bcnt;
				ya_top += bcnt;
				if(ya_bot != ya_top) {
				  width= rhp->h_dots_P_bin;
				  xa= (oldbin << rhp->h_sf_dots_P_bin)
					+ rhp->h_xadd;
				  xend= rhp->h_xadd + rhp->rh_xlen;
if(diag) printf(" oldb %d xa %d ya_bot %d ya_top %d ", oldbin, xa, ya_bot, ya_top);
				  while(width--) {	/* draw hist bin */
				    if(xa >= xend) break;
				    mxnewx(xa++);
				    for(ya= ya_bot; ya < ya_top; ya++)
					mxonlyy(ya);
				  }
				}
			    }
if(diag) tputs("E");
			    bp->b_bcnt= bcnt;
			    bp->b_acc= acc;	/* store values for old bin */

			    /*
			     * If this is pass 2 (flush of last bin) we
			     * break to next interation of Level B which will
			     * end (since pass cnt in loop is now 2) allowing
			     * next interation of Level A to occur.
			     */
			    if(pass == 2) break;

			    /*
			     * Initializations for new bin.
			     */
if(diag) tputs("F");
			    bp= rhp->h_sbp + bin;	/* new bin pointer */
			    acc= (unsign) bp->b_acc;	/* stop sign extend! */
			    bcnt= (unsign) bp->b_bcnt;
			    oldbin= bin;
			  }

			  /*
			   * Increment bin count.
			   */
if(diag) tputs("G");
			  if(++acc & rhp->h_smask) {	/* scale */
if(diag) tputs("H");
			    bcnt += shift_((-rhp->h_sfact), acc);  /* sfact
								   can be - */
			    acc &= ~rhp->h_smask;
			  }
			}
		    }
		}
	    } /* Level C */
	} /* Level B */

	/*
	 * Update trigger count and scale factor printout on screen.
	 * Not called as a function to save run time.
	 */
	if(dohist) {
		if(i_b->d_flags & D_RASTH) {
		    char *p;
		    int xa, ya, oldtcnt, rhnum;
		    RASTH *rhp_sav= rhp;

		    if(hscaled && htogether) {
			rhp= conf[confnum].c_rhp;
			rhnum= conf[confnum].c_rhnum;
		    } else {
			rhnum= 1;
		    }
		    for(; rhnum > 0; rhp++, rhnum--) {
			xa= rhp->h_xadd + (4 * 6);
			ya= rhp->h_yadd + rhp->rh_labb_yo;
			setmxcolor(MXDRK);

			/*
			 * Save time by erasing just old numbers and not
			 * erasing entire char area.
			 * If this pass is current hist, subtract one from
			 * tcnt to get old tcnt (tcnt has been incremented
			 * for the current rast, hist at top of Level A).
			 */
			if(rhp == rhp_sav) oldtcnt= rhp->h_tcnt-1;
			else oldtcnt= rhp->h_tcnt;
			p= itoa_RL(oldtcnt, 'd', tcnt, ep_tcnt);
			*p++ = ',';
			itoa_RL((rhp->h_sfact)-htotsf, 'd', p, ep_tcnt);
			mxmove(xa, ya);
			mxtext(tcnt);
			setmxcolor(MXBRT);
			p= itoa_RL(rhp->h_tcnt, 'd', tcnt, ep_tcnt);
			*p++ = ',';
			p= itoa_RL(rhp->h_sfact, 'd', p, ep_tcnt);
			mxmove(xa, ya);
			mxtext(tcnt);
		    }
		    rhp= rhp_sav;
		}
	}
    }	/* Level A */
}
