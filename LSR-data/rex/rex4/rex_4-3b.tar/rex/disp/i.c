/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government.  The original
 * versions, REX 1.0-3.12, were developed for the pdp11 architecture and
 * distributed without restrictions.  This version, REX 4.0, is a port of
 * the original version to the Intel 80x86 architecture.  This version is
 * distributed only under license agreement from the National Institutes 
 * of Health, Laboratory of Sensorimotor Research, Bldg 10 Rm 10C101, 
 * 9000 Rockville Pike, Bethesda, MD, 20892, (301) 496-9375.
 *-----------------------------------------------------------------------*
 */

/*
 * Initializations for REX raster disp process.  Other intializations in
 * conf.c
 */

#include <stdio.h>
#include <signal.h>
#include <sys/types.h>
#include "../hdr/sys.h"
#include "../hdr/proc.h"
#include "../hdr/phys.h"
#include "../hdr/buf.h"
#include "../hdr/menu.h"
#include "../hdr/disp.h"


/*
 * Version indentifier for disp process.
 */
char version[P_LVERSION]= "4.3, 24 Nov 93";

int diag= 0;
INT_BLOCK_P i_b= 0;
PARAM param= {0};
int paramfd= 0;
PROCTBL_P myptp= NP;
BIN bins[NBINS]= {0};
TLIST tlist[TLISTNUM]= {0};
TSEARCH tsearch[RASTHNUM]= {0};
int myptx= -1;
int loc_msg= 0;
int confnum= 0;
int rwakecd= 0;
int htogether= 0;
long tsrchtime= 0;
char NS[] = "";
int error1= 0, error2= 0;
sigset_t alert_set;
