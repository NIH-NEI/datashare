/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government, is in the
 * public domain, and cannot be copywrited.  For further information
 * contact:  Laboratory of Sensorimotor Research, National Eye Institute,
 * National Institutes of Health, Bldg 10 Rm 6C420, Bethesda, MD, 20205.
 *-----------------------------------------------------------------------*
 */

/*
 * Raster, histogram configurations.
 */

#include "../hdr/sys.h"
#include "../hdr/proc.h"
#include "../hdr/buf.h"
#include "../hdr/disp.h"

/*
 * Conf0: single larger raster, hist.
 */
RASTH conf0[] = {

	{ RH_RAST|RH_HIST,	/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	500, 220,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	4, 265,			/* x, y add of lower left corner of rast */
	4, 25,			/* x, y add of lower left corner of hist */
	10,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */
};

/*
 * Conf1:  4 rast, hist each 250 dots wide.
 */
RASTH conf1[] = {

	/*
	 * RASTH 0
	 */
	{ RH_RAST|RH_HIST,	/* flags */
	0,			/* log base 2 msec per dot */
	1,			/* log base 2 dots per bin */
	250, 122,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	4, 130,			/* x, y add of lower left corner of rast */
	4, 4,			/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 1
	 */
	{ RH_RAST|RH_HIST,	/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	250, 122,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	258, 130,		/* x, y add of lower left corner of rast */
	258, 4,			/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 2
	 */
	{ RH_RAST|RH_HIST,	/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	250, 122,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	4, 386,			/* x, y add of lower left corner of rast */
	4, 260,			/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 3
	 */
	{ RH_RAST|RH_HIST,	/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	250, 122,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	258, 386,		/* x, y add of lower left corner of rast */
	258, 260,		/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */
};

/*
 * Conf2:  12 rast or hist each 165 dots wide by 123 high (3 horiz
 * 	   by 4 vert).
 */
RASTH conf2[] = {

	/*
	 * RASTH 0
	 */
	{ RH_RAST,		/* flags */
	0,			/* log base 2 msec per dot */
	1,			/* log base 2 dots per bin */
	165, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	4, 4,			/* x, y add of lower left corner of rast */
	4, 4,			/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 1
	 */
	{ RH_RAST,		/* flags */
	0,			/* log base 2 msec per dot */
	1,			/* log base 2 dots per bin */
	165, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	173, 4,			/* x, y add of lower left corner of rast */
	173, 4,			/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 2
	 */
	{ RH_RAST,		/* flags */
	0,			/* log base 2 msec per dot */
	1,			/* log base 2 dots per bin */
	165, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	342, 4,			/* x, y add of lower left corner of rast */
	342, 4,			/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 3
	 */
	{ RH_RAST,		/* flags */
	0,			/* log base 2 msec per dot */
	1,			/* log base 2 dots per bin */
	165, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	4, 131,			/* x, y add of lower left corner of rast */
	4, 131,			/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 4
	 */
	{ RH_RAST,		/* flags */
	0,			/* log base 2 msec per dot */
	1,			/* log base 2 dots per bin */
	165, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	173, 131,		/* x, y add of lower left corner of rast */
	173, 131,		/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 5
	 */
	{ RH_RAST,		/* flags */
	0,			/* log base 2 msec per dot */
	1,			/* log base 2 dots per bin */
	165, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	342, 131,		/* x, y add of lower left corner of rast */
	342, 131,		/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 6
	 */
	{ RH_RAST,		/* flags */
	0,			/* log base 2 msec per dot */
	1,			/* log base 2 dots per bin */
	165, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	4, 258,			/* x, y add of lower left corner of rast */
	4, 258,			/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 7
	 */
	{ RH_RAST,		/* flags */
	0,			/* log base 2 msec per dot */
	1,			/* log base 2 dots per bin */
	165, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	173, 258,		/* x, y add of lower left corner of rast */
	173, 258,		/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 8
	 */
	{ RH_RAST,		/* flags */
	0,			/* log base 2 msec per dot */
	1,			/* log base 2 dots per bin */
	165, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	342, 258,		/* x, y add of lower left corner of rast */
	342, 258,		/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 9
	 */
	{ RH_RAST,		/* flags */
	0,			/* log base 2 msec per dot */
	1,			/* log base 2 dots per bin */
	165, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	4, 385,			/* x, y add of lower left corner of rast */
	4, 385,			/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 10
	 */
	{ RH_RAST,		/* flags */
	0,			/* log base 2 msec per dot */
	1,			/* log base 2 dots per bin */
	165, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	173, 385,		/* x, y add of lower left corner of rast */
	173, 385,		/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 11
	 */
	{ RH_RAST,		/* flags */
	0,			/* log base 2 msec per dot */
	1,			/* log base 2 dots per bin */
	165, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	342, 385,		/* x, y add of lower left corner of rast */
	342, 385,		/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

};

/*
 * Conf3:  6 rast/hist each 165 dots wide by 123 high (3 horiz
 * 	   by 4 vert).
 */
RASTH conf3[] = {

	/*
	 * RASTH 0
	 */
	{ RH_RAST|RH_HIST,	/* flags */
	0,			/* log base 2 msec per dot */
	1,			/* log base 2 dots per bin */
	165, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	4, 131,			/* x, y add of lower left corner of rast */
	4, 4,			/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 1
	 */
	{ RH_RAST|RH_HIST,	/* flags */
	0,			/* log base 2 msec per dot */
	1,			/* log base 2 dots per bin */
	165, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	173, 131,		/* x, y add of lower left corner of rast */
	173, 4,			/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 2
	 */
	{ RH_RAST|RH_HIST,	/* flags */
	0,			/* log base 2 msec per dot */
	1,			/* log base 2 dots per bin */
	165, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	342, 131,		/* x, y add of lower left corner of rast */
	342, 4,			/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 3
	 */
	{ RH_RAST|RH_HIST,	/* flags */
	0,			/* log base 2 msec per dot */
	1,			/* log base 2 dots per bin */
	165, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	4, 385,			/* x, y add of lower left corner of rast */
	4, 258,			/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 4
	 */
	{ RH_RAST|RH_HIST,	/* flags */
	0,			/* log base 2 msec per dot */
	1,			/* log base 2 dots per bin */
	165, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	173, 385,		/* x, y add of lower left corner of rast */
	173, 258,		/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 5
	 */
	{ RH_RAST|RH_HIST,	/* flags */
	0,			/* log base 2 msec per dot */
	1,			/* log base 2 dots per bin */
	165, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	342, 385,		/* x, y add of lower left corner of rast */
	342, 258,		/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */
};

/*
 * Tics line scalings for different values of ms_P_dot.
 */
TSCALE tscale[] = {
	10, 50,		/* 1 ms_P_dot */
	5, 25,		/* 2 ms_P_dot */
	0, 25,		/* 4 ms_P_dot */
	0, 25,		/* 8 ms_P_dot */
	0, 31,		/* 16 ms_P_dot */
	0, 31,		/* 32 ms_P_dot */
};

/*
 * Initial scaling factors for histograms.  Idea:  the larger the
 * quantity msec per bin the larger the scaling factor.
 */
int sfact[2 * MAXSHF] = {
	-4,
	-3,
	-2,
	-1,
	0,
	1,
	1,
	2,
	2,
	3,
};

CONFIG conf[] = {
	&conf0, 1,		/* single raster, histogram */
	&conf1, 4,
	&conf2, 12,
	&conf3, 6,
	0, 0,			/* terminate with zeros */
};
