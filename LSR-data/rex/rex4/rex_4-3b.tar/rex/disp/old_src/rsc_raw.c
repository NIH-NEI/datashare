/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government, is in the
 * public domain, and cannot be copywrited.  For further information
 * contact:  Laboratory of Sensorimotor Research, National Eye Institute,
 * National Institutes of Health, Bldg 10 Rm 6C420, Bethesda, MD, 20205.
 *-----------------------------------------------------------------------*
 */

/*
 * Scroll raster display.
 */

#include <matroy.h>

rscroll(bot_ya, top_ya, dely, xstart, xend)
{
	register int *mp_4;
	register int yfrom_3, yto_2;
	static int line, old_0, xa_1;
	extern int *mxptr;

	mp_4= mxptr;

	/*
	 * Start at top and move down, copying line below to one above.
	 */
	for(line = top_ya, yto_2 = line, yto_2 <<= 1; ; ) {

		yfrom_3 = line;
		yfrom_3 -= dely;

		/*
		 * If bot is reached, stop copy.  Last line is cleared
		 * for new raster line.
		 */
		if(yfrom_3 <= bot_ya) break;
		line = yfrom_3;
		yfrom_3 <<= 1;		/* matrox scaling for xadd reg */

		for(xa_1= xstart; xa_1 < xend;) {

			mp_4->yr = xa_1++;
			mp_4->xr = yfrom_3;
			old_0 = mp_4->dr;
			mp_4->xr = yto_2;
			mp_4->dr = old_0;
		}

		/*
		 * Change lines.
		 */
		yto_2 = yfrom_3;
	}

	/*
	 * When copying last line clear it after copy to make room for
	 * next raster line.
	 */
	yfrom_3 <<= 1;
	for(xa_1= xstart; xa_1 < xend;) {

		mp_4->yr = xa_1++;
		mp_4->xr = yfrom_3;
		old_0 = mp_4->dr;
		mp_4->dr = 0;
		mp_4->xr = yto_2;
		mp_4->dr = old_0;
	}
}
