/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government.  The original
 * versions, REX 1.0-3.12, were developed for the pdp11 architecture and
 * distributed without restrictions.  This version, REX 4.0, is a port of
 * the original version to the Intel 80x86 architecture.  This version is
 * distributed only under license agreement from the National Institutes 
 * of Health, Laboratory of Sensorimotor Research, Bldg 10 Rm 10C101, 
 * 9000 Rockville Pike, Bethesda, MD, 20892, (301) 496-9375.
 *-----------------------------------------------------------------------*
 */

/*
 * Support routines for raster, histogram display.
 */

#include <stdio.h>
#include <sys/types.h>
#include "../hdr/sys.h"
#include "../hdr/proc.h"
#include "../hdr/buf.h"
#include "../hdr/ecode.h"
#include "../hdr/menu.h"
#include "../hdr/matrox.h"
#include "../hdr/disp.h"

extern int diag;

/*
 * Draw tic marks line.
 * If argenab is true, use argflag instead of rh_flag for each rast, hist.
 * If rhathp == NP do all rasts, hists.
 */
void
dtics(RASTH *rasthp, int argenab, int argflag)
{
    RASTH *rhp;
    int i, xtics;
    TSCALE *tsp;
    int xstart, ystart, xend, yadd, rhnum, flag;

    setmxcolor(MXBRT);

    /*
     * If rasthp is NP do all rasters, hists.
     */
    if(rasthp == NP) {
	rhp= conf[confnum].c_rhp;
	rhnum= conf[confnum].c_rhnum;
    } else {
	rhp= rasthp;
	rhnum= 1;
    }

    for(; rhnum > 0; rhp++, rhnum--) {

	if(argenab) flag= argflag;
	else flag= rhp->rh_flag;
	tsp= &tscale[rhp->r_sf_ms_P_dot];
	for(;;) {
		if(flag & RH_RAST) {
			flag &= ~RH_RAST;
			xstart= rhp->r_xadd;
			ystart= rhp->r_yadd + rhp->rh_tics_yo;
		} else if(flag & RH_HIST) {
			flag &= ~RH_HIST;
			xstart= rhp->h_xadd;
			ystart= rhp->h_yadd + rhp->rh_tics_yo;
		} else break;

		xend= xstart + (rhp->rh_xlen - 1);

		/*
		 * Draw solid horiz line.
		 */
		mxmove(xstart, ystart);
		mxvect(xend, ystart);

		/*
		 * Now add tic marks below it.
		 */
		if(tsp->ts_small) {
		  yadd= ystart - 1;
		  for(i= 0; i < SMALLSZ; i++, yadd--) {
		    mxnewy(yadd);
		    for(xtics= xstart; xtics <= xend; xtics += tsp->ts_small)
			mxonlyx(xtics);
		  }
		}
		if(tsp->ts_large) {
		  yadd= ystart - 1;
		  for(i= 0; i < LARGESZ; i++, yadd--) {
		    mxnewy(yadd);
		    for(xtics= xstart; xtics <= xend; xtics += tsp->ts_large)
			mxonlyx(xtics);
		  }
		}
	}
    }
}

/*
 * Draw raster, histogram trigger line.
 */
void
dtrig(RASTH *rasthp, int argenab, int argflag)
{
    RASTH *rhp;
    int yadd, i;
    int xadd, yend, lastrline, rhnum, flag;

    setmxcolor(MXBRT);

    /*
     * If rasthp is NP do all rasters, hists.
     */
    if(rasthp == NP) {
	rhp= conf[confnum].c_rhp;
	rhnum= conf[confnum].c_rhnum;
    } else {
	rhp= rasthp;
	rhnum= 1;
    }

    for(; rhnum > 0; rhp++, rhnum--) {

	if(argenab) flag= argflag;
	else flag= rhp->rh_flag;
	rhp->rh_trig_xo= (rhp->rh_xlen >> 1) + (rhp->r_trigtoff >>
							rhp->r_sf_ms_P_dot);
	if(flag & RH_RAST) {
		rhp->r_tplus= (rhp->rh_xlen - rhp->rh_trig_xo -1)
						<< rhp->r_sf_ms_P_dot;
		rhp->r_tminus= rhp->rh_trig_xo << rhp->r_sf_ms_P_dot;
		xadd= rhp->r_xadd + rhp->rh_trig_xo;
		yadd= rhp->r_yadd + rhp->rh_tics_yo + 1;
		yend= rhp->r_yadd + rhp->rh_ylen;

		/*
		 * Initialize the r_top_yo and r_bot_yo fields also.
		 */
		rhp->r_bot_yo= rhp->rh_tics_yo + rhp->r_dely;
		mxnewx(xadd);
		i= 0;
		rhp->r_nlines= 0;
		for(; yadd < yend; yadd++) {
			if(++i == rhp->r_dely) {
				i= 0;
				lastrline= yadd;
				rhp->r_nlines++;
				continue;
			}
			mxonlyy(yadd);
		}
		rhp->r_top_yo= lastrline - rhp->r_yadd;

		/*
		 * fillras() decrements cline before using, so initialize
		 * it to one line above the top.
		 */
		rhp->r_cline_yo= rhp->r_top_yo + rhp->r_dely;

	}
	if(flag & RH_HIST) {
		xadd= rhp->h_xadd + rhp->rh_trig_xo;
		yadd= rhp->h_yadd + rhp->rh_tics_yo + 1;
		yend= rhp->h_yadd + rhp->rh_ylen;
		rhp->h_bbot_yo= rhp->rh_tics_yo + 1;
		rhp->h_btop= rhp->rh_ylen - rhp->h_bbot_yo;
		mxnewx(xadd);
		for(; yadd < yend; yadd++)
			mxonlyy(yadd);
	}
    }
}

/*
 * Draw raster, histogram ascii labels.
 */

#define LABELSZ 25

void
dlabel(RASTH *rasthp, int argenab, int argflag)
{
    RASTH *rhp;
    char *p;
    char laba[LABELSZ], labb[LABELSZ];
    int rhnum, flag;

    setmxcolor(MXBRT);
    mxsize(1);

    /*
     * If rasthp is NP do all rasters, hists.
     */
    if(rasthp == NP) {
	rhp= conf[confnum].c_rhp;
	rhnum= conf[confnum].c_rhnum;
    } else {
	rhp= rasthp;
	rhnum= 1;
    }

    for(; rhnum > 0; rhp++, rhnum--) {

	if(argenab) flag= argflag;
	else flag= rhp->rh_flag;

	/*
	 * Clear strings by putting in spaces.
	 */
	for(p= laba; p < &laba[LABELSZ]; *p++ = ' ');
	for(p= labb; p < &labb[LABELSZ]; *p++ = ' ');

	/*
	 * Do laba first;  same for both rast and hist.
	 */
	p= itoa_RL(rhp - conf[confnum].c_rhp, 'd', laba, &laba[LABELSZ]);
	*p= ' ';
	p= stufs("t=", &laba[4], &laba[LABELSZ]);
	p= itoa_RL(rhp->rh_trig, 'd', p, &laba[LABELSZ]);
	*p= ' ';
	p= stufs("fs=", &laba[11], &laba[LABELSZ]);
	p= itoa_RL(rhp->rh_xlen << rhp->r_sf_ms_P_dot, 'd', p, &laba[LABELSZ]);
	stufs("ms", p, &laba[LABELSZ]);
	p= stufs("tic=", &labb[11], &labb[LABELSZ]);
	p= itoa_RL(tscale[rhp->r_sf_ms_P_dot].ts_large << rhp->r_sf_ms_P_dot, 'd',
			p, &labb[LABELSZ]);
	stufs("ms", p, &labb[LABELSZ]);

	if(flag & RH_RAST) {
		p= stufs("dots=", labb, &labb[LABELSZ]);
		p= itoa_RL(rhp->rh_xlen, 'd', p, &labb[LABELSZ]);
		*p= ' ';
		mxmove(rhp->r_xadd, rhp->r_yadd + rhp->rh_laba_yo);
		mxtext(laba);
		mxmove(rhp->r_xadd, rhp->r_yadd + rhp->rh_labb_yo);
		mxtext(labb);
	}
	if(flag & RH_HIST) {
		p= stufs("cnt=     ", labb, &labb[LABELSZ]);
		*p= ' ';
		p= itoa_RL(rhp->h_tcnt, 'd', &labb[4], &labb[LABELSZ]);
		*p++ = ',';
		p= itoa_RL(rhp->h_sfact, 'd', p, &labb[LABELSZ]);
		*p= ' ';
		mxmove(rhp->h_xadd, rhp->h_yadd + rhp->rh_laba_yo);
		mxtext(laba);
		mxmove(rhp->h_xadd, rhp->h_yadd + rhp->rh_labb_yo);
		mxtext(labb);
	}
    }
}

/*
 * Fill in histogram.
 */
void
dhist(RASTH *rasthp, int color)
{
    RASTH *rhp;
    BIN *bp;
    int yadd;
    int xadd, xend, ystart, width, topy, rhnum;

    setmxcolor(color);

    /*
     * If rasthp is NP do all hists.
     */
    if(rasthp == NP) {
	rhp= conf[confnum].c_rhp;
	rhnum= conf[confnum].c_rhnum;
    } else {
	rhp= rasthp;
	rhnum= 1;
    }

    for(; rhnum > 0; rhp++, rhnum--) {

	if( ! (rhp->rh_flag & RH_HIST)) continue;
	xadd= rhp->h_xadd;
	xend= rhp->h_xadd + rhp->rh_xlen;
	ystart= rhp->h_yadd + rhp->h_bbot_yo;
	for(bp= rhp->h_sbp; bp < rhp->h_ebp; bp++) {

		if(bp->b_bcnt == 0) {
			xadd += rhp->h_dots_P_bin;
			continue;
		}
		topy= ystart + (unsign) bp->b_bcnt;
		for(width= rhp->h_dots_P_bin; width > 0; width--) {
			if(xadd >= xend) break;
			mxnewx(xadd++);
			for(yadd= ystart; yadd < topy; yadd++)
				mxonlyy(yadd);
		}
	}
    }
    setmxcolor(MXBRT);
}

/*
 * Clear histogram bins and initialize times.  If tinit is true,
 * r_ltime, h_ltime, and rh_itime are set to current time (triggers 
 * before current time will not be processed).  If tinit is false,
 * r_ltime, h_ltime will be reset to rh_itime to allow rast, hist to
 * be redisplayed with units remaining in event buffer (applicable
 * after variables in raster menus are changed).
 */
void
clhist(RASTH *rasthp, int tinit)
{
    RASTH *rhp;
    BIN *bp;
    int rhnum;
    int shift_tmp;

    if(rasthp == NP) {
	rhp= conf[confnum].c_rhp;
	rhnum= conf[confnum].c_rhnum;
    } else {
	rhp= rasthp;
	rhnum= 1;
    }

    for(; rhnum > 0; rhp++, rhnum--) {

	/*
	 * Take a shot at a good initial scaling factor.
	 */
	if(rhp->h_autosel) {
		rhp->h_sfact= sfact[rhp->h_sf_dots_P_bin];
	} else rhp->h_sfact= rhp->h_isfact;
	rhp->h_smask= shift_(rhp->h_sfact, ~0);
	rhp->h_tcnt= 0;
	if(tinit) rhp->rh_itime= rhp->h_ltime= rhp->r_ltime= i_b->i_time;
	else {
		rhp->h_ltime= rhp->r_ltime= rhp->rh_itime;
		tsrchtime= 0;	/* allow past triggers to be redisplayed */
	}
	for(bp= rhp->h_sbp; bp < rhp->h_ebp; bp++) {
		bp->b_bcnt= 0;
		bp->b_acc= 0;
	}
    }
}

/*
 * Initializations for new configuration.
 */
int
cinit(void)
{
	BIN *bp, *ebp;
	RASTH *rhp;
	TSEARCH *sp;
	int rhnum;

	rhp= conf[confnum].c_rhp;
	rhnum= conf[confnum].c_rhnum;
	if(rhnum > RASTHNUM) {
		rxerr("cinit(): Conf has too many rast,hists");
		return(1);
	}

	/*
	 * Allocate hist bins assuming smallest bin width of 1 dot_P_bin.
	 */
	ebp= &bins[NBINS];
	bp= &bins;
	for(; rhnum > 0; rhp++, rhnum--) {
		rhp->h_sbp= bp;
		bp += rhp->rh_xlen;
		if(bp >= ebp) {
			rxerr("cinit(): Out of hist bins to allocate");
			return(1);
		}
		rhp->h_ebp= bp;
	}

	/*
	 * Clear hist bins.
	 */
	clhist(NP, 1);

	/*
	 * Zero tsearch array.
	 */
	for(sp= &tsearch; sp < &tsearch[RASTHNUM]; sp++) {
		sp->ts_trig= 0;
		sp->ts_rhp= NP;
	}
	return(0);
}

/*
 * Initializations needed after parameters changed in RASTHs.
 */
int
rhinit(RASTH *rasthp)
{
    RASTH *rhp;
    TSEARCH *sp;
    int rhnum;
    int maxtoff, rfact;

    if(rasthp == NP) {
	rhp= conf[confnum].c_rhp;
	rhnum= conf[confnum].c_rhnum;
    } else {
	rhp= rasthp;
	rhnum= 1;
    }

    for(; rhnum > 0; rhp++, rhnum--) {
	if( rhp->r_sf_ms_P_dot < 0 || rhp->r_sf_ms_P_dot > MAXSHF
	|| rhp->h_sf_dots_P_bin < 0 || rhp->h_sf_dots_P_bin > MAXSHF) {
		rxerr("rhinit(): Bad ms_P_dot or dots_P_bin");
		return(1);
	}
	rhp->r_ms_P_dot= 01 << rhp->r_sf_ms_P_dot;
	rhp->h_dots_P_bin= 01 << rhp->h_sf_dots_P_bin;
	maxtoff= (rhp->rh_xlen >> 1) << rhp->r_sf_ms_P_dot;
	if(rhp->r_trigtoff > maxtoff
	|| rhp->r_trigtoff < -maxtoff) {
		rxerr("rhinit(): Trigger time offset too large");
		return(1);
	}

	/*
	 * Init tsearch array for this RASTH.
	 */
	sp= &tsearch[rhp - conf[confnum].c_rhp];
	sp->ts_trig= rhp->rh_trig;
	sp->ts_rhp= rhp;

	/*
	 * Init ending bin pointer based on dots_P_bin.
	 * Round up.
	 */
	rfact= (01 << rhp->h_sf_dots_P_bin) - 1;
	rhp->h_ebp= rhp->h_sbp + ( (rhp->rh_xlen + rfact) >>
					rhp->h_sf_dots_P_bin);
    }
    return(0);
}

/*
 * Directly erase specified rectangular section of matrox without affecting
 * rest of screen.
 */
void
derase(int x, int xlen, int y, int ylen)
{
	int xend= x + xlen;
	int yend= y + ylen;
	int ytmp= y;

	for(; x < xend; x++) {
	    for(ytmp= y; ytmp < yend; ytmp++) {
		mxfast(x, ytmp, MXDRK);
	    }
	}
}
