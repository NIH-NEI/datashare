/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government.  The original
 * versions, REX 1.0-3.12, were developed for the pdp11 architecture and
 * distributed without restrictions.  This version, REX 4.0, is a port of
 * the original version to the Intel 80x86 architecture.  This version is
 * distributed only under license agreement from the National Institutes 
 * of Health, Laboratory of Sensorimotor Research, Bldg 10 Rm 10C101, 
 * 9000 Rockville Pike, Bethesda, MD, 20892, (301) 496-9375.
 *-----------------------------------------------------------------------*
 */

#include <sys/types.h>
#include <stdlib.h>
#include <stdio.h>
#include "../hdr/sys.h"
#include "../hdr/proc.h"
#include "../hdr/buf.h"
#include "../hdr/menu.h"
#include "../hdr/matrox.h"
#include "../hdr/disp.h"

/*
 * Menus, nouns for display.  This file is a good example of the use of the
 * REX menu system, for display uses most its features.
 */

/*
 *-----------------------------------------------------------------------
 * Access functions, etc. for menus.
 *-----------------------------------------------------------------------
 */

/*
 * Raster configuration access function.
 */
#pragma off (unreferenced)
int
conf_vaf(int flag, MENU *mp, char *astr, VLIST *vlp, int *tvadd)
{
#pragma on (unreferenced)
	int confx, sav_flags;
	
	/*
	 * Check for legal conf number.
	 */
	if(flag & ME_BEF) {
		for(confx= 0; confx <= *tvadd; confx++) {
		    if(conf[confx].c_rhp == NP) {
			rxerr("conf_vaf(): Illegal conf number");
			return(-1);
		    }
		}
		return(0);		/* value ok */
	}

	/*
	 * Changing configuration number requires
	 * reinitializing entire raster, hist display.
	 */
	sav_flags= i_b->d_flags;
	i_b->d_flags &= ~D_RHACT;
	if(cinit() || rhinit(NP)) return(-1);
	if(sav_flags & D_RASTH) {
		endact();
		if(i_b->i_flags & I_GO) begras();
		else i_b->d_flags |= (sav_flags & D_RHACT);
	} else i_b->d_flags |= (sav_flags & D_RHACT);
	return(0);
}

/*
 * Raster, hist parameter variable access function.
 * The menu access function, ras_maf(), must know if any of the variables
 * are actually changed and take appropriate action.  This function sets
 * a flag for ras_maf() when a variable is changed.
 */
int ras_change, ras_oldf, ras_newf;

#pragma off (unreferenced)
int
ras_vaf(int flag, MENU *mp, char *astr, VLIST *vlp, int *tvadd)
{
#pragma on (unreferenced)
	RASTH *rhp;

	/*
	 * When these variables are changed this rast, hist must be
	 * turned off.  Clearing these flags prevents dras() from
	 * loading its trigger.
	 */
	rhp= (RASTH *)mp->me_basep;
	rhp->rh_flag &= ~(RH_RAST|RH_HIST);
	ras_change= 1;
	return(0);
}

/*
 * Raster, hist parameter menu access function.
 */
#pragma off (unreferenced)
int
ras_maf(int flag, MENU *mp, char *astr, VLIST *vlp, int *tvadd)
{
#pragma on (unreferenced)
	int mx;
	RASTH *rhp;

	if(flag & ME_BEF) {

		/*
		 * Set up global base pointer for this menu access.
		 */
		if(*astr == '\0') mx= 0;
		else mx= atoi(astr);
		if(mx < 0 || mx >= conf[confnum].c_rhnum) {
			rxerr("ras_maf(): Bad menu number");
			return(-1);
		}
		rhp= conf[confnum].c_rhp + mx;
		mp->me_basep= (unsign)rhp;
		ras_change= 0;

		/*
		 * Save old value of flag in case it is changed.
		 * Place current value in menu variable.
		 */
		ras_newf= ras_oldf= rhp->rh_flag;
		return(0);
	}

	/*
	 * If any variables have been changed, ras_change will be true.  This
	 * rast, hist then must be re-intitialized.
	 * Dont, however, initialize h_ltime, r_ltime to present time.
	 * Let them revert to rh_itime and redisplay past units still
	 * in event buffer with new parameters.
	 */
	if(ras_change) rhnew((RASTH *)mp->me_basep, 0);
	return(0);
}

/*
 * Clear rast, hist and initialize with new parameters.
 * Globl vars ras_newf and ras_oldf must be appropiately set.
 * If tinit is true, rh_itime, h_ltime, r_time will be set to present
 * time and only subsequent units will be added to rast, hist.
 */
void
rhnew(RASTH *rhp, int tinit)
{
	  clhist(rhp, tinit);		/* clear out this RASTHs hist */
	  if(rhinit(rhp) == 0) {
	    if(i_b->d_flags & D_RASTH) {
		if(conf[confnum].c_rhnum > 1) {
		    if(ras_oldf & RH_RAST)
			derase(rhp->r_xadd, rhp->rh_xlen, rhp->r_yadd,
						rhp->rh_ylen);
		    if(ras_oldf & RH_HIST)
			derase(rhp->h_xadd, rhp->rh_xlen, rhp->h_yadd,
						rhp->rh_ylen);
		} else {
			mxerase(0);
			mxwait();		/* when only one faster */
		}
		dtics(rhp, 1, ras_newf);
		dtrig(rhp, 1, ras_newf);
		dlabel(rhp, 1, ras_newf);

		/*
		 * Jab dras().
		 */
		rhp->rh_flag= ras_newf;
		if(i_b->i_flags & I_GO) loc_msg |= s_(DS_DRAS);
	    } else rhp->rh_flag= ras_newf;
	  }
}

/*
 * Raster, hist menu root argument generation function.  The purpose of this
 * function is to generate ascii strings that correspond to the
 * argument strings that would be used to access all the rast, hist menus
 * of a given configuration.  If a certain config has 10 rast, hist menus this
 * function would generate 10 strings composed of the numbers '0' thru '9';
 * mkroot() would then use these strings to access all the menus to write them
 * out on the root file.
 */
#pragma off (unreferenced)
int
ras_agf(int call_cnt, MENU *mp, char *astr)
{
#pragma on (unreferenced)

	if(call_cnt >= conf[confnum].c_rhnum) {

		/*
		 * Done.  Return null to terminate writing of root for
		 * this menu.
		 */
		*astr= '\0';
	} else itoa_RL(call_cnt, 'd', astr, &astr[P_ISLEN]);
	return(0);
}

/*
 *-----------------------------------------------------------------------
 * Noun, menu tables for display.
 *-----------------------------------------------------------------------
 */

/*
 * Noun table.
 */
NOUN nouns[] = {
	"dsplay", 	&n_dsp,
	"hist",		&n_hist,
	"raster",	&n_ras,
	"",
};

/*
 * Dsplay menu vlist.
 */
extern error1, error2;
extern diag;
extern doutput_inmem;
extern doutput_rot;

VLIST ds_vl[] = {
"ras_config_num",	&confnum, NP, conf_vaf, ME_BEF|ME_AFT, ME_DEC,
"hist_scale_together",	&htogether, NP, NP, 0, ME_DEC,
"ras_wakeup_ecode",	((char *)&((INT_BLOCK *)NP)->d_rwakecd -
				(char *)&((INT_BLOCK *)NP)->INT_BLOCK_FIRST),
			NP, NP, ME_IBLOCK, ME_DEC,
"doutput_inmem",	&doutput_inmem, NP, NP, 0, ME_DEC,
"doutput_rotate",	&doutput_rot, NP, NP, 0, ME_DEC,
"error1",		&error1, NP,NP,0,ME_DEC,
"error2",		&error2, NP,NP,0,ME_DEC,
"diag",			&diag, NP, NP, 0, ME_DEC,
NS,
};

/*
 * Individual rast, hist vlist.
 */
VLIST ras_vl[] = {
"control_flag",		&ras_newf, NP, ras_vaf, ME_BEF, ME_DEC,
"ms_per_dot_sf",	&((RASTH *)NP)->r_sf_ms_P_dot, NP, ras_vaf,
			    ME_BEF|ME_GB, ME_DEC,
"dots_P_bin_sf",	&((RASTH *)NP)->h_sf_dots_P_bin, NP, ras_vaf,
			    ME_BEF|ME_GB, ME_DEC,
"trigger_ecode",	&((RASTH *)NP)->rh_trig, NP, ras_vaf, ME_BEF|ME_GB,
			    ME_DEC,
"trigger_time_off",	&((RASTH *)NP)->r_trigtoff, NP, ras_vaf,
			    ME_BEF|ME_GB, ME_DEC,
"unit_code",		&((RASTH *)NP)->r_unitcode, NP, ras_vaf,
			    ME_BEF|ME_GB, ME_DEC,
"hist_sc_auto_sel",	&((RASTH *)NP)->h_autosel, NP, ras_vaf,
			    ME_BEF|ME_GB, ME_DEC,
"hist_init_scale",	&((RASTH *)NP)->h_isfact, NP, ras_vaf,
			    ME_BEF|ME_GB, ME_DEC,
NS,
};

char hm_ds_vl[] = "\
ras_config_num-\n\
  0: 1 rast/hist\n\
  1: 2 rast\n\
  2: 4 rast/hist\n\
  3: 8 rast\n\
  4: 6 rast/hist\n\
  5: 12 rast\n\
  6: 8 rast/hist\n\
  7: 16 rast\n\
  8: 6 rast,\n\
     2 rast/hist\n\
New config takes effect\n\
when menu is exited.";

char hm_ras_vl[] = "\
Changes won't occur until menu\n\
is exited.\n\
control_flag-\n\
  0: rast, hist off\n\
  1: rast only\n\
  2: hist only\n\
  3: both rast, hist\n\
'_sf' signifies power of 2\n\
shift factors- 1,2,4,8...";

/*
 * Menu list for display.
 */
MENU menus[] = {
"dsplay",		&ds_vl, NP, NP, 0, NP, hm_ds_vl,
"raster",		&ras_vl,NP,ras_maf,ME_BEF|ME_AFT,ras_agf,hm_ras_vl,
NS,
};
