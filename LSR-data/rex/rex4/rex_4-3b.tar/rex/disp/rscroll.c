/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government.  The original
 * versions, REX 1.0-3.12, were developed for the pdp11 architecture and
 * distributed without restrictions.  This version, REX 4.0, is a port of
 * the original version to the Intel 80x86 architecture.  This version is
 * distributed only under license agreement from the National Institutes 
 * of Health, Laboratory of Sensorimotor Research, Bldg 10 Rm 10C101, 
 * 9000 Rockville Pike, Bethesda, MD, 20892, (301) 496-9375.
 *-----------------------------------------------------------------------*
 */

/*
 * Scroll raster display.
 */

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include "../hdr/sys.h"
#include "../hdr/proc.h"
#include "../hdr/buf.h"
#include "../hdr/menu.h"
#include "../hdr/matrox.h"
#include "../hdr/disp.h"

void
rscroll(int bot_ya, int top_ya, int dely, int xstart, int xend)
{
	int yfrom, yto;
	int x;

	/*
	 * Start at top and move down, copying line below to one above.
	 */
	for(yfrom= top_ya, yto= top_ya; yfrom > bot_ya;
		    yto=yfrom, yfrom -= dely) {

		for(x= xstart; x < xend; x++) {
		        mxnewx(x);
			mxnewy(yfrom);
			mxfast(x, yto, mxread());
		}
	}

	/*
	 * When copying last line clear it after copy to make room for
	 * next raster line.
	 */
	for(x= xstart; x < xend; x++) {
		mxnewx(x);
		mxnewy(yfrom);
		mxfast(x, yto, mxread());
		mxfast(x, yfrom, MXDRK);
	}
}
