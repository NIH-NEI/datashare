/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government.  The original
 * versions, REX 1.0-3.12, were developed for the pdp11 architecture and
 * distributed without restrictions.  This version, REX 4.0, is a port of
 * the original version to the Intel 80x86 architecture.  This version is
 * distributed only under license agreement from the National Institutes 
 * of Health, Laboratory of Sensorimotor Research, Bldg 10 Rm 10C101, 
 * 9000 Rockville Pike, Bethesda, MD, 20892, (301) 496-9375.
 *-----------------------------------------------------------------------*
 */

/*
 * Disp interprocess communication.
 */

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <signal.h>
#include "../hdr/sys.h"
#include "../hdr/proc.h"
#include "../hdr/buf.h"
#include "../hdr/tty.h"
#include "../hdr/menu.h"
#include "../hdr/matrox.h"
#include "../hdr/disp.h"

#define NVMASK	(s_(G_NMEXEC))	/* allow everything (but myself) to re-interrupt
				   noun,menu processing */
extern sigset_t	alert_set;

#pragma off (unreferenced)
void
alert(int sig)
{
#pragma on (unreferenced)

	PROCTBL_P p= &i_b->ptbl[myptx];
	u_int msg, restormask;
	int (*func)();
	int nindex;
	char vstr[P_ISLEN], astr[P_ISLEN];
	extern ME_ACCP me_accp;

	if(p->p_state & P_ALRTBSY_ST) return;
	p->p_state |= P_ALRTBSY_ST;

newscan:
	protect(&p->p_sem);

	/*
	 * An easy way for process to send messages to itself without using
	 * sendmsg(), providing the process doesn't need to interrupt itself
	 * by sending itself a signal.  Used by begras().
	 */
	if(loc_msg) {
		p->p_msg |= loc_msg;
		loc_msg= 0;
	}
	msg= p->p_msg & ~p->p_rmask;	/* mask with priority level */
	if(msg == 0) {

		/*
		 * Alert must return from here only.
		 */
		p->p_state &= ~(P_NOSIG_ST|P_ALRTBSY_ST);
		release_(&p->p_sem);
		return;

	} else if(msg & s_(G_KILL)) {
		p->p_msg &= ~s_(G_KILL);
		release_(&p->p_sem);
		p->p_state |= P_EXIT_ST;
		mxinit(0);
		exit(0);

	} else if(msg & s_(G_STOP)) {		
		p->p_msg &= ~s_(G_STOP);
		release_(&p->p_sem);
		i_b->d_flags &= ~D_ALLACT;
		i_b->disp_pi= -1;		/* no disp process now */

		/*
		 * If currently reading a root, close root.
		 */
		if(infd != 0) rt_close();
		sendmsg(COMM, CM_AFFIRM);

	} else if(msg & s_(G_RUN)) {
		p->p_msg &= ~s_(G_RUN);
		release_(&p->p_sem);
		if(i_b->disp_pi > 0) {
			rxerr("alert(): A disp process is already running");
			sendmsg(COMM, CM_NEG);
			goto newscan;
		}
		i_b->disp_pi= myptx;		/* I am now the disp process */

		/*
		 * If started from a root file, open root.
		 */
		if(i_b->i_rtflag & RT_READ) rt_read();
		sendmsg(COMM, CM_AFFIRM);

	} else if(msg & s_(G_RTEXEC)) {
		p->p_msg &= ~s_(G_RTEXEC);
		release_(&p->p_sem);

		if(i_b->i_rtflag & RT_READ) rt_read();
		else if(i_b->i_rtflag & RT_WMENU) rt_write();
		else if(i_b->i_rtflag & RT_CLOSE) rt_close();
		sendmsg(COMM, CM_AFFIRM);

	} else if(msg & s_(G_NMEXEC)) {
		p->p_msg &= ~s_(G_NMEXEC);
#ifdef NEED_FAR
		_fstufs(i_b->i_verbs, vstr, &vstr[P_ISLEN]);
		_fstufs(i_b->i_args, astr, &astr[P_ISLEN]);
#else
		stufs(i_b->i_verbs, vstr, &vstr[P_ISLEN]);
		stufs(i_b->i_args, astr, &astr[P_ISLEN]);
#endif
		nindex= i_b->i_nindex;
		i_b->i_nindex= 0;

		/*
		 * Prepare to allow re-interrupts.
		 */
		restormask= (p->p_rmask ^ NVMASK) & NVMASK;
		p->p_rmask |= NVMASK;
		p->p_state &= ~(P_NOSIG_ST|P_ALRTBSY_ST|P_EARLYWAKE_ST);
		release_(&p->p_sem);
		if(sigprocmask(SIG_UNBLOCK, &alert_set, NULL) == -1)
		    rxerr("alert(): cannot sigprocmask");

		if(*vstr == '\0') access_m(&me_accp, &menus[nindex], astr);
		else {
			func= nouns[nindex].n_ptr;
			(*func)(vstr, astr);
		}

		/*
		 * Comm may have already been awakened by noun,menu.  If
		 * not, awaken it.
		 */
		if( ! (p->p_state & P_EARLYWAKE_ST))
			sendmsg(COMM, CM_AFFIRM);

		/*
		 * Disable re-interrupts and restore pri mask.
		 */
		if(sigprocmask(SIG_BLOCK, &alert_set, NULL) == -1)
		    rxerr("alert(): cannot sigprocmask");
		p->p_state |= (P_NOSIG_ST|P_ALRTBSY_ST);
		p->p_rmask &= ~restormask;

	} else if(msg & s_(DS_DRAS)) {
		p->p_msg &= ~s_(DS_DRAS);
		release_(&p->p_sem);
		if( ! (i_b->d_flags & D_RHACT)) goto newscan;

		/*
		 * Note that msg DS_DRAS might come while display is
		 * processing a noun, verb.  Therefore care must be
		 * taken in noun, verb processing to prevent problems
		 * due to re-interrupts by the DS_DRAS message.
		 * In most cases the D_RHACT bits are cleared before entering
		 * critical sections during noun, verb processing.  (Rast, hist
		 * processing cannot be interrupted by noun, verb messages).
		 *
		 * When called, dras() will assemble and process a list of
		 * past event triggers from the current event load index and
		 * return.  A newscan for messages then occurs.  Noun, verbs are
		 * processed before this message so that they will get an
		 * opportunity to execute when runtime is short and the
		 * rast, hist display might run continuously.  Note
		 * however if DS_DRAS interrupts noun, verb processing
		 * there is no guarantee the noun, verb procssing will resume
		 * if rast, hist processing cannot catch up.  In this case
		 * the paradigm could be stopped to allow time for rast, hist
		 * processing to finish.
		 */
		dras();

	} else if(msg & s_(DS_WDNEW)) {
		p->p_msg &= ~s_(DS_WDNEW);
		release_(&p->p_sem);
		if(i_b->d_flags & D_WIND) {
			endact();
			set_wind();
			go_wind();
		}

	} else {		/* bad msg */
		p->p_msg &= ~msg;
		release_(&p->p_sem);
		rxerr("alert(): Disp received illegal message");
	}

	goto newscan;
}
