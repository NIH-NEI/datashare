/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government.  The original
 * versions, REX 1.0-3.12, were developed for the pdp11 architecture and
 * distributed without restrictions.  This version, REX 4.0, is a port of
 * the original version to the Intel 80x86 architecture.  This version is
 * distributed only under license agreement from the National Institutes 
 * of Health, Laboratory of Sensorimotor Research, Bldg 10 Rm 10C101, 
 * 9000 Rockville Pike, Bethesda, MD, 20892, (301) 496-9375.
 *-----------------------------------------------------------------------*
 */

/*
 * Disp process main.
 */

#include <sys/types.h>
#include <sys/wait.h>
#include <process.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <setjmp.h>
#include <signal.h>
#include "../hdr/sys.h"
#include "../hdr/phys.h"
#include "../hdr/proc.h"
#include "../hdr/buf.h"
#include "../hdr/tty.h"
#include "../hdr/menu.h"
#include "../hdr/disp.h"
#include "../hdr/matrox.h"

jmp_buf env= {0};
extern char version[];
extern sigset_t	alert_set;

#pragma off (unreferenced)
main(int argc, char *argv[])
{
#pragma on (unreferenced)

#ifdef GOO
	setbuf(stdout, NULL);
#endif

	/*
	 * Get paramfile and map INT_BLOCK.
	 */
	paramfd = atoi(argv[1]);
	getparam(paramfd, &param);
	if((i_b= (INT_BLOCK_P)padr_map(&param.i_bl)) == -1) {
		fprintf(stderr, "Comm: cannot map INT_BLOCK\n");
		exit(1);
	}

	myptx= atoi(argv[2]);
	myptp= &i_b->ptbl[myptx];
#ifdef NEED_FAR
	_fstufs(version, myptp->p_version, &myptp->p_version[P_LVERSION]);
#else
	stufs(version, myptp->p_version, &myptp->p_version[P_LVERSION]);
#endif

	sigemptyset(&alert_set);
	sigaddset(&alert_set, S_ALERT);	    /* set up signal mask for alert */
	signal(S_CNTRLC, SIG_IGN);
	signal(S_CNTRLB, oncntrlb);
	signal(S_ALERT, alert);
	signal(S_DEBUG_PRINT, doutput);
	i_b->d_flags |= D_RLINE|D_HISTON;
	sendname(myptp, nouns, menus);

	/*
	 * Set up matrox.
	 */
	mxinit(1);
	mxscroll(0);
	setmxcolor(MXBRT);
	mxerase(0);
	mxwait();

	/*
	 * Initialize default configuration.
	 */
	cinit();
	rhinit(NP);

	/*
	 * Check if invoked from a root file.
	 */
	if(i_b->i_rtflag & RT_READ) rt_read();

	setjmp(env);
	for(;;) sleep(16000);
}

/*
 * On cntlb reset interprocess communication to a default state.
 */
void
#pragma off (unreferenced)
oncntrlb(int sig)
{
#pragma on (unreferenced)
	PROCTBL_P p;

	signal(S_CNTRLB, oncntrlb);
	p= myptp;
	p->p_state |= P_NOSIG_ST;		/* prevent IPC */
	sleep(1);			/* let comm run first */
	p->p_msg= p->p_vindex= p->p_rmask= 0;
	p->p_sem= HIGHBIT;
	p->p_state &= ~P_NOSIG_ST;
	longjmp(env, 0);
}
