/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government.  The original
 * versions, REX 1.0-3.12, were developed for the pdp11 architecture and
 * distributed without restrictions.  This version, REX 4.0, is a port of
 * the original version to the Intel 80x86 architecture.  This version is
 * distributed only under license agreement from the National Institutes 
 * of Health, Laboratory of Sensorimotor Research, Bldg 10 Rm 10C101, 
 * 9000 Rockville Pike, Bethesda, MD, 20892, (301) 496-9375.
 *-----------------------------------------------------------------------*
 */

/*
 * Initializations for window display.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include "../hdr/sys.h"
#include "../hdr/proc.h"
#include "../hdr/buf.h"
#include "../hdr/menu.h"
#include "../hdr/matrox.h"
#include "../hdr/cdsp.h"
#include "../hdr/disp.h"

/*
 * Definitions for scales.  Indexed by magnification number:
 * 0: 204.8 degs/full scale, 1: 102.4 degs/full scale, etc.
 */
typedef struct {
	int	dots_tic;	/* dots per tic mark */
	int	degs_tic;	/* degrees per tic mark */
} SCALE;

SCALE eyescale[MAXMAG] = {
	{50, 20},	/* mag 0 */
	{50, 10},	/* mag 1 */
	{50, 5},	/* mag 2 */
	{40, 2},	/* mag 3 */
	{40, 1},	/* mag 4 */
	{80, 1},	/* mag 5 */
};


/*
 * Set up screen for window display.  Screen is always cleared before
 * this function is called.
 */
void
set_wind(void)
{
	char str1[]= "HORIZ EYE OFFSET";
	char str2[]= "VERT EYE OFFSET";

	setmxcolor(MXBRT);
	mxsize(1);

	set_axis();
	mxhtext(str1, WDI_XCEN-((sizeof(str1)/2)*WDI_HTXT), WDI_TOP-WDI_VTXT);
	mxvtext(str2, WDI_RIGHT-WDI_HTXT, WDI_YCEN+((sizeof(str2)/2)
						    * WDI_VTXT));

}

/*
 * Draw axis and tic marks.
 */
void
set_axis(void)
{
	SCALE *ep, *op;
	
	ep= &eyescale[i_b->d_emag];
	op= &eyescale[i_b->d_omag];
	
	/*
	 * Draw frame.
	 */
	if(i_b->d_wd_disp & D_W_FRAME) {	 
		mxmove(WDI_LEFT, WDI_BOT);
		mxvect(WDI_RIGHT, WDI_BOT);
		mxvect(WDI_RIGHT, WDI_TOP);
		mxvect(WDI_LEFT, WDI_TOP);
		mxvect(WDI_LEFT, WDI_BOT);
	}

	/*
	 * Draw horiz axis.
	 */
	mxmove(WDI_LAXIS, WDI_BAXIS);
	mxvect(WDI_RAXIS, WDI_BAXIS);
	mxhtic(WDI_hcen_(WDI_RAXIS, WDI_LAXIS), WDI_BAXIS, 
	  ep->dots_tic, ep->degs_tic, 1);
	mxmove(WDI_LAXIS, WDI_TAXIS);
	mxvect(WDI_RAXIS, WDI_TAXIS);
	mxhtic(WDI_hcen_(WDI_RAXIS, WDI_LAXIS), WDI_TAXIS,
	  op->dots_tic, op->degs_tic, 1);

	/*
	 * Draw vert axis.
	 */
	mxmove(WDI_LAXIS, WDI_BAXIS);
	mxvect(WDI_LAXIS, WDI_TAXIS);
	mxvtic(WDI_LAXIS, WDI_vcen_(WDI_TAXIS, WDI_BAXIS),
	  ep->dots_tic, ep->degs_tic, 1);
	mxmove(WDI_RAXIS, WDI_BAXIS);
	mxvect(WDI_RAXIS, WDI_TAXIS);
	mxvtic(WDI_RAXIS, WDI_vcen_(WDI_TAXIS, WDI_BAXIS),
	 op->dots_tic, op->degs_tic, 1);

	/*
	 * Draw offset lanes.
	 */
	mxmove(WDI_LAXIS, WDI_OTOP);
	mxvect(WDI_ORIGHT, WDI_OTOP);
	mxvect(WDI_ORIGHT, WDI_BAXIS);

	/*
	 * Draw grid.
	 */
	if(i_b->d_wd_disp & D_W_GRID)
	  set_grid(WDI_XCEN, WDI_YCEN, ep->dots_tic);
}

/*
 * Draw grid.
 */
void
set_grid(int xcen, int ycen, int dots_t)
{
	int xpos, ypos;
	
	for(ypos= ycen; ypos < WDI_TAXIS; ypos += dots_t) {
		for(xpos= xcen; xpos < WDI_RAXIS; xpos += dots_t) {
			mxfast(xpos, ypos, 1);
#ifdef GOO
			mxonlyx(xpos+1);
			mxonlyx(xpos+2);
			mxonlyx(xpos-1);
			mxonlyx(xpos-2);
			mxfast(xpos, ypos+1, 1);
			mxonlyy(ypos+2);
			mxonlyy(ypos-1);
			mxonlyy(ypos-2);
#endif
		}
		for(xpos= xcen; xpos > WDI_LAXIS; xpos -= dots_t) {
			mxfast(xpos, ypos, 1);
		}
	}
	for(ypos= ycen; ypos > WDI_BAXIS; ypos -= dots_t) {
		for(xpos= xcen; xpos < WDI_RAXIS; xpos += dots_t) {
			mxfast(xpos, ypos, 1);
		}
		for(xpos= xcen; xpos > WDI_LAXIS; xpos -= dots_t) {
			mxfast(xpos, ypos, 1);
		}
	}
}

/*
 * Draw horizontal tic marks and labels.
 */
void
mxhtic(int xcen, int ycen, int dots_t, int degs_t, int upflag)
{
	int xpos, degs;
	int ticlen, ticsp, scnt;
	char stmp[20];

	if(upflag) {
		
		/*
		 * Drawing tics and labels above axis line.
		 */
		ticlen= WDI_LENTIC;
		ticsp= WDI_SPTIC;

	} else {
		ticlen= -WDI_LENTIC;
		ticsp= -(WDI_SPTIC+WDI_VTXT);
	}
	mxmove(xcen, ycen);
	for(xpos= xcen, degs= 0; xpos <  WDI_RAXIS;
	    xpos += dots_t, degs += degs_t) {
		mxmove(xpos, ycen);
		mxvect(xpos, ycen + ticlen);
		sprintf(stmp, "%d", degs);
		scnt= strlen(stmp);
		mxhtext(stmp, xpos - (scnt/2)*WDI_HTXT, ycen+ticlen+ticsp);
	}
	mxmove(xcen, ycen);
	for(xpos= xcen, degs= 0; xpos > WDI_LAXIS;
	    xpos -= dots_t, degs -= degs_t) {
		mxmove(xpos, ycen);
		mxvect(xpos, ycen + ticlen);
		sprintf(stmp, "%d", degs);
		scnt= strlen(stmp);
		mxhtext(stmp, xpos - (scnt/2)*WDI_HTXT, ycen+ticlen+ticsp);
	}
}

/*
 * Draw vertical tic marks and labels.
 */
void
mxvtic(int xcen, int ycen, int dots_t, int degs_t, int rightflag)
{
	int ypos, degs;
	int ticlen, scnt;
	char stmp[20];

	if(rightflag) {
		
		/*
		 * Drawing tics and labels to right of axis line.
		 */
		ticlen= WDI_LENTIC;

	} else {
		ticlen= -WDI_LENTIC;
	}

	mxmove(xcen, ycen);
	for(ypos= ycen, degs= 0; ypos <  WDI_TAXIS;
	    ypos += dots_t, degs += degs_t) {
		mxmove(xcen, ypos);
		mxvect(xcen+ticlen, ypos);
		sprintf(stmp, "%d", degs);
		scnt= strlen(stmp);
	    	if(rightflag)
	    	  mxhtext(stmp, xcen+WDI_LENTIC+WDI_SPTIC, ypos);
	    	else
	    	  mxhtext(stmp, xcen-(WDI_LENTIC+WDI_SPTIC+(scnt*WDI_HTXT)),
	    	    ypos);
	}
	mxmove(xcen, ycen);
	for(ypos= ycen, degs= 0; ypos > WDI_BAXIS;
	    ypos -= dots_t, degs -= degs_t) {
		mxmove(xcen, ypos);
		mxvect(xcen+ticlen, ypos);
		sprintf(stmp, "%d", degs);
		scnt= strlen(stmp);
	    	if(rightflag)
	    	  mxhtext(stmp, xcen+WDI_LENTIC+WDI_SPTIC, ypos);
	    	else
	    	  mxhtext(stmp, xcen-(WDI_LENTIC+WDI_SPTIC+(scnt*WDI_HTXT)),
	    	    ypos);
	}
}

/*
 * Start window display.
 */
void
go_wind(void)
{
	i_b->d_flags |= (D_WIND|D_REWIND);
}

/*
 * Draw text string in horiz line.
 */
void
mxhtext(char *s, int ix, int iy)
{
	static x, y;	/* last x and y location */
	
	if(ix >= 0) x= ix;	/* if args are neg, use previous locations */
	if(iy >= 0) y= iy;

	mxmove(x, y);

	for(;;) {
		if(*s < 040) continue;
		mxchar(*s++);
		x += WDI_HTXT;
		mxmove(x, y);
		if(*s == '\0') break;
	}
}

/*
 * Draw text string in vertical line.
 */
void
mxvtext(char *s, int ix, int iy)
{
	static x, y;	/* last x and y location */
	
	if(ix >= 0) x= ix;	/* if args are neg, use previous locations */
	if(iy >= 0) y= iy;

	mxmove(x, y);

	for(;;) {
		if(*s < 040) continue;
		mxchar(*s++);
		y -= WDI_VTXT;
		mxmove(x, y);
		if(*s == '\0') break;
	}
}
