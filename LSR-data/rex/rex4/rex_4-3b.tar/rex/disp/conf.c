/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government.  The original
 * versions, REX 1.0-3.12, were developed for the pdp11 architecture and
 * distributed without restrictions.  This version, REX 4.0, is a port of
 * the original version to the Intel 80x86 architecture.  This version is
 * distributed only under license agreement from the National Institutes 
 * of Health, Laboratory of Sensorimotor Research, Bldg 10 Rm 10C101, 
 * 9000 Rockville Pike, Bethesda, MD, 20892, (301) 496-9375.
 *-----------------------------------------------------------------------*
 */

/*
 * Raster, histogram configurations.
 */

#include <stdio.h>
#include <sys/types.h>
#include "../hdr/sys.h"
#include "../hdr/proc.h"
#include "../hdr/buf.h"
#include "../hdr/menu.h"
#include "../hdr/disp.h"

/*
 * Conf0: single larger raster, hist.
 */
RASTH conf0[] = {

	{ RH_RAST|RH_HIST,	/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	500, 220,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	4, 265,			/* x, y add of lower left corner of rast */
	4, 25,			/* x, y add of lower left corner of hist */
	10,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */
};

/*
 * Conf1: 2 rasters.
 */
RASTH conf1[] = {

	/*
	 * RASTH 0
	 */
	{ RH_RAST,		/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	500, 220,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	4, 25,			/* x, y add of lower left corner of rast */
	4, 25,			/* x, y add of lower left corner of hist */
	10,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 0
	 */
	{ RH_RAST,		/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	500, 220,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	4, 265,			/* x, y add of lower left corner of rast */
	4, 265,			/* x, y add of lower left corner of hist */
	10,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */
};

/*
 * Conf2:  4 rast, hist each 250 dots wide.
 */
RASTH conf2[] = {

	/*
	 * RASTH 0
	 */
	{ RH_RAST|RH_HIST,	/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	250, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	4, 131,			/* x, y add of lower left corner of rast */
	4, 4,			/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 1
	 */
	{ RH_RAST|RH_HIST,	/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	250, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	258, 131,		/* x, y add of lower left corner of rast */
	258, 4,			/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 2
	 */
	{ RH_RAST|RH_HIST,	/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	250, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	4, 385,			/* x, y add of lower left corner of rast */
	4, 260,			/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 3
	 */
	{ RH_RAST|RH_HIST,	/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	250, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	258, 385,		/* x, y add of lower left corner of rast */
	258, 260,		/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */
};

/*
 * Conf3:  8 rast each 250 dots wide.
 */
RASTH conf3[] = {

	/*
	 * RASTH 0
	 */
	{ RH_RAST,		/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	250, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	4, 4,			/* x, y add of lower left corner of rast */
	4, 4,			/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 1
	 */
	{ RH_RAST,		/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	250, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	258, 4,			/* x, y add of lower left corner of rast */
	258, 4,			/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 2
	 */
	{ RH_RAST,		/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	250, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	4, 131,			/* x, y add of lower left corner of rast */
	4, 131,			/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 3
	 */
	{ RH_RAST,		/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	250, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	258, 131,		/* x, y add of lower left corner of rast */
	258, 131,		/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 4
	 */
	{ RH_RAST,		/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	250, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	4, 258,			/* x, y add of lower left corner of rast */
	4, 258,			/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 5
	 */
	{ RH_RAST,		/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	250, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	258, 258,		/* x, y add of lower left corner of rast */
	258, 258,		/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 6
	 */
	{ RH_RAST,		/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	250, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	4, 385,			/* x, y add of lower left corner of rast */
	4, 385,			/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 7
	 */
	{ RH_RAST,		/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	250, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	258, 385,		/* x, y add of lower left corner of rast */
	258, 385,		/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */
};

/*
 * Conf4:  6 rast/hist each 165 dots wide by 123 high (3 horiz
 * 	   by 4 vert).
 */
RASTH conf4[] = {

	/*
	 * RASTH 0
	 */
	{ RH_RAST|RH_HIST,	/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	165, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	4, 131,			/* x, y add of lower left corner of rast */
	4, 4,			/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 1
	 */
	{ RH_RAST|RH_HIST,	/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	165, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	173, 131,		/* x, y add of lower left corner of rast */
	173, 4,			/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 2
	 */
	{ RH_RAST|RH_HIST,	/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	165, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	342, 131,		/* x, y add of lower left corner of rast */
	342, 4,			/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 3
	 */
	{ RH_RAST|RH_HIST,	/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	165, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	4, 385,			/* x, y add of lower left corner of rast */
	4, 258,			/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 4
	 */
	{ RH_RAST|RH_HIST,	/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	165, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	173, 385,		/* x, y add of lower left corner of rast */
	173, 258,		/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 5
	 */
	{ RH_RAST|RH_HIST,	/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	165, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	342, 385,		/* x, y add of lower left corner of rast */
	342, 258,		/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */
};

/*
 * Conf5:  12 rast or hist each 165 dots wide by 123 high (3 horiz
 * 	   by 4 vert).
 */
RASTH conf5[] = {

	/*
	 * RASTH 0
	 */
	{ RH_RAST,		/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	165, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	4, 4,			/* x, y add of lower left corner of rast */
	4, 4,			/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 1
	 */
	{ RH_RAST,		/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	165, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	173, 4,			/* x, y add of lower left corner of rast */
	173, 4,			/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 2
	 */
	{ RH_RAST,		/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	165, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	342, 4,			/* x, y add of lower left corner of rast */
	342, 4,			/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 3
	 */
	{ RH_RAST,		/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	165, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	4, 131,			/* x, y add of lower left corner of rast */
	4, 131,			/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 4
	 */
	{ RH_RAST,		/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	165, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	173, 131,		/* x, y add of lower left corner of rast */
	173, 131,		/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 5
	 */
	{ RH_RAST,		/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	165, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	342, 131,		/* x, y add of lower left corner of rast */
	342, 131,		/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 6
	 */
	{ RH_RAST,		/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	165, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	4, 258,			/* x, y add of lower left corner of rast */
	4, 258,			/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 7
	 */
	{ RH_RAST,		/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	165, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	173, 258,		/* x, y add of lower left corner of rast */
	173, 258,		/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 8
	 */
	{ RH_RAST,		/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	165, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	342, 258,		/* x, y add of lower left corner of rast */
	342, 258,		/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 9
	 */
	{ RH_RAST,		/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	165, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	4, 385,			/* x, y add of lower left corner of rast */
	4, 385,			/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 10
	 */
	{ RH_RAST,		/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	165, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	173, 385,		/* x, y add of lower left corner of rast */
	173, 385,		/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 11
	 */
	{ RH_RAST,		/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	165, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	342, 385,		/* x, y add of lower left corner of rast */
	342, 385,		/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

};

/*
 * Conf6:  8 rast, hist each 125 dots wide by 123 high.
 */
RASTH conf6[] = {

	/*
	 * RASTH 0
	 */
	{ RH_RAST|RH_HIST,	/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	125, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	0, 131,			/* x, y add of lower left corner of rast */
	0, 4,			/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 1
	 */
	{ RH_RAST|RH_HIST,	/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	125, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	129, 131,		/* x, y add of lower left corner of rast */
	129, 4,			/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 2
	 */
	{ RH_RAST|RH_HIST,	/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	125, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	258, 131,		/* x, y add of lower left corner of rast */
	258, 4,			/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 3
	 */
	{ RH_RAST|RH_HIST,	/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	125, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	387, 131,		/* x, y add of lower left corner of rast */
	387, 4,			/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 4
	 */
	{ RH_RAST|RH_HIST,	/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	125, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	0, 385,			/* x, y add of lower left corner of rast */
	0, 258,			/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 5
	 */
	{ RH_RAST|RH_HIST,	/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	125, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	129, 385,		/* x, y add of lower left corner of rast */
	129, 258,		/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 6
	 */
	{ RH_RAST|RH_HIST,	/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	125, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	258, 385,		/* x, y add of lower left corner of rast */
	258, 258,		/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 7
	 */
	{ RH_RAST|RH_HIST,	/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	125, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	387, 385,		/* x, y add of lower left corner of rast */
	387, 258,		/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */
};

/*
 * Conf7:  16 rast or hist each 125 dots wide by 123 high (4 horiz
 * 	   by 4 vert).
 */
RASTH conf7[] = {

	/*
	 * RASTH 0
	 */
	{ RH_RAST,		/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	125, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	0, 4,			/* x, y add of lower left corner of rast */
	0, 4,			/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 1
	 */
	{ RH_RAST,		/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	125, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	129, 4,			/* x, y add of lower left corner of rast */
	129, 4,			/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 2
	 */
	{ RH_RAST,		/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	125, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	258, 4,			/* x, y add of lower left corner of rast */
	258, 4,			/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 3
	 */
	{ RH_RAST,		/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	125, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	387, 4,			/* x, y add of lower left corner of rast */
	387, 4,			/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 4
	 */
	{ RH_RAST,		/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	125, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	0, 131,			/* x, y add of lower left corner of rast */
	0, 131,			/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 5
	 */
	{ RH_RAST,		/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	125, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	129, 131,		/* x, y add of lower left corner of rast */
	129, 131,		/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 6
	 */
	{ RH_RAST,		/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	125, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	258, 131,		/* x, y add of lower left corner of rast */
	258, 131,		/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 7
	 */
	{ RH_RAST,		/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	125, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	387, 131,		/* x, y add of lower left corner of rast */
	387, 131,		/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 8
	 */
	{ RH_RAST,		/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	125, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	0, 258,			/* x, y add of lower left corner of rast */
	0, 258,			/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 9
	 */
	{ RH_RAST,		/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	125, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	129, 258,		/* x, y add of lower left corner of rast */
	129, 258,		/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 10
	 */
	{ RH_RAST,		/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	125, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	258, 258,		/* x, y add of lower left corner of rast */
	258, 258,		/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 11
	 */
	{ RH_RAST,		/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	125, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	387, 258,		/* x, y add of lower left corner of rast */
	387, 258,		/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 12
	 */
	{ RH_RAST,		/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	125, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	0, 385,			/* x, y add of lower left corner of rast */
	0, 385,			/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 13
	 */
	{ RH_RAST,		/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	125, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	129, 385,		/* x, y add of lower left corner of rast */
	129, 385,		/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 14
	 */
	{ RH_RAST,		/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	125, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	258, 385,		/* x, y add of lower left corner of rast */
	258, 385,		/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 15
	 */
	{ RH_RAST,		/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	125, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	387, 385,		/* x, y add of lower left corner of rast */
	387, 385,		/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

};

/*
 * Conf8:  6 rasters, 2 rast/hists.  Varying sizes.
 */
RASTH conf8[] = {

	/*
	 * RASTH 0
	 */
	{ RH_RAST|RH_HIST,	/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	165, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	4, 4,			/* x, y add of lower left corner of rast */
	4, 131,			/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 1
	 */
	{ RH_RAST|RH_HIST,	/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	334, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	173, 4,			/* x, y add of lower left corner of rast */
	173, 131,		/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 2
	 */
	{ RH_RAST,		/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	165, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	4, 258,			/* x, y add of lower left corner of rast */
	4, 258,			/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 3
	 */
	{ RH_RAST,		/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	165, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	173, 258,		/* x, y add of lower left corner of rast */
	173, 258,		/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 4
	 */
	{ RH_RAST,		/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	165, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	342, 258,		/* x, y add of lower left corner of rast */
	342, 258,		/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 5
	 */
	{ RH_RAST,		/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	165, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	4, 385,			/* x, y add of lower left corner of rast */
	4, 385,			/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 6
	 */
	{ RH_RAST,		/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	165, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	173, 385,		/* x, y add of lower left corner of rast */
	173, 385,		/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */

	/*
	 * RASTH 7
	 */
	{ RH_RAST,		/* flags */
	0,			/* log base 2 msec per dot */
	0,			/* log base 2 dots per bin */
	165, 123,		/* x and y length each in dots of rast and
				   hist;  y len includes label lines etc. */
	342, 385,		/* x, y add of lower left corner of rast */
	342, 385,		/* x, y add of lower left corner of hist */
	8,			/* vert spacing in dots between raster lines */
	1001,			/* trigger event code */
	0,			/* time offset in msec from center for trig */
	9, 0,			/* A label line y offset, B line y offset */
	22,			/* tics line y offset */
	601,			/* unitcode */
	0,			/* initial scale factor */
	1,			/* autoselect flag */
	0 },			/* all else initialized to 0 */
};

/*
 * Tics line scalings for different values of ms_P_dot.
 */
TSCALE tscale[] = {
	10, 50,		/* 1 ms_P_dot */
	5, 25,		/* 2 ms_P_dot */
	0, 25,		/* 4 ms_P_dot */
	0, 25,		/* 8 ms_P_dot */
	0, 31,		/* 16 ms_P_dot */
	0, 31,		/* 32 ms_P_dot */
};

/*
 * Initial scaling factors for histograms.  Idea:  the larger the
 * quantity msec per bin the larger the scaling factor.
 */
int sfact[2 * MAXSHF] = {
	-4,
	-3,
	-2,
	-1,
	0,
	1,
	1,
	2,
	2,
	3,
};

CONFIG conf[] = {
	&conf0, 1,		/* single raster, histogram */
	&conf1, 2,
	&conf2, 4,
	&conf3, 8,
	&conf4, 6,
	&conf5, 12,
	&conf6, 8,
	&conf7, 16,
	&conf8, 8,
	0, 0,			/* terminate with zeros */
};
