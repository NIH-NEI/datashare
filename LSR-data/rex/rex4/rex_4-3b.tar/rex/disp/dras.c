/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government.  The original
 * versions, REX 1.0-3.12, were developed for the pdp11 architecture and
 * distributed without restrictions.  This version, REX 4.0, is a port of
 * the original version to the Intel 80x86 architecture.  This version is
 * distributed only under license agreement from the National Institutes 
 * of Health, Laboratory of Sensorimotor Research, Bldg 10 Rm 10C101, 
 * 9000 Rockville Pike, Bethesda, MD, 20892, (301) 496-9375.
 *-----------------------------------------------------------------------*
 */

/*
 * Raster, histogram display.
 */

#include <stdio.h>
#include <sys/types.h>
#include "../hdr/sys.h"
#include "../hdr/proc.h"
#include "../hdr/buf.h"
#include "../hdr/ecode.h"
#include "../hdr/matrox.h"
#include "../hdr/tty.h"
#include "../hdr/menu.h"
#include "../hdr/disp.h"

extern int diag;

/*
 * Search backward from current event buffer load index and assemble
 * a list of triggers to display.
 *
 * NOTE:  The wakeup trigger, ras_wakeup_ecode, should occur AFTER all the
 * units of interest are in the event buffer.  Otherwise if dras() is started
 * before all units (taking into account timescales of rasts, hists) have
 * occurred they will not be displayed on screen or added into histograms.
 * If a rast, hist is redrawn (e.g. if raster display is left and restarted)
 * and the units previously not processed are still in event buffer they will
 * be displayed on the redrawn raster; however, they will NOT be added
 * to histogram since units are added only once when their trigger is
 * first processed.
 */
void
dras(void)
{
	EVENT_P ep;
	TSEARCH *sp;
	int ecode;
	EVENT_P ep_sav;
	TLIST *tlp;
	RASTH *rhp;
	long begtime, etime;
	int rhnum;
	int beg_init= 0;

	/*
	 * Check if initiated from begras().
	 */
	if(i_b->d_flags & D_RHDRAW) {

		/*
		 * Screen is blank.  Draw rast, hist display and set
		 * r_ltime to allow past units still in event buffer to
		 * be redisplayed.
		 */
		dtics(NP, 0, 0);
		dtrig(NP, 0, 0);
		dlabel(NP, 0, 0);
		dhist(NP, MXBRT);
		tsrchtime= 0;
		rhp= conf[confnum].c_rhp;
		rhnum= conf[confnum].c_rhnum;
		for(; rhnum > 0; rhp++, rhnum--) {
			rhp->r_ltime= rhp->rh_itime;
		}
		i_b->d_flags &= ~D_RHDRAW;
	}

	/*
	 * Restore hist signalling in case is has be disabled by noun,
	 * verb processing during critical sections.
	 */
	if(i_b->d_flags & D_HISTON) i_b->d_flags |= D_HSIG;

	/*
	 * Search for previous triggers.  Stop if:
	 *	1.) Time of event reaches already displayed triggers.
	 *	2.) Nlines worth of triggers are found.
	 *	3.) Event buffer is exhausted.
	 */
	ep= &i_b->bevent[i_b->evlx];
	ep_sav= ep;
	tlp= &tlist;
	tlp->tl_trig= NP;	/* first entry must be null; fillras() works
				   backward from end of list */
	for(sp= &tsearch; sp->ts_trig != 0; sp++->ts_tcnt= 0);

	for(;;) {

	    /*
	     * Decrement ep first- evlx points to next event to load.
	     */
	    if(--ep < &i_b->bevent) ep= &i_b->bevent[EBUFNUM-1];
	    if(ep->e_code > 0) {	/* check for an event code */

		/*
		 * If time is earlier than tsrchtime we can stop.  If
		 * time is later than begtime we have passed the
		 * current load index (evlx).
		 */
		etime= ep->e_key;
		if(etime <= tsrchtime) break;
		if(beg_init == 0) {
		    beg_init= 1;
		    begtime= etime;
		} else if(etime > begtime) break;

		ecode= ep->e_code;

		/*
		 * Stop if init code is found.  Currently commented out.
		 * Similar line in fillras() also commented out.
		if(ecode & INIT_MASK) break;
		 */

		for(sp= &tsearch; sp->ts_trig != 0; sp++) {
		    if(ecode == sp->ts_trig) {
if(diag) tputs("Y");
			rhp= sp->ts_rhp;
			if( ! (rhp->rh_flag & (RH_RAST|RH_HIST))) continue;
			if(sp->ts_tcnt++ >= rhp->r_nlines) continue;
			if(++tlp >= &tlist[TLISTNUM]) {
				rxerr("dras(): tlist[] size exceeded");
				tlp--;
			}
			tlp->tl_trig= ep;
			tlp->tl_rasth= rhp;
			tlp->tl_time= etime;
if(diag) tputs("Z");
		    }
		}
	    }

	    /*
	     * If there are no subsequent events after begtime loop would
	     * continue indefinitely- the test for etime > begtime would
	     * never be true.  Therefore check for coming full circle and
	     * quit.
	     */
	    if(ep == ep_sav) break;
	}
	tsrchtime= begtime;

	/*
	 * Display raster lines and hists on matrox.
	 */
	if(tlp->tl_trig != NP) fillras(tlp);
}
