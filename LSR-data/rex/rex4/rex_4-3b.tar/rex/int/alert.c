/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government.  The original
 * versions, REX 1.0-3.12, were developed for the pdp11 architecture and
 * distributed without restrictions.  This version, REX 4.0, is a port of
 * the original version to the Intel 80x86 architecture.  This version is
 * distributed only under license agreement from the National Institutes 
 * of Health, Laboratory of Sensorimotor Research, Bldg 10 Rm 10C101, 
 * 9000 Rockville Pike, Bethesda, MD, 20892, (301) 496-9375.
 *-----------------------------------------------------------------------*
 */

/*
 * Int interprocess communication.
 */

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <signal.h>
#include "../hdr/sys.h"
#include "../hdr/cnf.h"
#include "../hdr/proc.h"
#include "../hdr/buf.h"
#include "../hdr/tty.h"
#include "../hdr/device.h"
#include "../hdr/menu.h"
#include "../hdr/int.h"

#define NVMASK	(s_(G_NMEXEC))	/* allow everything (but myself) to re-interrupt
				   noun,menu processing */
extern sigset_t	alert_set;

#pragma off (unreferenced)
void
alert(int sig)
{
#pragma on (unreferenced)

	PROCTBL_P p= &i_b->ptbl[myptx];
	unsign msg, restormask;
	int (*func)();
	int nindex;
	char vstr[P_ISLEN], astr[P_ISLEN];
	extern ME_ACCP me_accp;

	if(p->p_state & P_ALRTBSY_ST) return;
	p->p_state |= P_ALRTBSY_ST;

newscan:
	protect(&p->p_sem);
	msg= p->p_msg & ~p->p_rmask;	/* mask with priority level */
	if(msg == 0) {

		/*
		 * Alert must return from here only.
		 */
		p->p_state &= ~(P_NOSIG_ST|P_ALRTBSY_ST);
		release_(&p->p_sem);
		return;

	} else if(msg & s_(G_KILL)) {
		p->p_msg &= ~s_(G_KILL);
		release_(&p->p_sem);
		p->p_state |= P_EXIT_ST;
#ifdef CLRMIRRORS
		XYmout(0,0);	/* put mirrors at 0,0 */
#endif
		exit(0);

	} else if(msg & s_(G_STOP)) {		
		p->p_msg &= ~s_(G_STOP);
		release_(&p->p_sem);
		if(i_b->i_flags & I_GO) {
			rxerr("alert(): Cannot stop int if clock is going");
			sendmsg(COMM, CM_NEG);
			goto newscan;
		}
		i_b->int_pi= -1;		/* no int process now */

		/*
		 * If currently reading from a root file, close root.
		 */
		if(infd != 0) rt_close();
		sendmsg(COMM, CM_AFFIRM);

	} else if(msg & s_(G_RUN)) {
		p->p_msg &= ~s_(G_RUN);
		release_(&p->p_sem);
		if(i_b->int_pi > 0) {
			rxerr("alert(): An int process is already running");
			sendmsg(COMM, CM_NEG);
			goto newscan;
		}
		i_b->int_pi= myptx;		/* I am now the int process */

		/*
		 * If currently reading from a root file, open root.
		 */
		if(i_b->i_rtflag & RT_READ) rt_read();
		sendmsg(COMM, CM_AFFIRM);

	} else if(msg & s_(G_RTEXEC)) {
		p->p_msg &= ~s_(G_RTEXEC);
		release_(&p->p_sem);

		/*
		 * Note that the int process calls rt_write() when
		 * RT_WSTATE is set also.
		 */
		if(i_b->i_rtflag & RT_READ) rt_read();
		else if(i_b->i_rtflag & (RT_WMENU|RT_WSTATE)) rt_write();
		else if(i_b->i_rtflag & RT_CLOSE) rt_close();
		sendmsg(COMM, CM_AFFIRM);

	} else if(msg & s_(G_NMEXEC)) {
		p->p_msg &= ~s_(G_NMEXEC);
#ifdef NEED_FAR
		_fstufs(i_b->i_verbs, vstr, &vstr[P_ISLEN]);
		_fstufs(i_b->i_args, astr, &astr[P_ISLEN]);
#else
		stufs(i_b->i_verbs, vstr, &vstr[P_ISLEN]);
		stufs(i_b->i_args, astr, &astr[P_ISLEN]);
#endif
		nindex= i_b->i_nindex;
		i_b->i_nindex= 0;

		/*
		 * Prepare to allow re-interrupts.
		 */
		restormask= (p->p_rmask ^ NVMASK) & NVMASK;
		p->p_rmask |= NVMASK;
		p->p_state &= ~(P_NOSIG_ST|P_ALRTBSY_ST|P_EARLYWAKE_ST);
		release_(&p->p_sem);
		if(sigprocmask(SIG_UNBLOCK, &alert_set, NULL) == -1)
		    rxerr("alert(): cannot sigprocmask");

		if(*vstr == '\0') access_m(&me_accp, &menus[nindex], astr);
		else {
			func= nouns[nindex].n_ptr;
			(*func)(vstr, astr);
		}

		/*
		 * Comm may have already been awakened by noun,menu.  If
		 * not, awaken it.
		 */
		if( ! (p->p_state & P_EARLYWAKE_ST))
			sendmsg(COMM, CM_AFFIRM);

		/*
		 * Disable re-interrupts and restore pri mask.
		 */
		if(sigprocmask(SIG_BLOCK, &alert_set, NULL) == -1)
		    rxerr("alert(): cannot sigprocmask");
		p->p_state |= (P_NOSIG_ST|P_ALRTBSY_ST);
		p->p_rmask &= ~restormask;

	} else {		/* bad msg */
		p->p_msg &= ~msg;
		release_(&p->p_sem);
		rxerr("alert(): Int received illegal message");
	}

	goto newscan;
}
