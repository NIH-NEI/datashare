/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government.  The original
 * versions, REX 1.0-3.12, were developed for the pdp11 architecture and
 * distributed without restrictions.  This version, REX 4.0, is a port of
 * the original version to the Intel 80x86 architecture.  This version is
 * distributed only under license agreement from the National Institutes 
 * of Health, Laboratory of Sensorimotor Research, Bldg 10 Rm 10C101, 
 * 9000 Rockville Pike, Bethesda, MD, 20892, (301) 496-9375.
 *-----------------------------------------------------------------------*
 */

/*
 * Digital I/O, d/a converter support.
 */
#include <stdio.h>
#include <conio.h>
#include <sys/types.h>
#include "../hdr/sys.h"
#include "../hdr/cnf.h"
#include "../hdr/phys.h"
#include "../hdr/proc.h"
#include "../hdr/buf.h"
#include "../hdr/device.h"
#include "../hdr/menu.h"
#include "../hdr/int.h"

/*
 * Array of pointers to DIO_DEV array.  Indexed by device id.
 * This array is initialized by dio_init() when int process is first
 * run.
 */
DIO_DEV *dio_index[DIO_DEV_DEVMAX]= {0};

void
dio_init()
{
    DIO_DEV *dp;

    for(dp= dio_dev; dp->dio_devid != 0; dp++) {
	dio_index[dp->dio_devid]= dp;
    }
}

/*
 * Output to port.
 */
int
dio_set(DIO_ID id, int value, int flag)
{
    DIO_DEV *dp;
    int port, data;
    u_char pinit;

    if((dp= dio_index[Dio_dev(id)]) == 0) {
	rxerr("dio_set(): nonexistant device");
	return(0);
    }

    /*
     * Init device if it hasn't been initialized.
     */
    if((dp->dio_flags & D_INIT) == 0) {
	if(dp->dio_init) (*dp->dio_init)(dp);
	else dp->dio_flags |= D_INIT;
    }
    port= Dio_port(id);
    pinit= dp->dio_pinit[port];
    if(Dio_type(pinit) != D_OUT) {
	rxerr("dio_set(): illegal operation on port, or port out of range.");
	return(0);
    }
    switch(flag) {
	case D_ON:
	    data= (dp->dio_state[port] |= Dio_data(id));
	    break;
	case D_OFF:
	    data= (dp->dio_state[port] &= ~Dio_data(id));
	    break;
	case D_VAL:
	    data= value & Dio_data(id);
	    break;
	default:
	    rxerr("dio_set(): illegal flag passed to function");
	    return(0);
    }
    if(pinit & D_REV) data= ~data;
    if(pinit & D_WORD) outpw(dp->dio_port_base + port, data);
    else outp(dp->dio_port_base + port, (data & 0xff));
    return(0);
}

/*
 * Input from port.
 */
int
dio_in(DIO_ID id)
{
    DIO_DEV *dp;
    int port, data;
    u_char pinit;

    if((dp= dio_index[Dio_dev(id)]) == 0) {
	rxerr("dio_set(): nonexistant device");
	return(0);
    }

    /*
     * Init device if it hasn't been initialized.
     */
    if((dp->dio_flags & D_INIT) == 0) {
	if(dp->dio_init) (*dp->dio_init)(dp);
	else dp->dio_flags |= D_INIT;
    }
    port= Dio_port(id);
    pinit= dp->dio_pinit[port];
    if(Dio_type(pinit) != D_IN) {
	rxerr("dio_in(): illegal operation on port, or port out of range");
	return(0);
    }
    if(pinit & D_WORD) {
	data= inpw(dp->dio_port_base + port);
	if(pinit & D_REV) data= ~data;
	return(data & Dio_data(id));
    } else {
	data= inp(dp->dio_port_base + port);
	if(pinit & D_REV) data= ~data & 0xff;
	return(data & Dio_data(id));
    }
}

/*
 * Initialization routines.
 */
#if (defined PCDIO || defined KMPIO12)
void
i8255_init(DIO_DEV *dp)
{
    int i, apinit, bpinit, cpinit, aclr, bclr, cclr;
    u_int control;

    /*
     * 8255 has 24 dio bits, with 4 ports per chip.  The first
     * three ports are 8 bit dio ports, the fourth is a control
     * register.  A device may have more than one chip.
     * Loop looking for control registers.  Use index addressing
     * instead of pointers for readability (this routine is
     * exectued once, and is not time-critical).
     */
    for(i= 3; Dio_type(dp->dio_pinit[i]) != D_NUL; i += 4) {

	if(Dio_type(dp->dio_pinit[i]) != D_CTRL) {
	    rxerr("8255_init(): pinit[] array improperly inited");
	    return;
	}
	
	/*
	 * Assemble control word based on whether ports are in/out.
	 * Set unused ports as inputs (note that an input port driving
	 * an output I/O module is safe, but an output port driving an
	 * input I/O module is not).
	 *
	 * If D_NOCLR is not set, turn output ports to off.  This will
	 * turn off any output I/O modules such as current sinks or
	 * relays.  This is important for output I/O modules, since
	 * they are on when driven with a logic 0.  The 8255 comes up
	 * with output ports all 0s.
	 */
	control= 0x80;

	apinit= dp->dio_pinit[i-3];
	if(Dio_type(apinit) == D_IN) control |= 0x10;	    /* port A */
	aclr= (apinit & D_REV) ? 0xff : 0x0;

	bpinit= dp->dio_pinit[i-2];
	if(Dio_type(bpinit) == D_IN) control |= 0x2;	    /* port B */
	bclr= (bpinit & D_REV) ? 0xff : 0x0;

	cpinit= dp->dio_pinit[i-1];
	if(Dio_type(cpinit) == D_IN) control |= 0x9;	    /* port C */
	cclr= (cpinit & D_REV) ? 0xff : 0x0;

	/*
	 * Try to clear outputs as quickly as possible after setting
	 * control word.
	 */
	outp(dp->dio_port_base + i, control);
	if( ! (apinit & D_NOCLR)) outp(dp->dio_port_base + (i-3), aclr);
	if( ! (bpinit & D_NOCLR)) outp(dp->dio_port_base + (i-2), bclr);
	if( ! (cpinit & D_NOCLR)) outp(dp->dio_port_base + (i-1), cclr);
    }
    dp->dio_flags |= D_INIT;
}
#endif

/*
 * Output to d/a converters.
 */
int
dio_da(DIO_ID id, int val1, int val2, int flag)
{
    DIO_DEV *dp;
    int da_num, datmp, i;
    u_char pinit;

    if((dp= dio_index[Dio_dev(id)]) == 0) {
	rxerr("dio_da(): nonexistant device");
	return(0);
    }

    /*
     * Init device if it hasn't been initialized.
     */
    if((dp->dio_flags & D_INIT) == 0) {
	if(dp->dio_init) (*dp->dio_init)(dp);
	else dp->dio_flags |= D_INIT;
    }
    da_num= Dio_port(id);
    pinit= dp->dio_pinit[da_num];
    if(Dio_type(pinit) != D_DA) {
	rxerr("dio_da(): illegal operation on d/a, or d/a out of range.");
	return(0);
    }

    /*
     * D/A output code.  D/A specific info is known here.  The code
     * takes a value specified in the standard REX internal
     * calibration of 40 steps/deg, 2s complement
     * and performs necessary conversions for specific D/A.
     */
    switch(dp->dio_devid) {
#ifdef CIO_DA
    case CIO_DA_DA:

	/*
	 * Computer Boards d/a cards have 6, 8, or 16 d/a converters.
	 * There are two 8-bit registers/converter, starting at the base
	 * address.  The first register is the lower 8 bits and should
	 * be written first.  The next register is the higher 4 bits.
	 * A write to this register updates the d/a.  Offset binary.
	 */
	for(i= 1; i <= 2; i++) {
	    if(flag & D_NOMAP) datmp= val1;
	    else {
		datmp= -(val1 - 2047);
		if(datmp > 4095) datmp= 4095;
		if(datmp < 0) datmp= 0;
	    }
	    outp(CIO_DA_PORT+(da_num << 1), shortlo_(datmp));
	    outp(CIO_DA_PORT+(da_num << 1)+1, shorthi_(datmp));
	    if( ! (flag & D_BOTH)) break;
	    val1= val2;
	    da_num++;
	}
	break;
#endif	
#ifdef DT2821
    case DT2821_DA:

	/*
	 * Data Translation DT2821 D/A.  Offset binary; +,+ in quad 0
	 * (as it should be).
	 */
	for(i= 1; i <= 2; i++) {
	    if(flag & D_NOMAP) datmp= val1;
	    else {
		datmp= val1 + 2048;
		if(datmp > 4095) datmp= 4095;
		if(datmp < 0) datmp= 0;
	    }
	    switch(da_num) {
	    case 0:
		while((inpw(DT0_DACSR_RW) & DT0_DACRDY) == 0);
		Wsetport_RW(DT0_DACSR_RW, DT0_SSEL, DT0_YSEL);
		outpw(DT0_DADATA_WO, datmp);
		Wsetport_RW(DT0_SCSR_RW, DT0_DACON, 0x0);
		break;
	    case 1:
		while((inpw(DT0_DACSR_RW) & DT0_DACRDY) == 0);
		Wsetport_RW(DT0_DACSR_RW, DT0_SSEL|DT0_YSEL, 0x0);
		outpw(DT0_DADATA_WO, datmp);
		Wsetport_RW(DT0_SCSR_RW, DT0_DACON, 0x0);
		break;
	    default:
		rxerr("dio_da(): illegal da #");
		break;
	    }
	    if( ! (flag & D_BOTH)) break;
	    val1= val2;
	    da_num++;
	}
	break;
#endif
#ifdef NIATMIO
    case NIATMIO_DA:

	/*
	 * National Instruments ATMIO-16.  Accepts 2's complement.
	 */
	for(i= 1; i <= 2; i++) {
	    if(flag & D_NOMAP) datmp= val1;
	    else datmp= -val1;
	    switch(da_num) {
	    case 0:
		outpw(NI0_DAC0_WO, datmp);
		break;
	    case 1:
		outpw(NI0_DAC1_WO, datmp);
		break;
	    default:
		rxerr("dio_da(): illegal da #");
		break;
	    }
	    if( ! (flag & D_BOTH)) break;
	    val1= val2;
	    da_num++;
	}
	break;
#endif
#ifdef ANDAS12
    case ANDAS12_DA:
	
	/*
	 * Analogics DAS12.  Offset binary.  NOTE! This d/a can only drive
	 * +,- 1ma.
 	 */
	for(i= 1; i <= 2; i++) {
	    if(flag & D_NOMAP) datmp= val1;
	    else {
		datmp= -(val1 - 2047);
		if(datmp > 4095) datmp= 4095;
		if(datmp < 0) datmp= 0;
	    }
	    switch(da_num) {
	    case 0:
		outpw(AN1_DAC0_WO, datmp);
		break;
	    case 1:
		outpw(AN1_DAC1_WO, datmp);
		break;
	    default:
		rxerr("dio_da(): illegal da #");
		break;
	    }
	    if( ! (flag & D_BOTH)) break;
	    val1= val2;
	    da_num++;
	}
	break;
#endif
    default:
	rxerr("dio_da(): unsupported da device id");
	break;
    }
    return(0);
}
