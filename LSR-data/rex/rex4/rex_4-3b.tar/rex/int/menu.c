/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government.  The original
 * versions, REX 1.0-3.12, were developed for the pdp11 architecture and
 * distributed without restrictions.  This version, REX 4.0, is a port of
 * the original version to the Intel 80x86 architecture.  This version is
 * distributed only under license agreement from the National Institutes 
 * of Health, Laboratory of Sensorimotor Research, Bldg 10 Rm 10C101, 
 * 9000 Rockville Pike, Bethesda, MD, 20892, (301) 496-9375.
 *-----------------------------------------------------------------------*
 */

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include "../hdr/sys.h"
#include "../hdr/cnf.h"
#include "../hdr/proc.h"
#include "../hdr/buf.h"
#include "../hdr/sac.h"
#include "../hdr/idsp.h"
#include "../hdr/menu.h"
#include "../hdr/device.h"
#include "../hdr/ramp.h"
#include "../hdr/int.h"

/*
 *-----------------------------------------------------------------------*
 * Nouns, menus, access functions for int.
 *
 * Note that for many of the menu variable-access functions below an
 * action corresponding to the menu variable is called with NULLI
 * as an argument.  The reason the action is called to make the change,
 * instead of having the menu system change the variable directly, is
 * due to critical sections between the upper and lower level.  The action
 * makes the change inside a section that is protected from interrupts.
 * Routines in both int.c and clock.c can interrupt the upper level
 * and cause problems.
 *-----------------------------------------------------------------------*
 */

/* 
 * Menu: "control_param"
 *-----------------------------------------------------------------------*
 */
#define CP_VL_SIZE 1000
char hm_cp_vl[CP_VL_SIZE];
#pragma off (unreferenced)
int
cp_maf(int flag, MENU *mp, char *astr, VLIST *vlp, int *tvadd)
{
#pragma on (unreferenced)
    char *hm= &hm_cp_vl;
    char *hm_end= &hm_cp_vl[CP_VL_SIZE];
    extern char hm_cp_proto_vl[];

    hm= stufs(hm_cp_proto_vl, hm, hm_end);
#if (!defined AD_CGLIST)
    if(ad_gain[0].ad_gain_factor != -1) {
	int i;
	char s_tmp[10];	

	hm= stufs("\n", hm, hm_end);
	hm= stufs("gains:\n  ", hm, hm_end);
	for(i= 0;;) {
	    itoa_RL(ad_gain[i].ad_gain_factor, 'd', &s_tmp,
			&s_tmp[P_LNAME]);
	    hm= stufs(s_tmp, hm, hm_end);
	    if(ad_gain[++i].ad_gain_factor == -1) break;
	    hm= stufs(", ", hm, hm_end);
	}
    }
#endif
    hm= stufs("\n", hm, hm_end);
    return(0);
}

char hm_cp_proto_vl[] = "\
Unit window control-\n\
  -:	default or stateset\n\
  0:	units ignored\n\
  1:	units saved";

#pragma off (unreferenced)
int
cp_aw_vaf(int flag, MENU *mp, char *astr, VLIST *vlp, int *tvadd)
{
#pragma on (unreferenced)

	pre_post(NULLI, NULLI);
	return(0);
}

#pragma off (unreferenced)
int
cp_uw_vaf(int flag, MENU *mp, char *astr, VLIST *vlp, int *tvadd)
{
#pragma on (unreferenced)

	uw_set(NULLI);
	return(0);
}

#if (!defined AD_CGLIST)
#pragma off (unreferenced)
int
cp_ad_ov_gain_vaf(int flag, MENU *mp, char *astr, VLIST *vlp, int *tvadd)
{
#pragma on (unreferenced)
    if(i_b->i_flags & I_GO) {
	rxerr("cp_adgain_vaf(): cannot change when clock is on");
	return(1);	    /* soft error- dont abort root reads */
    }
    return(sig_ck_ad_gain(-1, *tvadd));
}
#endif

#pragma off (unreferenced)
int
cp_ad_max_rate_vaf(int flag, MENU *mp, char *astr, VLIST *vlp, int *tvadd)
{
#pragma on (unreferenced)
    if(i_b->i_flags & I_GO) {
	rxerr("cp_ad_max_rate_vaf(): cannot change when clock is on");
	return(1);	    /* soft error- dont abort root reads */
    }
    return(sig_ck_ad_max_rate(-1, *tvadd));
}

extern int errprt;
VLIST cp_vl[] = {
#if (!defined AD_CGLIST)
"ad_overall_gain",	&ad_ov_gain, NP, cp_ad_ov_gain_vaf, ME_BEF, ME_DEC,
#endif
"ad_max_rate",		&ad_max_rate, NP, cp_ad_max_rate_vaf, ME_BEF, ME_DEC,
"pre_time_msec",	&m_pre, NP, cp_aw_vaf, ME_AFT, ME_NVALD,
"post_time_msec",	&m_post, NP, cp_aw_vaf, ME_AFT, ME_NVALD,
"unit_wind_ctl",	&m_uwind, NP, cp_uw_vaf, ME_AFT, ME_NVALD,
"wind_disp_rate",	&w_rate, NP, NP, 0, ME_DEC,
"wind_check_rate",	&t_wrate, NP, NP, 0, ME_DEC,
"state_proc_rate",	&st_rate, NP, NP, 0, ME_DEC,
"debug_state",		&errprt, NP, NP, 0, ME_DEC,
"doutput_inmem",	&doutput_inmem, NP, NP, 0, ME_DEC,
"doutput_rotate",	&doutput_rot, NP, NP, 0, ME_DEC,
NS,
};

/*
 * Menu: "signals"
 *-----------------------------------------------------------------------*
 */
#define SIG_VL_SIZE 1000
char hm_sig_vl[SIG_VL_SIZE];
static int signum;		/* signal number of current access */
#pragma off (unreferenced)
int
sig_maf(int flag, MENU *mp, char *astr, VLIST *vlp, int *tvadd)
{
#pragma on (unreferenced)
    int i;
    SIG *sigp;
    char *hm= &hm_sig_vl;
    char *hm_end= &hm_sig_vl[SIG_VL_SIZE];
    
    if(i_b->i_flags & I_GO) {
	rxerr("sig_maf(): cannot change when clock is on");
	return(1);	    /* soft error- dont abort root reads */
    }

    if(flag & ME_BEF) {

	/*
	 * Set up global base pointer for this menu access.
	 */
	if(*astr == '\0') signum= 0;
	else signum= atoi(astr);
	if(signum < 0 || signum >= SA_MAXSIG) {
	    rxerr("sig_maf(): Bad signal number");
	    return(-1);
	}
	sigp= &sig[signum];
	mp->me_basep= (unsign)sigp;

	/*
	 * Set up help message for this menu access.
	 */
	hm= stufs("enable- 0: off, 1: a/d, 2: mem", hm, hm_end);
	if(gv_ad_mem[0].gv_ptr != NULL) {
  	  hm= stufs("\na/d mem variables:\n  ", hm, hm_end);
	  for(i= 0;;) {
		hm= stufs(gv_ad_mem[i].gv_name, hm, hm_end);
		if(gv_ad_mem[++i].gv_ptr == NULL) break;
		if(!(i & 01)) hm= stufs("\n  ", hm, hm_end);
		else hm= stufs("  ", hm, hm_end);
	  }
	}
	hm= stufs("\nrates:\n  ", hm, hm_end);
	sig_compute_ad_rates();
	for(i= 0;;) {
	    char s_tmp[10];
	    
	    itoa_RL(ad_acq_rates[i].ad_acq_rate, 'd', &s_tmp,
			&s_tmp[P_LNAME]);
	    hm= stufs(s_tmp, hm, hm_end);
	    if(++i >= SA_SPREAD_LOG2+1) break;
	    hm= stufs(", ", hm, hm_end);
	}
	hm= stufs("\ncalib (deg FS)- 0: 204, 1: 102", hm, hm_end);
	hm= stufs("\n  2: 51, 3: 25, 4: 12, 5: 6", hm, hm_end);
	hm= stufs("\n  6: Noise test for 16 bit a/d", hm, hm_end);
#if (defined AD_CGLIST)
	if(ad_gain[0].ad_gain_factor != -1) {
	    char s_tmp[10];	

	    hm= stufs("\ngains:\n  ", hm, hm_end);
	    for(i= 0;;) {
		itoa_RL(ad_gain[i].ad_gain_factor, 'd', &s_tmp,
			&s_tmp[P_LNAME]);
		hm= stufs(s_tmp, hm, hm_end);
		if(ad_gain[++i].ad_gain_factor == -1) break;
		hm= stufs(", ", hm, hm_end);
	    }
	}
#endif
	if(gv_mem_src[0].gv_ptr != NULL) {
	  hm= stufs("\nnon-a/d memory sources:\n  ", hm, hm_end);
	  for(i= 0;;) {
		hm= stufs(gv_mem_src[i].gv_name, hm, hm_end);
		if(gv_mem_src[++i].gv_ptr == NULL) break;
		if(!(i & 01)) hm= stufs("\n  ", hm, hm_end);
		else hm= stufs("  ", hm, hm_end);
	  }
	}
	return(0);
    } else return(0);
}

/*
 * Signal menu root argument generation function.  The purpose of this
 * function is to generate ascii strings that correspond to the
 * argument strings that would be used to access all the signal menus.
 */
#pragma off (unreferenced)
int
sig_agf(int call_cnt, MENU *mp, char *astr)
{
#pragma on (unreferenced)

	if(call_cnt >= SA_MAXSIG) {

		/*
		 * Done.  Return null to terminate writing of root for
		 * this menu.
		 */
		*astr= '\0';
	} else itoa_RL(call_cnt, 'd', astr, &astr[P_ISLEN]);
	return(0);
}

/*
 * Variable access functions.
 */
#pragma off (unreferenced)
int
sig_sig_enable_vaf(int flag, MENU *mp, char *astr, VLIST *vlp, int *tvadd)
{
#pragma on (unreferenced)

    return(sig_ck_sig_enable(signum, *tvadd));
}

#pragma off (unreferenced)
int
sig_ad_chan_vaf(int flag, MENU *mp, char *astr, VLIST *vlp, int *tvadd)
{
#pragma on (unreferenced)

    return(sig_ck_chan(signum, *tvadd));
}

#pragma off (unreferenced)
int
sig_ad_mem_var_vaf(int flag, MENU *mp, char *astr, VLIST *vlp, int *tvadd)
{
#pragma on (unreferenced)

    return(sig_ck_ad_mem_var(signum, (char *)tvadd));
}
 
#pragma off (unreferenced)
int
sig_ad_acq_rate_vaf(int flag, MENU *mp, char *astr, VLIST *vlp, int *tvadd)
{
#pragma on (unreferenced)

    return(sig_ck_ad_acq_rate(signum, *tvadd));
}
 
#pragma off (unreferenced)
int
sig_ad_calib_vaf(int flag, MENU *mp, char *astr, VLIST *vlp, int *tvadd)
{
#pragma on (unreferenced)

    return(sig_ck_ad_calib(signum, *tvadd));
}
 
#if (defined AD_CGLIST)
#pragma off (unreferenced)
int
sig_ad_gain_vaf(int flag, MENU *mp, char *astr, VLIST *vlp, int *tvadd)
{
#pragma on (unreferenced)

    return(sig_ck_ad_gain(signum, *tvadd));
}
#endif

#pragma off (unreferenced)
int
sig_mem_src_vaf(int flag, MENU *mp, char *astr, VLIST *vlp, int *tvadd)
{
#pragma on (unreferenced)

    return(sig_ck_mem_src_var(signum, (char *)tvadd));
}
 
#pragma off (unreferenced)
int
sig_sig_store_rate_vaf(int flag, MENU *mp, char *astr, VLIST *vlp, int *tvadd)
{
#pragma on (unreferenced)

    return(sig_ck_sig_store_rate(signum, *tvadd));
}
 
#pragma off (unreferenced)
int
sig_sig_title_vaf(int flag, MENU *mp, char *astr, VLIST *vlp, int *tvadd)
{
#pragma on (unreferenced)

    return(sig_ck_sig_title_var(signum, (char *)tvadd));
}
 
VLIST sig_vl[] = {
"sig_enable",		&((SIG *)NP)->sig_enable, NP, sig_sig_enable_vaf,
			    ME_BEF|ME_GB, ME_DEC,
"ad_chan",		&((SIG *)NP)->sig_ad_chan, NP, sig_ad_chan_vaf,
			    ME_BEF|ME_GB, ME_NVALD,
"ad_mem_variable",	&((SIG *)NP)->sig_ad_mem_var, NP, sig_ad_mem_var_vaf,
			    ME_BEF|ME_GB, ME_STR,
"ad_acquire_rate",	&((SIG *)NP)->sig_ad_rate, NP, sig_ad_acq_rate_vaf,
			    ME_BEF|ME_GB, ME_NVALD,
"ad_calib",		&((SIG *)NP)->sig_ad_calib, NP, sig_ad_calib_vaf,
			    ME_BEF|ME_GB, ME_NVALD,
#if (defined AD_CGLIST)
"ad_gain",		&((SIG *)NP)->sig_ad_gain, NP, sig_ad_gain_vaf,
 			    ME_BEF|ME_GB, ME_NVALD,
#endif
"ad_delay_100_us",	&((SIG *)NP)->sig_ad_delay, NP, NP,
 			    ME_GB, ME_NVALD,
"memory_source",	&((SIG *)NP)->sig_mem_source, NP, sig_mem_src_vaf,
			    ME_BEF|ME_GB, ME_STR,
"signal_store_rate",	&((SIG *)NP)->sig_store_rate, NP,
			    sig_sig_store_rate_vaf, ME_BEF|ME_GB, ME_NVALD,
"signal_title",		&((SIG *)NP)->sig_title, NP, sig_sig_title_vaf,
			    ME_BEF|ME_GB, ME_STR,
NS,
};

/*
 * Menu: "mirror"
 *-----------------------------------------------------------------------*
 */
#pragma off (unreferenced)
int
mr_vaf(int flag, MENU *mp, char *astr, VLIST *vlp, int *tvadd)
{
#pragma on (unreferenced)

	mr_set(NULLI, NULLI, NULLI);
	return(0);
}

VLIST mir_vl[] = {
"mir_menu_enab",	&m_mrmenu, NP, mr_vaf, ME_AFT, ME_DEC,
"mir_control",		&m_mrctl, NP, mr_vaf, ME_AFT, ME_NVALD,
"mir_xpos_10s",		&m_mrxpos, NP, mr_vaf, ME_AFT, ME_NVALD,
"mir_ypos_10s",		&m_mrypos, NP, mr_vaf, ME_AFT, ME_NVALD,
NS,
};

char hm_mir_vl[] = "\
mir_cont-\n\
  0: off\n\
  1: abs pos\n\
  2: wave form gen\n\
  3: joystick";

/*
 * Menu: "offsets_eye"
 *-----------------------------------------------------------------------*
 */
#pragma off (unreferenced)
int
off_vaf(int flag, MENU *mp, char *astr, VLIST *vlp, int *tvadd)
{
#pragma on (unreferenced)

	off_eye(NULLI, NULLI);
	off_oeye(NULLI, NULLI);
	return(0);
}

VLIST off_vl[] = {
"off_menu_enab",	&m_offmenu, NP, off_vaf, ME_AFT, ME_DEC,
"eyeh_off_10s",		&m_eho, NP, off_vaf, ME_AFT, ME_NVALD,
"eyev_off_10s",		&m_evo, NP, off_vaf, ME_AFT, ME_NVALD,
"oeyeh_off_10s",	&m_oeho, NP, off_vaf, ME_AFT, ME_NVALD,
"oeyev_off_10s",	&m_oevo, NP, off_vaf, ME_AFT, ME_NVALD,
NS,
};

char hm_off_vl[] = "\
Offsets in tenths\n\
of degree.  Value\n\
of 0 yields no\n\
offset.";

/*
 * Menu: "rgen(ramp)"
 *-----------------------------------------------------------------------*
 */
#pragma off (unreferenced)
int
ra_vaf(int flag, MENU *mp, char *astr, VLIST *vlp, int *tvadd)
{
#pragma on (unreferenced)

	ra_new(NULLI, NULLI, NULLI, NULLI, NULLI, NULLI, NULLI);
	return(0);
}

#pragma off (unreferenced)
int
ras0_rate_vaf(int flag, MENU *mp, char *astr, VLIST *vlp, int *tvadd)
{
#pragma on (unreferenced)

	/*
	 * Update rate must be reconciled to clock rate.
	 */
	if(*tvadd < CLOCK_RATE) *tvadd= CLOCK_RATE;
	else *tvadd -= *tvadd % CLOCK_RATE;
	return(0);
}

/*
 * Ramp generator submenu0.
 */
VLIST ras0_vl[] = {
"update_rate_ms",	&ra_urate, NP, ras0_rate_vaf, ME_BEF, ME_DEC,
#ifdef CC_RAPHI
"phidevice",		&ra_phidev, NP, NP, 0, ME_OCT,
"phiontime",		&ra_pontime, NP, NP, 0, ME_DEC,
"phiofftime",		&ra_pofftime, NP, NP, 0, ME_DEC,
#endif
NS,
};

/*
 * Ramp submenu0 menu struct.
 */
MENU ras0_me = {
"x",			&ras0_vl, NP, NP, 0, NP, NS,
};

VLIST ra_vl[] = {
"menu_enab",		&m_ramenu, NP, ra_vaf, ME_AFT, ME_DEC,
"type_flag",		&m_type, NP, ra_vaf, ME_AFT, ME_NVALO,
"length_10s",		&m_ralen, NP, ra_vaf, ME_AFT, ME_NVALD,
"angle_deg",		&m_raang, NP, ra_vaf, ME_AFT, ME_NVALD,
"velocity_deg/sec",	&m_ravel, NP, ra_vaf, ME_AFT, ME_NVALD,
"xoffset_10s",		&m_raxoff, NP, ra_vaf, ME_AFT, ME_NVALD,
"yoffset_10s",		&m_rayoff, NP, ra_vaf, ME_AFT, ME_NVALD,
"ramp_ecode",		&m_ecode, NP, ra_vaf, ME_AFT, ME_NVALD,
"submenu0",		&ras0_me, NP, NP, 0, ME_SUBMENU,
NS,
};

char hm_ra_vl[] = "\
type-\n\
  00: default- CENPT\n\
  01: NO25MS\n\
  02: CENPT\n\
  04: BEGPT\n\
 010: ENDPT";

/*
 * Menu: "running_line"
 *-----------------------------------------------------------------------*
 */
#pragma off (unreferenced)
int
rl_vaf(int flag, MENU *mp, char *astr, VLIST *vlp, int *tvadd)
{
#pragma on (unreferenced)

	if(rl_caddr != NULLI) rltab.C_addr= (void *)(rl_caddr & ~01);
	else if(rl_sig != NULLI) switch(rl_sig) {

	case 0:
	default:
		rltab.C_addr= &eyeh;
		break;
	case 1:
		rltab.C_addr= &eyev;
		break;
	case 2:
		rltab.C_addr= &otherh;
		break;
	case 3:
		rltab.C_addr= &otherv;
		break;
	case 4:
		rltab.C_addr= &mrxcur;
		break;
	case 5:
		rltab.C_addr= &mrycur;
		break;
	case 6:
		rltab.C_addr= &oeyeh;
		break;
	case 7:
		rltab.C_addr= &oeyev;
		break;
	case 8:
		rltab.C_addr= &addh;
		break;
	case 9:
		rltab.C_addr= &addv;
		break;
	case 10:
		rltab.C_addr= &joyh;
		break;
	case 11:
		rltab.C_addr= &joyv;
		break;
	}
	return(0);
}

VLIST rl_vl[] = {
"C_trace_on",		&Ctraceon, NP, NP, 0, ME_DEC,
"C_memory_add",		&rl_caddr, NP, rl_vaf, ME_AFT, ME_NVALO,
"C_signal",		&rl_sig, NP, rl_vaf, ME_AFT, ME_NVALD,
"C_scale",		&rltab.C_scale, NP, NP, 0, ME_DEC,
"C_offset", 		&rltab.C_offset, NP, NP, 0, ME_DEC,
"A_scale",		&rltab.A_scale, NP, NP, 0, ME_DEC,
"A_offset",		&rltab.A_offset, NP, NP, 0, ME_DEC,
"B_scale",		&rltab.B_scale, NP, NP, 0, ME_DEC,
"B_offset",		&rltab.B_offset, NP, NP, 0, ME_DEC,
"bar_offset",		&rltab.bar_os, NP, NP, 0, ME_DEC,
"unit_offset",		&rltab.spike_os, NP, NP, 0, ME_DEC,
"rate", 		&rlrate, NP, NP, 0, ME_DEC,
"wrap",			&rl_wrap, NP, NP, 0, ME_DEC,
NS,
};

char hm_rl_vl[] = "\
C_signal:\n\
  0: eyeh\n\
  1: eyev\n\
  2: otherh\n\
  3: otherv\n\
  4: internal mir x\n\
  5: internal mir y\n\
  6: oeyeh\n\
  7: oeyev\n\
  8: addh\n\
  9: addv\n\
 10: joyh\n\
 11: joyv\n\
C_memory_add if not '-'\n\
overrides value of C_signal.";

/*
 * Menu: "saccade_det"
 *-----------------------------------------------------------------------*
 */
#pragma off (unreferenced)
int
sd_vaf(int flag, MENU *mp, char *astr, VLIST *vlp, int *tvadd)
{
#pragma on (unreferenced)

	sd_set(NULLI);
	return(0);
}

VLIST sd_vl[] = {
"sd_control",		&m_sdctl, NP, sd_vaf, ME_AFT, ME_NVALO,
"h_range",		&limh.range, NP, NP, 0, ME_DEC,
"v_range",		&limv.range, NP, NP, 0, ME_DEC,
"peak_vel",		&peakvel, NP, NP, 0, ME_DEC,
"start_vel",		&velstart, NP, NP, 0, ME_DEC,
"end_vel",		&velend, NP, NP, 0, ME_DEC,
"max_vel",		&velmax, NP, NP, 0, ME_DEC,
"min_vel",		&velmin, NP, NP, 0, ME_DEC,
"max_dur",		&durmax, NP, NP, 0, ME_DEC,
"min_dur",		&durmin, NP, NP, 0, ME_DEC,
"delay_time",		&delay_time, NP, NP, 0, ME_DEC,
NS,
};

char hm_sd_vl[] = "\
sd_cont-\n\
  0: off\n\
  1: on";

/*
 * Menu: "stabilization"
 *-----------------------------------------------------------------------*
 */
#pragma off (unreferenced)
int
st_vaf(int flag, MENU *mp, char *astr, VLIST *vlp, int *tvadd)
{
#pragma on (unreferenced)

	stab_set(NULLI, NULLI, NULLI);
	return(0);
}

VLIST st_vl[] = {
"stab_menu_enab",	&m_stmenu, NP, st_vaf, ME_AFT, ME_DEC,
"stab_control",		&m_stctl, NP, st_vaf, ME_AFT, ME_NVALO,
"st_xoff",		&m_stxoff, NP, st_vaf, ME_AFT, ME_NVALD,
"st_yoff",		&m_styoff, NP, st_vaf, ME_AFT, ME_NVALD,
NS,
};

char hm_st_vl[] = "\
stab_cont-\n\
  00: off\n\
  01: horiz\n\
  02: vert\n\
  03: both";

/*
 * Menu: "bit"
 *-----------------------------------------------------------------------*
 */
VLIST bit_vl[] = {
"default_bit_device",	&m_bitdio, NP, NP, 0, ME_HEX,
NS,
};

char hm_bit_vl[] = "\
Default device id used\n\
for commands to set, clr\n\
the noun 'bit'";

/*
 * Menu: "trials"
 *-----------------------------------------------------------------------*
 */
VLIST tt_vl[] = {
"correct",		&tyes, NP, NP, 0, ME_DEC,
"wrong",		&tno, NP, NP, 0, ME_DEC,
NS,
};

/*
 * Menu: "windows"
 *-----------------------------------------------------------------------*
 */
#pragma off (unreferenced)
int
wd_vaf(int flag, MENU *mp, char *astr, VLIST *vlp, int *tvadd)
{
#pragma on (unreferenced)

	wd_siz(NULLI, NULLI);
	wd_osiz(NULLI, NULLI);
	wd_ctl(NULLI, NULLI, NULLI);
	wd_pos(NULLI, NULLI);

	return(0);
}

#pragma off (unreferenced)
int
wd_sc_vaf(int flag, MENU *mp, char *astr, VLIST *vlp, int *tvadd)
{
#pragma on (unreferenced)

	if(flag & ME_BEF) {
		if(*tvadd < 0 || *tvadd > MAXMAG) {
			rxerr("mag_vaf(): Illegal magnification");
			return(-1);
		}
		return(0);
	}
	wd_iscale();
	sendmsg(DISP, DS_WDNEW);
	return(0);
}
	
VLIST wdm_vl[] = {
"wd_menu_enab",		&m_wdmenu, NP, wd_vaf, ME_AFT, ME_DEC,
"wd_disp_flags",	&m_wddisp, NP, wd_vaf, ME_AFT, ME_NVALO,
"wd_control",		&m_wdctl, NP, wd_vaf, ME_AFT, ME_NVALO,
"wd_type",		&m_wdtype, NP, wd_vaf, ME_AFT, ME_NVALD,
"wd_xpos_10s",		&m_wdxpos, NP, wd_vaf, ME_AFT, ME_NVALD,
"wd_ypos_10s",		&m_wdypos, NP, wd_vaf, ME_AFT, ME_NVALD,
"wd_xsiz_10s",		&m_wdxsiz, NP, wd_vaf, ME_AFT, ME_NVALD,
"wd_ysiz_10s",		&m_wdysiz, NP, wd_vaf, ME_AFT, ME_NVALD,
"wd_oxsiz_10s",		&m_wdoxsiz, NP, wd_vaf, ME_AFT, ME_NVALD,
"wd_oysiz_10s",		&m_wdoysiz, NP, wd_vaf, ME_AFT, ME_NVALD,
"eye_mag",		((char *)&((INT_BLOCK *)NP)->d_emag -
				(char *)&((INT_BLOCK *)NP)->INT_BLOCK_FIRST),
			NP, wd_sc_vaf, ME_BEF|ME_AFT|ME_IBLOCK, ME_DEC,
"offsets_mag",		((char *)&((INT_BLOCK *)NP)->d_omag -
				(char *)&((INT_BLOCK *)NP)->INT_BLOCK_FIRST),
			NP, wd_sc_vaf, ME_BEF|ME_AFT|ME_IBLOCK, ME_DEC,
NS,
};

char hm_wdm_vl[] = "\
wd_disp_flags-\n\
  01: eye on\n\
  02: oeye on\n\
  04: eye offset on\n\
 010: oeye offset on\n\
 020: joystick on\n\
 040: grid on\n\
0100: frame on\n\
wd_control-\n\
  00: off\n\
  01: eye_on\n\
  02: oeye_on\n\
  03: both_on\n\
wd_type-\n\
  0: abs pos\n\
  1: mir\n\
  2: ramp\n\
  3: joystick";

/*
 *-----------------------------------------------------------------------*
 * Noun table.
 *-----------------------------------------------------------------------*
 */
NOUN nouns[] = {
	"bit",		&n_bit,
	"clock",	&n_clock,
	"statelist",	&n_slist,
	"mirror",	&n_mirror,
	"cal_values",	&n_calib,
	"signals",	&n_signals,
	"",
};

/*
 *-----------------------------------------------------------------------*
 * Top level menu table.
 *-----------------------------------------------------------------------*
 */
extern VLIST state_vl[];
extern char hm_sv_vl[];
MENU menus[] = {
"control_param",	&cp_vl, NP, cp_maf, ME_BEF, NP, hm_cp_vl,
"signals",		&sig_vl, NP, sig_maf, ME_BEF, sig_agf, hm_sig_vl,
"mirror",		&mir_vl, NP, NP, 0, NP, hm_mir_vl,
"offsets_eye",		&off_vl, NP, NP, 0, NP, hm_off_vl,
"rgen(ramp)",		&ra_vl, NP, NP, 0, NP, hm_ra_vl,
"running_line",		&rl_vl, NP, NP, 0, NP, hm_rl_vl,
"state_vars",		&state_vl, NP, NP, 0, NP, hm_sv_vl,
"saccade_det",		&sd_vl, NP, NP, 0, NP, hm_sd_vl,
"stabilization",	&st_vl, NP, NP, 0, NP, hm_st_vl,
"bit",			&bit_vl, NP, NP, 0, NP, hm_bit_vl,
"trials",		&tt_vl, NP, NP, 0, NP, NS,
"windows",		&wdm_vl, NP, NP, 0, NP, hm_wdm_vl,
NS,
};
