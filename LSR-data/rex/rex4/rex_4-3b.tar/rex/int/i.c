/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government.  The original
 * versions, REX 1.0-3.12, were developed for the pdp11 architecture and
 * distributed without restrictions.  This version, REX 4.0, is a port of
 * the original version to the Intel 80x86 architecture.  This version is
 * distributed only under license agreement from the National Institutes 
 * of Health, Laboratory of Sensorimotor Research, Bldg 10 Rm 10C101, 
 * 9000 Rockville Pike, Bethesda, MD, 20892, (301) 496-9375.
 *-----------------------------------------------------------------------*
 */

/*
 *	Initializations for int process.
 *
 */
#include <stdio.h>
#include <signal.h>
#include <sys/types.h>
#include "../hdr/sys.h"
#include "../hdr/cnf.h"
#include "../hdr/phys.h"
#include "../hdr/proc.h"
#include "../hdr/buf.h"
#include "../hdr/menu.h"
#include "../hdr/device.h"
#include "../hdr/state.h"
#include "../hdr/ecode.h"
#include "../hdr/sac.h"
#include "../hdr/cdsp.h"
#include "../hdr/idsp.h"
#ifdef CC_RAMP
#include "../hdr/ramp.h"
#endif
#include "../hdr/int.h"

/*
 * Version identifier for int process.
 */
char version[P_LVERSION]= "4.3b, 14 Dec 93";

INT_BLOCK_P i_b;
RAW_BLOCK_P r_b;
PARAM param;
int paramfd;
int myptx= -1;
PROCTBL_P myptp= NP;
char NS[] = "";
sigset_t alert_set;
int errprt;
int error1, error2;

/*
 * Used in interrupt routine proper.
 */
SAMP samp;
int *sa_gvptr[SA_MAXSIG];
int ad_cglist[AD_CHANNELS];
int ad_max_rate= AD_RATE;
int ad_min_rate;
int ad_ov_gain= 1;
short *sa_frame;
int sa_mfrbeglx;
long sa_mfrbegtime;
int sa_1msec_ctd;
int sa_int_P_ms;
int adumpinc= ADUMPINC;
int fillcheck;
int st_rate= ST_RATE;
int eyeh, eyev;		/* space for adc values */
int otherh, otherv;	/* place where other channels are stored */
int oeyeh, oeyev;	/* other eye values */
int addh, addv;		/* additional channels to make up to 8 */
int joyh, joyv;		/* joystick channels */
int sp_lock, ds_lock;	/* locks to prevent re-entering state
			   set proc and display */
int phistate, phicount;
int Ctcount, Cstate;
long c_count;			/* continuation record count */
long awtime;			/* analog write time */
int winrate;			/* rate for eye window check */
int rurate;			/* ramp update rate */
int hiwat;			/* high water point for writing to disk */
int windcnt;			/* fill count of unwritten data for
				   the current window opening */
int postcnt;			/* count of samples to save after window
				   closes */
int lowx;			/* low index for next write of analog buffers */
int lasthighx;		/* last high index of write, or open index */
int mrxout= NULLI, mryout= NULLI;
int st_count;
int m_bitdio= BIT_DEFAULT;	/* default device for noun 'bit' */
sigset_t sig_state;
int int_request;
unsigned w_flags;	/* flags for write processing */
int scrb_msg, disp_msg, comm_msg, flag_msg;
int w_pre= W_PRE;
int w_post= W_POST;
int m_pre= NULLI, m_post= NULLI;
int m_uwind= NULLI, uwind= 1;	/* unit window control */
unsigned sig_flags;		/* flags for signalling */
int dina, dinb;		/* digital input words */
int noflag;
int tyes, tno;
ESCAPE *firstesc;

/*
 * Running line.
 */
struct matbuf matbuf[WDI_RIGHT] = {0};
struct rltab rltab = {
	-3,	&eyeh,	    370,		/* Chan A */
	-3,	&eyev,	    250,		/* Chan B */
	-3,	&otherh,    170,		/* Chan C */
	10,					/* bar offset */
	90,					/* spike offset */
};
    
/*
 * Running line.
 */
int rlrate= 16;		/* display rate; every 16 ms */
int astate, aspike, amarkA, amarkB, addtmp, aindex;
int Ctraceon= 1;
int rl_wrap= 0;
int bindex= 1, balk, run_count= 1;
int rl_caddr= NULLI, rl_sig= 2;
int rline=	CHANA|CHANB|CHANC|BARL|SPIKES|MARKA|MARKB;
int rlinenew=	CHANA|CHANB|CHANC|BARL|SPIKES|MARKA|MARKB;

/*
 * Eye window and window display.
 */
int c_eyeshift;
int t_wrate= 10;
int w_rate= 27;		/* matrox working at 50hz frame rate */
int m_wdmenu, m_wdctl= NULLI, m_wdxpos= NULLI, m_wdypos= NULLI;
int m_wdxsiz= NULLI, m_wdysiz= NULLI;
int m_wdoxsiz= NULLI, m_wdoysiz= NULLI;
int m_wdtype= NULLI;
int m_wddisp= NULLI;
int wdxsiz, wdysiz, wdxpos, wdypos;
int wdoxsiz, wdoysiz;
int *wdxptr= &mrxpos, *wdyptr= &mrypos;
int wdctl;
int wdtype;
int wdchange;

/*
 * Eye offsets.
 */
int m_offmenu;
int m_eho= NULLI, m_evo= NULLI;
int m_oeho= NULLI, m_oevo= NULLI;
int eho, evo, oeho, oevo;

/*
 * Window display cursors.
 */
int c_eye[] = {			/* eye position cursor */

/*
 * 12 dot Cross.
 */
	1,1,0,
	2,2,0,
	3,3,0,
	-1,1,0,
	-2,2,0,
	-3,3,0,
	-1,-1,0,
	-2,-2,0,
	-3,-3,0,
	1,-1,0,
	2,-2,0,
	3,-3,0,
	0,0,-1,
};

CURSOR c_oeye[] = {		/* other eye */

/*
 * 12 dot circle, radius 3.
 */
 	3,0,0,
	3,1,0,
	1,3,0,
	0,3,0,
	-1,3,0,
	-3,1,0,
	-3,0,0,
	-3,-1,0,
	-1,-3,0,
	0,-3,0,
	1,-3,0,
	3,-1,0,
	0,0,-1,
};
	
CURSOR c_cen[] = {		/* center of screen */

/*
 * 16 dot square.
 */
 	2,0,0,
 	2,1,0,
 	2,2,0,
 	1,2,0,
 	0,2,0,
 	-1,2,0,
 	-2,2,0,
 	-2,1,0,
 	-2,0,0,
 	-2,-1,0,
 	-2,-2,0,
 	-1,-2,0,
 	0,-2,0,
 	1,-2,0,
 	2,-2,0,
 	2,-1,0,
	0,0,-1,
};

/*
 * Cursors for eye offset indicator marks.
 */
CURSOR c_0mark[] = {

/*
 * Cross.
 */
	1,1,0,
	2,2,0,
	3,3,0,
	-1,1,0,
	-2,2,0,
	-3,3,0,
	-1,-1,0,
	-2,-2,0,
	-3,-3,0,
	1,-1,0,
	2,-2,0,
	3,-3,0,
	0,0,-1,
};

CURSOR c_1mark[] = {

/*
 * Cross.
 */
	1,1,0,
	2,2,0,
	3,3,0,
	-1,1,0,
	-2,2,0,
	-3,3,0,
	-1,-1,0,
	-2,-2,0,
	-3,-3,0,
	1,-1,0,
	2,-2,0,
	3,-3,0,
	0,0,-1,
};

CURSOR c_2mark[] = {

/*
 * 12 dot circle, radius 3.
 */
 	3,0,0,
	3,1,0,
	1,3,0,
	0,3,0,
	-1,3,0,
	-3,1,0,
	-3,0,0,
	-3,-1,0,
	-1,-3,0,
	0,-3,0,
	1,-3,0,
	3,-1,0,
	0,0,-1,
};


CURSOR c_3mark[] = {

/*
 * 12 dot circle, radius 3.
 */
 	3,0,0,
	3,1,0,
	1,3,0,
	0,3,0,
	-1,3,0,
	-3,1,0,
	-3,0,0,
	-3,-1,0,
	-1,-3,0,
	0,-3,0,
	1,-3,0,
	3,-1,0,
	0,0,-1,
};


/*
 * The window position cursor is defined by the code that draws it in
 * int.c.  It is changed whenever the window size or display mag is
 * changed.  The definition here must declare enough space for the
 * number of dots in the cursor.
 */ 
CURSOR c_wind[] = {		/* window position cursor, 8 points */
	0,0,0,
	0,0,0,
	0,0,0,
	0,0,0,
	0,0,0,
	0,0,0,
	0,0,0,
	0,0,0,
	0,0,-1,
};

CURSOR c_owind[] = {		/* wind cursor for other eye, 12 points */
	0,0,0,
	0,0,0,
	0,0,0,
	0,0,0,
	0,0,0,
	0,0,0,
	0,0,0,
	0,0,0,
	0,0,0,
	0,0,0,
	0,0,0,
	0,0,0,
	0,0,-1,
};

CURSOR c_mir[] = {		/* mirror */

/*
 * 8 dot diamond.
 */
	2,0,0,
	1,1,0,
	0,2,0,
	-1,1,0,
	-2,0,0,
	-1,-1,0,
	0,-2,0,
	1,-1,0,
	0,0,-1,
};

CURSOR c_joy[] = {		/* joystick */

/*
 * 12 dot 'J'
 */
	1,3,0,
	1,2,0,
	1,1,0,
	1,0,0,
	1,-1,0,
	1,-2,0,
	1,-3,0,
	0,-3,0,
	-1,-3,0,
	-2,-3,0,
	-2,-2,0,
	-2,-1,0,

	0,0,-1,
};

/*
 * Cursor initializations.
 */
WINDISP windisp[] = {
	{0,0,0,0,0,0,0,&c_eye},
	{0,0,0,0,0,0,WDI_SWON,&c_cen},
	{0,0,0,0,0,0,0,&c_wind},
	{0,0,0,0,0,0,0,&c_mir},
 	{0,0,0,0,0,0,0,&c_oeye},
 	{0,0,0,0,0,0,0,&c_0mark},
 	{0,0,0,0,0,0,0,&c_1mark},
 	{0,0,0,0,0,0,0,&c_2mark},
 	{0,0,0,0,0,0,0,&c_3mark},
	{0,0,0,0,0,0,0,&c_owind},
	{0,0,0,0,0,0,0,&c_joy},
};

/*
 * Mirror control.
 */
int m_mrmenu, m_mrxpos= NULLI, m_mrypos= NULLI, m_mrctl= NULLI;
int mrctl, mrxpos, mrypos, mrxcur, mrycur;

/*
 * Stabilization control.
 */
int m_stmenu, m_stctl= NULLI, m_stxoff= NULLI, m_styoff= NULLI;
int stctl, stxoff, styoff;

/*
 * Saccade detector.
 */
struct lim limh= {			/* horizontal defaults */
	0, RANGE, 0 + RANGE, 0 - RANGE
};
struct lim limv= {			/* vertical */
	0, RANGE, 0 + RANGE, 0 - RANGE
};

int m_sdctl= NULLI;
int sdctl;
int sacstate, sacflags, duration;
long sacontime;
int timeout, delay_time=DELAY;
int *aval, *bval, *newval, *sacfillp;
struct lim *limp;
int sacstack[STSIZE] = {0};
int peakvel;
int velstart= VELSTART, velend= VELEND, velmax= VELMAX, durmax= DURMAX;
int velmin= VELMIN;
int durmin= DURMIN, h_sacinit, h_sacend, h_sacsize;
int v_sacinit, v_sacend, v_sacsize;
int eyeflag;

/*
 * Ramp generator.
 */
#ifdef CC_RAMP
struct ra_p ra_x = {0}, ra_y = {0};
unsign ra_duration, ra_timeleft;
int rampflag;
int m_ramenu, m_type= NULLI, m_ralen= NULLI, m_raang= NULLI;
int m_ravel= NULLI, m_raxoff= NULLI, m_rayoff= NULLI, m_ecode= NULLI;
int ra_len, ra_ang, ra_vel, ra_xoff, ra_yoff, ra_type;
int ra_vfactor= 4;
int ra_wtime;
int ra_urate= 3;
int ra_state= RA_OFF;
DIO_ID ra_device;
int ra_ecode;
int ra_xflag;
int ra_pontime= 1, ra_pofftime= 99, ra_phiflag;
DIO_ID ra_phidev;
#endif

/*
 * Calibration paradigms.
 */
int c_fp, c_dim, c_curp, c_xhold, c_yhold, c_oxhold, c_oyhold;
struct c_eyekeep c_eyekeep[C_KEEPMAX] = {0};

/*
 * Dummy p_rxerr to resolve reference from rxerr().
 */
p_rxerr()
{
}
