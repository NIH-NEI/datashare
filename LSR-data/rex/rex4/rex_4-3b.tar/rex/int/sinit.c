/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government.  The original
 * versions, REX 1.0-3.12, were developed for the pdp11 architecture and
 * distributed without restrictions.  This version, REX 4.0, is a port of
 * the original version to the Intel 80x86 architecture.  This version is
 * distributed only under license agreement from the National Institutes 
 * of Health, Laboratory of Sensorimotor Research, Bldg 10 Rm 10C101, 
 * 9000 Rockville Pike, Bethesda, MD, 20892, (301) 496-9375.
 *-----------------------------------------------------------------------*
 */

/*
 * 	Initialize state lists.  Called from main, and whenever a
 * reset is done.  These functions CAN be run at interrupt level;
 * interrupt level restrictions apply.
 */

#include <stdio.h>
#include <sys/types.h>
#include "../hdr/sys.h"
#include "../hdr/proc.h"
#include "../hdr/menu.h"
#include "../hdr/state.h"
#include "../hdr/int.h"

static int first= 1;

void
stateinit(void)
{
	AWAKE *pawake;
	STATE *pstate;
	ESCAPE *pescape;

	AWAKE *pre, *post;
	extern AWAKE nowstate[];
	extern ESCAPE *firstesc;
	extern STATE sps_state;

	pre = post = 0;

	/* link each chain */
	for (pawake = nowstate, pstate = pawake->initial_state;
	pstate; pstate = (++pawake)->initial_state) {


		/* set up list pointers in each escape */
		if (first == 0) {	/* reset last escape */
			/* zero the current next escape link */
			pawake->lastesc->nextesc = 0;

			/* find first state's last escape */
			for (pescape = &pstate->escape;
				pescape->nextesc; pescape++);

			/* save its address */
			pawake->lastesc = pescape;
		}
		else setstate(pstate,pawake);

		/* re-set post pointer in prestate */
		if (pre) {
			pre->poststate = (STATE *)pawake;
			pre->lastesc->nextesc = &pstate->escape;
		}

		/* set pre pointer */
		pawake->prestate = (STATE*)pre;
		pre = pawake;

		/* set up post pointers, assuming last state */
		pawake->poststate = 0;
		pawake->lastesc->nextesc = 0;

	}

	/* set up first escape */
	if (first == 0) firstesc = &nowstate[0].initial_state->escape;
	else {
		firstesc = &sps_state.escape;

		/* no longer first time through */
		first = 0;
	}
}

/*
 * Set up state list pointers.
 */
void
setstate(STATE *pstate, AWAKE *pawake)
{
	ESCAPE *pescape;

	/* if pointers are already set, done */
	if (pstate->escape.awakestate) return;

/*
if (first) printf("STATE:  %s\n",pstate->statename);
*/

	for (pescape = &pstate->escape;
	pescape->stateptr; pescape++) {

		/* set up chain pointer */
		pescape->awakestate = pawake;

		/* set up next pointer */
		pescape->nextesc = pescape + 1;

		/* set up escape state */
		setstate(pescape->stateptr, pawake);
	}

	/* set up correct lastesc pointer */
	pawake->lastesc = --pescape;

	/* correct previous next escape pointer */
	pescape->nextesc = 0;
}

/*
 * Called when reinitialize statelist command is executed.
 */
void
again(void)
{
	extern STATE sps_state;
	extern ESCAPE *firstesc;

	firstesc = &sps_state.escape;
}
