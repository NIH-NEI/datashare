/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government, is in the
 * public domain, and cannot be copywrited.  For further information
 * contact:  Laboratory of Sensorimotor Research, National Eye Institute,
 * National Institutes of Health, Bldg 10 Rm 6C420, Bethesda, MD, 20205.
 *-----------------------------------------------------------------------*
 */

/*
 *	Tail end symbol to verify size of int process.
 */

int xinterrupt 0;
