/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government.  The original
 * versions, REX 1.0-3.12, were developed for the pdp11 architecture and
 * distributed without restrictions.  This version, REX 4.0, is a port of
 * the original version to the Intel 80x86 architecture.  This version is
 * distributed only under license agreement from the National Institutes 
 * of Health, Laboratory of Sensorimotor Research, Bldg 10 Rm 10C101, 
 * 9000 Rockville Pike, Bethesda, MD, 20892, (301) 496-9375.
 *-----------------------------------------------------------------------*
 */

/*
 *	Device specific code for int process.  Conditionally compiled
 * from defines in ../hdr/cnf.h.
 */
#include <stdio.h>
#include <signal.h>
#include <conio.h>
#include <sys/types.h>
#include <sys/timers.h>
#include <sys/irqinfo.h>
#include <sys/proxy.h>
#include <sys/seginfo.h>
#include <sys/kernel.h>
#include "../hdr/sys.h"
#include "../hdr/cnf.h"
#include "../hdr/phys.h"
#include "../hdr/proc.h"
#include "../hdr/buf.h"
#include "../hdr/device.h"
#include "../hdr/menu.h"
#include "../hdr/dma.h"
#include "../hdr/int.h"

/*
 *---------------------------------------------------------------------*
 * Clock.
 *---------------------------------------------------------------------*
 */
timer_t tid= 0;
struct itimercb timercb= {0}, timercb_init= {0};
struct itimerspec timer= {0}, timer_init= {0};
#define NANO_TO_MSEC 1000000L;

void
clk_stop(void)
{
	struct sigaction act;

	if(rmtimer(tid) == -1) {
	    rxerr("clk_stop(): cannot remove timer");
	}
	act.sa_flags= 0;
	act.sa_mask= 0;
	act.sa_handler= SIG_DFL;
	if(sigaction(S_STATESIG, &act, NULL) == -1) {
	    rxerr("clk_stop(): cannot sigaction-1");
	    return;
	}
	clk_set(TIMER_DEFAULT);
	i_b->i_flags &= ~ I_GO;
}

/*
 * Initialize clock and set rate.
 */
void
clk_set(int msec)
{
    long period;

    period= msec * NANO_TO_MSEC;
    if(qnx_timerperiod(period) == -1)
	rxerr("clk_set(): cannot set period");
}

void
clk_start(void)
{
	struct sigaction act;
	sigset_t block_set;

	/*
	 * Dont allow REX IPC signals while in state processor.
	 */
	sigemptyset(&block_set);
	sigaddset(&block_set, S_ALERT);
	sigaddset(&block_set, S_DEBUG_PRINT);

	act.sa_flags= 0;
	act.sa_mask= block_set;
	act.sa_handler= &msec_clock;
	if(sigaction(S_STATESIG, &act, NULL) == -1)
	    rxerr("clk_go(): cannot sigaction-2");
	clk_set(CLOCK_RATE);

	/*
	 * Create timer.
	 */
	timercb= timercb_init;	    /* set to zero */
	timercb.itcb_event.evt_value= S_STATESIG;
	if((tid= mktimer(TIMEOFDAY, _TNOTIFY_SIGNAL, &timercb)) == -1) {
	    rxerr("clk_go(): cannot make timer");
	    return;
	}
	timer= timer_init;	    /* set to zero */
	timer.it_value.tv_nsec= CLOCK_RATE * NANO_TO_MSEC; 
	timer.it_interval.tv_nsec= CLOCK_RATE * NANO_TO_MSEC;
	if(reltimer(tid, &timer, NULL) == -1) {
	    rxerr("clk_go(): cannot arm timer");
	    return;
	}
	i_b->i_flags |= I_GO;
}

/*
 *----------------------------------------------------------------------*
 * A/D Support.
 *----------------------------------------------------------------------*
 */
unsigned counter;
int int_id;

void
ad_start(void)
{

    /*
     * Init a/d board.
     */
    if(ad_ds_init() == -1) return;

    /*
     * Attach to a/d interrupt.
     */
    if(int_id == 0) {
	if((int_id= qnx_hint_attach(AD_VECT, &ad_int_hand, FP_SEG(&counter)))
		== -1) {
		    rxerr("Cannot attach to a/d interrupt");
		    int_id= 0;
		    return;
	}
    }

    /*
     * Start a/d.
     */
    ad_ds_begin();
}

void
ad_stop(void)
{
    /*
     * Stop a/d.
     */
    ad_ds_end();

    /*
     * Detach interrupt.
     */
    if(int_id) {
	if(qnx_hint_detach(int_id) == -1) {
	    rxerr("Cannot detach a/d interrupt");
	    return;
	}
    }
    int_id= 0;

    /*
     * Clean up.
     */
    ad_ds_uninit();
}

/*
 *----------------------------------------------------------------------*
 * Device specific routines for a/d support.
 *----------------------------------------------------------------------*
 */

/*
 * Data Translation DT2821.  Has 16 bit AT interface, DMA, 2 d/a channels,
 * an 16 bits of digital I/O.  Operated in dual-dma mode.
 * ----------------------------------------------------------------------
 */
#ifdef DT2821

u_int ad_sel= -1;
DMA dma_a= {0}, dma_b= {0};
int int_a;		/* signifies which dma buffer was loaded
			   with dual dma */

int
ad_ds_init(void)
{
    struct _seginfo sbuf;
    int rval;
    
    /*
     * Setup DMA controller.  Operate the DT2821 in dual-dma mode
     * using 2 16 bit channels.  All 8 channels are sampled and stored
     * each msec.
     */

    /*
     * Get segment for dma buffer.
     */
    if(ad_sel == -1) {
	if((ad_sel= qnx_segment_alloc_flags(64, _PMF_DMA_SAFE)) == -1) {
	    rxerr("Cannot alloc a/d DMA segment");
	    return(-1);
	}
    }
    if(qnx_segment_info(0, 0, ad_sel, &sbuf) == -1) {
	    rxerr("Cannot 'qnx_segment_info' on a/d DMA segment");
	    return(-1);
    }
#ifdef NEED_FAR
    dma_a.dma_lbufp= MK_FP(ad_sel, 0);
#endif
    dma_a.dma_pbufp.dma_phys= sbuf.addr;
    dma_a.dma_chan= DT0_DMACHAN1;
    dma_a.dma_mode= (DMA_M_WRITE | DMA_M_AUTOINIT | DMA_M_SINGLE);
    dma_a.dma_bcount= 16;
    dma_a.dma_inuse= 1;
    if((rval= dma_init(&dma_a)) != 0) return(rval); 

#ifdef NEED_FAR
    dma_b.dma_lbufp= MK_FP(ad_sel, 16);
#endif
    dma_b.dma_pbufp.dma_phys= sbuf.addr + 16;
    dma_b.dma_chan= DT0_DMACHAN2;
    dma_b.dma_mode= (DMA_M_WRITE | DMA_M_AUTOINIT | DMA_M_SINGLE);
    dma_b.dma_bcount= 16;
    dma_b.dma_inuse= 1;
    if((rval= dma_init(&dma_b)) != 0) return(rval); 
    int_a= 0;
    return(0);
}

int
ad_ds_uninit(void)
{

    dma_uninit(&dma_a); dma_uninit(&dma_b);
    dma_a.dma_inuse= 0, dma_b.dma_inuse= 0;

    if(ad_sel != -1) {
	if(qnx_segment_free(ad_sel) == -1) {
	    rxerr("ad_ds_uninit(): Cannot free a/d DMA segment");
	    return(-1);
	}
	ad_sel= -1;
    }
    return(0);
}

void
ad_ds_begin(void)
{
    int i;
    
    outpw(DT0_TMRCTR_RW, 0x4e0);	    /* 8 khz */
    outpw(DT0_SCSR_RW, DT0_CLRDMADNE|DT0_BUFFB|DT0_INIT|DT0_DACINIT);

    /*
     * Write channel-gain list into onboard RAM.
     */
    outpw(DT0_CHANCSR_RW, DT0_LLE|(8-1));	/* sample 8 channels */
    for(i= 0; i < AD_CHANNELS; i++) outpw(DT0_ADCSR_RW,
		(((ad_cglist[i] & 03) << 4) | i));
    outpw(DT0_CHANCSR_RW, (8-1));		/* clear DT0_LLE */
    outpw(DT0_ADCSR_RW, DT0_CLK|DT0_IA);
    outpw(DT0_SCSR_RW,
	  DT0_ERRINT|DT0_DUALDMA|DT0_CLKDMA|DT0_PRLD);   /* preload mux */
    while(inpw(DT0_ADCSR_RW) & DT0_MUXBUSY);    /* wait until mux settles */
    outpw(DT0_SCSR_RW,
	  DT0_ERRINT|DT0_DUALDMA|DT0_CLKDMA|DT0_STRIG);  /* start */

#ifdef GOO
doutput_rot= 0;
{
	int far *bp= (int far *)dma_a.dma_lbufp;
	int i;

	for(i= 0; i < 16; i++) bp[i]= 0x0;
}
    while(1) {
	static u_int a, asav, b, bsav, c, csav, d, dsav, e, esav;
	extern DMA_8237 dma_8237[];
	DMA_8237 *dp= &dma_8237[6], *ep= &dma_8237[7];
	int far *bp= (int far *)dma_a.dma_lbufp;
	int i;
	
	outp(dp->dma_bptr, 0);
	d= inp(dp->dma_wc);
	d |= (inp(dp->dma_wc) << 8) & 0xff00;
	e= inp(ep->dma_wc);
	e |= (inp(ep->dma_wc) << 8) & 0xff00;
	if(d != dsav) {
	    dsav= d;
	    dprintf(" dc %x ", d);
	    dputchar('\n');
	    for(i= 0; i< 8; i++) dprintf("%x ", bp[i]);
	    dputchar('_');
	    for(i= 8; i< 16; i++) dprintf("%x ", bp[i]);
	}
	if(e != esav) {
	    esav= e;
	    dprintf(" ec %x ", e);
	    dputchar('\n');
	    for(i= 0; i< 8; i++) dprintf("%x ", bp[i]);
	    dputchar('_');
	    for(i= 8; i< 16; i++) dprintf("%x ", bp[i]);
	}
    }
#endif
}

void
ad_ds_end(void)
{
    outpw(DT0_ADCSR_RW, 0);
}
#endif

/*
 * National Instruments AT-MIO-16.  Has 16 bit AT interface, DMA,
 * 2 D/A channels, 8 bits of digital I/O.  Operated in dual
 * dma mode.
 * ----------------------------------------------------------------------
 */
#ifdef NIATMIO

u_int ad_sel= -1;
DMA dma_a= {0}, dma_b= {0};
int int_a;		/* signifies which dma buffer was loaded
			   with dual dma */

int
ad_ds_init(void)
{
    struct _seginfo sbuf;
    int rval;
    
    /*
     * Setup DMA controller.  Operate in dual-dma mode
     * using 2 16 bit channels.  All 8 channels are sampled and stored
     * each msec.
     */

    /*
     * Get segment for dma buffer.
     */
    if(ad_sel == -1) {
	if((ad_sel= qnx_segment_alloc_flags(64, _PMF_DMA_SAFE)) == -1) {
	    rxerr("Cannot alloc a/d DMA segment");
	    return(-1);
	}
    }
    if(qnx_segment_info(0, 0, ad_sel, &sbuf) == -1) {
	    rxerr("Cannot 'qnx_segment_info' on a/d DMA segment");
	    return(-1);
    }
#ifdef NEED_FAR
    dma_a.dma_lbufp= MK_FP(ad_sel, 0);
#endif
    dma_a.dma_pbufp.dma_phys= sbuf.addr;
    dma_a.dma_chan= NI0_DMACHAN1;
    dma_a.dma_mode= (DMA_M_WRITE | DMA_M_AUTOINIT | DMA_M_SINGLE);
    dma_a.dma_bcount= 16;
    dma_a.dma_inuse= 1;
    if((rval= dma_init(&dma_a)) != 0) return(rval); 

#ifdef NEED_FAR
    dma_b.dma_lbufp= MK_FP(ad_sel, 16);
#endif
    dma_b.dma_pbufp.dma_phys= sbuf.addr + 16;
    dma_b.dma_chan= NI0_DMACHAN2;
    dma_b.dma_mode= (DMA_M_WRITE | DMA_M_AUTOINIT | DMA_M_SINGLE);
    dma_b.dma_bcount= 16;
    dma_b.dma_inuse= 1;
    if((rval= dma_init(&dma_b)) != 0) return(rval); 
    int_a= 0;
    return(0);
}

int
ad_ds_uninit(void)
{

    dma_uninit(&dma_a); dma_uninit(&dma_b);
    dma_a.dma_inuse= 0, dma_b.dma_inuse= 0;

    if(ad_sel != -1) {
	if(qnx_segment_free(ad_sel) == -1) {
	    rxerr("ad_ds_uninit(): Cannot free a/d DMA segment");
	    return(-1);
	}
	ad_sel= -1;
    }
    return(0);
}

void
ad_ds_begin(void)
{
    int i;

    /*
     * Init the board.
     */
    ad_ds_end();

    /*
     * Load channel-gain list.
     */
    for(i= 0; i <= 7; i++) {
	outpw(NI0_MUXCNT_WO, i);
	outpw(NI0_MUXGAIN_WO, (((cg_list[i].cg_gain & 03) << 6)
			       | (cg_list[i].cg_chan)
			       | (i == 7 ? NI0_LASTONE : 0x0)));
    }

    /*
     * Program counter 4- sample counter.
     * Want sampling to continue indefinitely, so program counter 4
     * to have a high output (a falling edge on OUT4 disables counter
     * 3).  Do this by setting up counter to generate a low TC pulse,
     * but dont arm counting!  Output will stay high indefinetly.
     */
    outpw(NI0_TCOM_WO, 0xff04); NI0_delay;
    outpw(NI0_TDATA_RW, 0x5); NI0_delay;    /* active low TC */
    outpw(NI0_TCOM_WO, 0xff0c); NI0_delay;
    outpw(NI0_TDATA_RW, 0x10); NI0_delay;   /* some positive count */
    outpw(NI0_TCOM_WO, 0xff48); NI0_delay;  /* load counter 4 */
    outpw(NI0_TCOM_WO, 0xfff4); NI0_delay;  /* dec counter 4 */

    /*
     * Program counter 3- sample interval counter.
     * Set it to do conversions at a 20Khz rate.  Sample 8 channels
     * every msec.
     */
    outpw(NI0_TCOM_WO, 0xff03); NI0_delay;
    outpw(NI0_TDATA_RW, 0x8c25); NI0_delay; /* 100Khz clock input */
    outpw(NI0_TCOM_WO, 0xff0b); NI0_delay;
    outpw(NI0_TDATA_RW, 0x2); NI0_delay;
    outpw(NI0_TCOM_WO, 0xff44); NI0_delay;
    outpw(NI0_TCOM_WO, 0xfff3); NI0_delay;
    outpw(NI0_TDATA_RW, 5); NI0_delay;    /* 5 counts @ 100Khz = 20Khz */
    outpw(NI0_TCOM_WO, 0xff24); NI0_delay;  /* arm counter 3 */

    /*
     * Program counter 2- scan interval counter.
     * Set it to do a scan of all 8 channels every msec.
     */
    outpw(NI0_TCOM_WO, 0xff02); NI0_delay;
    outpw(NI0_TDATA_RW, 0x8d25); NI0_delay; /* 10Khz clock input */
    outpw(NI0_TCOM_WO, 0xff0a); NI0_delay;
    outpw(NI0_TDATA_RW, 0x2); NI0_delay;
    outpw(NI0_TCOM_WO, 0xff42); NI0_delay;
    outpw(NI0_TCOM_WO, 0xfff2); NI0_delay;
    outpw(NI0_TDATA_RW, 10); NI0_delay;    /* 10 counts @ 10Khz = 1Khz */
    outpw(NI0_TCOM_WO, 0xff22); NI0_delay;  /* arm counter 2 */

    /*
     * Set up a/d.
     */
    outpw(NI0_ADCLR_ST, 0x0);	    /* clear a/d fifo */
    outpw(NI0_MUXCNT_WO, 0x0);	    /* set to first channel */
    outpw(NI0_INT2CLR_WO, 0x0);	    /* clear any spurious edge from
				       programming counter 2 */
    Wsetport_WO(NI0_COM1_WO_P, ni0_com1,
	NI0_SCANEN | NI0_DAQEN | NI0_DMAEN | NI0_DBDMA | NI0_TCINTEN, 0x0);
    Wsetport_WO(NI0_COM2_WO_P, ni0_com2,
	NI0_SCN2 | NI0_INTEN, 0x0);
    outpw(NI0_TCINT_WO, 0x0);	    /* clear TC register */
    outpw(NI0_STDAQ_ST, 0x0);	    /* start a/d */

#ifdef GOO
doutput_rot= 0;
{
    int stat_sav= 0;
    int stat_new;

    while(1) {
	stat_new= inpw(NI0_STAT_RO);
	if(stat_new != stat_sav) {
	    dprintf(" %x ", stat_new);
	    stat_sav= stat_new;
	}
    }
}
#endif
}

void
ad_ds_end(void)
{
    int i;
    
    /*
     * Init the board.  This sequence is detailed in the manual on page
     * 3-36.
     */
    Wsetport_WO(NI0_COM1_WO_P, ni0_com1, 0x0, 0xffff);
    Wsetport_WO(NI0_COM2_WO_P, ni0_com2, 0x0, 0xffff);
    outpw(NI0_MUXGAIN_WO, 0x0);
    outpw(NI0_TCOM_WO, 0xffff); NI0_delay;
    outpw(NI0_TCOM_WO, 0xffef); NI0_delay;
    outpw(NI0_TCOM_WO, 0xff17); NI0_delay;
    outpw(NI0_TDATA_RW, 0xf000); NI0_delay;
    for(i=1; i <= 5; i++) {
	outpw(NI0_TCOM_WO, 0xff00 + i); NI0_delay;

	/*
	 * Disable counters 4, 5 (the sample counters- we dont use).
	 */
	if(i == 4  || i == 5) outpw(NI0_TDATA_RW, 0x0);
	else outpw(NI0_TDATA_RW, 0x4);
	NI0_delay;
	outpw(NI0_TCOM_WO, 0xff08 + i); NI0_delay;
	outpw(NI0_TDATA_RW, 0x3); NI0_delay;
    }
    outpw(NI0_TCOM_WO, 0xff5f); NI0_delay;
    outpw(NI0_ADCLR_ST, 0x0);
    outpw(NI0_INT2CLR_WO, 0x0);
    outpw(NI0_TCINT_WO, 0x0);
    outpw(NI0_DAC0_WO, 0x0);
    outpw(NI0_DAC1_WO, 0x0);
}
#endif

/*
 * National Instruments ATMIO-16X.  16 bit A/D, 16 bit AT interface, DMA,
 * 2 D/A channels, 8 bits of digital I/O.  Operated in dual
 * dma mode.
 * ----------------------------------------------------------------------
 */
#ifdef NIATMIOX

u_int ad_sel= -1;
DMA dma_a= {0}, dma_b= {0};
int int_a;		/* signifies which dma buffer was loaded
			   with dual dma */

int
ad_ds_init(void)
{
    struct _seginfo sbuf;
    int rval;
    
    /*
     * Setup DMA controller.  Operate in dual-dma mode
     * using 2 16 bit channels.  All 8 channels are sampled and stored
     * each msec.
     */

    /*
     * Get segment for dma buffer.
     */
    if(ad_sel == -1) {
	if((ad_sel= qnx_segment_alloc_flags(64, _PMF_DMA_SAFE)) == -1) {
	    rxerr("Cannot alloc a/d DMA segment");
	    return(-1);
	}
    }
    if(qnx_segment_info(0, 0, ad_sel, &sbuf) == -1) {
	    rxerr("Cannot 'qnx_segment_info' on a/d DMA segment");
	    return(-1);
    }
#ifdef NEED_FAR
    dma_a.dma_lbufp= MK_FP(ad_sel, 0);
#endif
    dma_a.dma_pbufp.dma_phys= sbuf.addr;
    dma_a.dma_chan= NI1_DMACHAN1;
    dma_a.dma_mode= (DMA_M_WRITE | DMA_M_AUTOINIT | DMA_M_SINGLE);
    dma_a.dma_bcount= 16;
    dma_a.dma_inuse= 1;
    if((rval= dma_init(&dma_a)) != 0) return(rval); 

#ifdef NEED_FAR
    dma_b.dma_lbufp= MK_FP(ad_sel, 16);
#endif
    dma_b.dma_pbufp.dma_phys= sbuf.addr + 16;
    dma_b.dma_chan= NI1_DMACHAN2;
    dma_b.dma_mode= (DMA_M_WRITE | DMA_M_AUTOINIT | DMA_M_SINGLE);
    dma_b.dma_bcount= 16;
    dma_b.dma_inuse= 1;
    if((rval= dma_init(&dma_b)) != 0) return(rval); 
    int_a= 0;
    return(0);
}

int
ad_ds_uninit(void)
{

    dma_uninit(&dma_a); dma_uninit(&dma_b);
    dma_a.dma_inuse= 0, dma_b.dma_inuse= 0;

    if(ad_sel != -1) {
	if(qnx_segment_free(ad_sel) == -1) {
	    rxerr("ad_ds_uninit(): Cannot free a/d DMA segment");
	    return(-1);
	}
	ad_sel= -1;
    }
    return(0);
}

void
ad_ds_begin(void)
{
    int i;
    u_int ad_vect, utmp;

    /*
     * Init the board.
     */
    ad_ds_end();

    /*
     * Load channel-gain list.
     */
    inp(NI1_CMEMCLR_ROST_8);
    for(i= 0; i < AD_CHANNELS; i++) {
	outpw(NI1_CFGMEM_WO, (((ad_cglist[i] & 07) << 3)
			       | (i << 6)
			       | NI1_CHAN_BIP
			       | (i == (AD_CHANNELS-1) ? NI1_CHAN_LAST :
							    0x0)));
    }
    outp(NI1_CMEMLD_WOST_8, 0x0);

    /*
     * Program counter 4- sample counter.
     * Want sampling to continue indefinitely, so program counter 4
     * to have a high output (a falling edge on OUT4 disables counter
     * 3).  Do this by setting up counter to generate a low TC pulse,
     * but dont arm counting!  Output will stay high indefinetly.
     */
    outpw(NI1_TCOM_WO, 0xff04);
    outpw(NI1_TDATA_RW, 0x5);    /* active low TC */
    outpw(NI1_TCOM_WO, 0xff0c);
    outpw(NI1_TDATA_RW, 0x10);   /* some positive count */
    outpw(NI1_TCOM_WO, 0xff48);  /* load counter 4 */
    outpw(NI1_TCOM_WO, 0xfff4);  /* dec counter 4 */

    /*
     * Program counter 3- sample interval counter.
     * Set it to do conversions at a 20Khz rate.  Sample 8 channels
     * every msec.
     */
    outpw(NI1_TCOM_WO, 0xff03);
    outpw(NI1_TDATA_RW, 0x8c25); /* 100Khz clock input */
    outpw(NI1_TCOM_WO, 0xff0b);
    outpw(NI1_TDATA_RW, 0x2);
    outpw(NI1_TCOM_WO, 0xff44);
    outpw(NI1_TCOM_WO, 0xfff3);
    outpw(NI1_TDATA_RW, 5);    /* 5 counts @ 100Khz = 20Khz */
    outpw(NI1_TCOM_WO, 0xff24);  /* arm counter 3 */

    /*
     * Program counter 2- scan interval counter.
     * Set it to do a scan of all 8 channels.
     */
    outpw(NI1_TCOM_WO, 0xff02);
    outpw(NI1_TDATA_RW, 0x8d25); /* 10Khz clock input */
    outpw(NI1_TCOM_WO, 0xff0a);
    outpw(NI1_TDATA_RW, 0x2);
    outpw(NI1_TCOM_WO, 0xff42);
    outpw(NI1_TCOM_WO, 0xfff2);
    if(ad_max_rate == 1000) {
	outpw(NI1_TDATA_RW, 10);    /* 10 counts @ 10Khz = 1Khz */
    } else if(ad_max_rate == 2000) {
	outpw(NI1_TDATA_RW, 5);     /* 5 counts @ 10Khz = 2Khz */
    } else {
	rxerr("ad_ds_begin(): Illegal ad_max_rate");
	return;
    }
    outpw(NI1_TCOM_WO, 0xff22);  /* arm counter 2 */

    /*
     * Set up a/d.
     */
    Wsetport_WO(NI1_COM2_WO_P, ni1_com2,
		NI1_DMACHAN1 | (NI1_DMACHAN2 << 3), 0x0);   /* dma */
    utmp= AD_VECT;
    switch(utmp) {
	case 3:
		ad_vect= 0;
		break;
	case 4:
		ad_vect= 1;
		break;
	case 5:
		ad_vect= 2;
		break;
	case 7:
		ad_vect= 3;
		break;
	case 10:
		ad_vect= 4;
		break;
	case 11:
		ad_vect= 5;
		break;
	case 12:
		ad_vect= 6;
		break;
	case 15:
		ad_vect= 7;
		break;
	default:
		rxerr("ad_ds_begin(): Illegal value for a/d interrupt.");
    }
    Wsetport_WO(NI1_COM3_WO_P, ni1_com3, ad_vect, 0x0);	/* interrupt level */
    Wsetport_WO(NI1_COM3_WO_P, ni1_com3,
		NI1_ADCREQ | NI1_DMACHB | NI1_DMACHA | NI1_DMATCINT,
		0x0);
    Wsetport_WO(NI1_COM4_WO_P, ni1_com4, NI1_EXTTRIG_DIS, 0x0);
    Wsetport_WO(NI1_COM1_WO_P, ni1_com1, NI1_SCN2 | NI1_SCANEN | NI1_DAQEN,
		0x0);
    inp(NI1_DAQST_ROST_8);	    /* start a/d */

#ifdef GOO
doutput_rot= 0;
{
    int stat_sav= 0;
    int stat_new;

    while(1) {
	stat_new= inpw(NI1_STAT1_RO);
	if(stat_new != stat_sav) {
	    dprintf(" %x ", stat_new);
	    stat_sav= stat_new;
	}
    }
}
#endif
}

void
ad_ds_end(void)
{
    int i;
    
    /*
     * Init the board.  This sequence is detailed in the manual on page
     * 5-2 (June 1992 edition, p/n 320488-01).
     */
    Wsetport_WO(NI1_COM1_WO_P, ni1_com1, 0x0, 0xffff);
    Wsetport_WO(NI1_COM2_WO_P, ni1_com2, 0x0, 0xffff);
    Wsetport_WO(NI1_COM3_WO_P, ni1_com3, 0x0, 0xffff);
    Wsetport_WO(NI1_COM4_WO_P, ni1_com4, 0x0, 0xffff);
    inp(NI1_CMEMCLR_ROST_8);
    inp(NI1_DAQCLR_ROST_8);
    outp(NI1_DMATCACL_WOST_8, 0x0);
    inp(NI1_DMATCBCL_ROST_8);
    inp(NI1_DMACCLR_ROST_8);
    inp(NI1_DACCLR_ROST_8);
    inp(NI1_TMRCLR_ROST_8);
    outp(NI1_ADCCAL_WOST_8, 0x0);
    while((inpw(NI1_STAT2_RO) & NI1_ADC_BUSY) == 0);

    /*
     * 9513 timer.  No delay needed on this board between accesses.
     */
    outpw(NI1_TCOM_WO, 0xffff);
    outpw(NI1_TCOM_WO, 0xffef);
    outpw(NI1_TCOM_WO, 0xff17);
    outpw(NI1_TDATA_RW, 0xf000);
    for(i=1; i <= 5; i++) {
	outpw(NI1_TCOM_WO, 0xff00 + i);

	/*
	 * Disable counters 4, 5 (the sample counters- we dont use).
	 */
	if(i == 4  || i == 5) outpw(NI1_TDATA_RW, 0x0);
	else outpw(NI1_TDATA_RW, 0x4);
	outpw(NI1_TCOM_WO, 0xff08 + i);
	outpw(NI1_TDATA_RW, 0x3);
    }
    outpw(NI1_TCOM_WO, 0xff5f);
}

#endif

/*
 * ADAC 5508 Super HR 16 Bit A/D.  This is an 8 bit interface card, operated
 * in single DMA mode.  8 bits of digital I/O, no d/as.
 * ----------------------------------------------------------------------
 */
#ifdef AC5508HR

u_int ad_sel= -1;
DMA dma_a= {0};

int
ad_ds_init(void)
{
    struct _seginfo sbuf;
    int rval;
    
    /*
     * Setup DMA controller.  Operate in single DMA mode
     * using 1 8 bit channel.  All 8 channels are sampled and stored
     * each msec.
     */

    /*
     * Get segment for dma buffer.
     */
    if(ad_sel == -1) {
	if((ad_sel= qnx_segment_alloc_flags(64, _PMF_DMA_SAFE)) == -1) {
	    rxerr("Cannot alloc a/d DMA segment");
	    return(-1);
	}
    }
    if(qnx_segment_info(0, 0, ad_sel, &sbuf) == -1) {
	    rxerr("Cannot 'qnx_segment_info' on a/d DMA segment");
	    return(-1);
    }
#ifdef NEED_FAR
    dma_a.dma_lbufp= MK_FP(ad_sel, 0);
#endif
    dma_a.dma_pbufp.dma_phys= sbuf.addr;
    dma_a.dma_chan= AC0_DMACHAN;

    /*
     * ADAC 5508 uses demand mode and transfers two bytes for
     * each DMA request.
     */
    dma_a.dma_mode= (DMA_M_WRITE | DMA_M_AUTOINIT | DMA_M_DEMAND);
    dma_a.dma_bcount= 16;
    dma_a.dma_inuse= 1;
    if((rval= dma_init(&dma_a)) != 0) return(rval); 

    return(0);
}

int
ad_ds_uninit(void)
{
    dma_uninit(&dma_a);
    dma_a.dma_inuse= 0;

    if(ad_sel != -1) {
	if(qnx_segment_free(ad_sel) == -1) {
	    rxerr("ad_ds_uninit(): Cannot free a/d DMA segment");
	    return(-1);
	}
	ad_sel= -1;
    }
    return(0);
}

void
ad_ds_begin(void)
{
    ad_ds_end();    /* init board */
    
    /*
     * Program timer 0- a/d conversion trigger clock.
     * On board timer is 4Mhz.  Max a/d conversion rate is 47Khz.
     * Must finish all 8 channels in the 1 msec scan interval,
     * also leaving time to pick up samples before new scan interval
     * begins.  Therefore, set counter 0 to 33.3KHz (divide by 120).
     * Each sample will take 30usec, and scan will finish in 240usec.
     */
    outp(AC0_TCTRL_WO, 0x14);	/* counter 0, LSB write, mode 2, binary */
    outp(AC0_CNTR0_RW, 120);	/* divide 4Mhz to 33.3Khz */

    /*
     * Program timer 1 to generate the scan interval of 1msec.
     * The output of timer 1 must be jumpered to the external trigger
     * input.  An external trigger must be a high to low transistion.
     * Use mode 2.
     */
    outp(AC0_TCTRL_WO, 0x74);	/* counter 1, LSB/MSB write, mode 2, binary */
    outp(AC0_CNTR1_RW, shortlo_(4000));	/* LSB of count of 4000 */
    outp(AC0_CNTR1_RW, shorthi_(4000));	/* MSB of count of 4000 */

    /*
     * Set a/d modes.  No need to init the digital output part.
     */
    outp(AC0_ADCSR1_RW, AC0_DMAEN);	/* enable dma operation */
    outp(AC0_ADCSR0_RW, AC0_TREN|AC0_SEQ|AC0_BP_UN|AC0_ERIE);

#ifdef GOO
doutput_rot= 0;
{
    int stat_sav0= 0, stat_sav1= 0;
    int stat_new0, stat_new1;

    while(1) {
	stat_new0= inp(AC0_ADCSR0_RW);
	if(stat_new0 != stat_sav0) {
	    dprintf(" 0:%x ", stat_new0);
	    stat_sav0= stat_new0;
	}
	stat_new1= inp(AC0_ADCSR1_RW);
	if(stat_new1 != stat_sav1) {
	    dprintf(" 1:%x ", stat_new1);
	    stat_sav1= stat_new1;
	}
    }
}
#endif

}

void
ad_ds_end(void)
{
    /*
     * Clear control registers.
     */
    outp(AC0_ADCSR0_RW, 0x0);
    outp(AC0_ADCSR1_RW, 0x0);

    /*
     * Clear done bit by reading a/d data registers.
     */
    outp(AC0_ADCSR1_RW, AC0_CLRERR);	/* clear any errors */
    inp(AC0_ADDATAL_RO);    /* must read low byte first */
    inp(AC0_ADDATAH_RO);
    if(inp(AC0_ADCSR0_RW) & AC0_DONE) {
	rxerr("ad_ds_begin(): done bit is not clear");
	return;
    }

    /*
     * Do software calibration.
     */
    outp(AC0_ADCSR0_RW, AC0_SOFTCAL);	/* bit must be set then cleared */
    AC0_delay;
    outp(AC0_ADCSR0_RW, 0x0);	
    AC0_delay;
    while((inp(AC0_ADCSR0_RW) & AC0_DONE) == 0); /* wait for done bit */
    inp(AC0_ADDATAL_RO);    /* clear done bit; must read low byte first */
    inp(AC0_ADDATAH_RO);
    if(inp(AC0_ADCSR0_RW) & AC0_DONE) {
	rxerr("ad_ds_begin(): done bit is not clear- 2");
	return;
    }
}

#endif

/*
 * ADAC 5525MF 12 Bit A/D.  This is an 8 bit interface card, operated
 * in single DMA mode.  Has 16 bits of digial I/O, 2 12 bit d/as.
 * ----------------------------------------------------------------------
 */
#ifdef AC5525MF

u_int ad_sel= -1;
DMA dma_a= {0};

int
ad_ds_init(void)
{
    struct _seginfo sbuf;
    int rval;
    
    /*
     * Setup DMA controller.  Operate in single DMA mode
     * using 1 8 bit channel.  All 8 channels are sampled and stored
     * each msec.
     */

    /*
     * Get segment for dma buffer.
     */
    if(ad_sel == -1) {
	if((ad_sel= qnx_segment_alloc_flags(64, _PMF_DMA_SAFE)) == -1) {
	    rxerr("Cannot alloc a/d DMA segment");
	    return(-1);
	}
    }
    if(qnx_segment_info(0, 0, ad_sel, &sbuf) == -1) {
	    rxerr("Cannot 'qnx_segment_info' on a/d DMA segment");
	    return(-1);
    }
#ifdef NEED_FAR
    dma_a.dma_lbufp= MK_FP(ad_sel, 0);
#endif
    dma_a.dma_pbufp.dma_phys= sbuf.addr;
    dma_a.dma_chan= AC1_DMACHAN;

    /*
     * ADAC 5525MF uses demand mode and transfers two bytes for
     * each DMA request.
     */
    dma_a.dma_mode= (DMA_M_WRITE | DMA_M_AUTOINIT | DMA_M_DEMAND);
    dma_a.dma_bcount= 16;
    dma_a.dma_inuse= 1;
    if((rval= dma_init(&dma_a)) != 0) return(rval); 

    return(0);
}

int
ad_ds_uninit(void)
{
    dma_uninit(&dma_a);
    dma_a.dma_inuse= 0;

    if(ad_sel != -1) {
	if(qnx_segment_free(ad_sel) == -1) {
	    rxerr("ad_ds_uninit(): Cannot free a/d DMA segment");
	    return(-1);
	}
	ad_sel= -1;
    }
    return(0);
}

void
ad_ds_begin(void)
{
    ad_ds_end();    /* init board */
    
    /*
     * Program timer 0- a/d conversion trigger clock.
     * On board timer is 1Mhz.  Max a/d conversion rate is 40Khz.
     * Must finish all 8 channels in the 1 msec scan interval,
     * also leaving time to pick up samples before new scan interval
     * begins.  Therefore, set counter 0 to 33.3KHz (divide by 30).
     * Each sample will take 30usec, and scan will finish in 240usec.
     */
    outp(AC1_TCTRL_RW, 0x16);	/* counter 0, LSB write, mode 3, binary */
    outp(AC1_CNTR0_RW, 30);	/* divide 1Mhz to 33.3Khz */

    /*
     * Board is jumpered so that the output of timer 1 is connected
     * to the gate of timer 0 thru an inverter.  Program counter 1
     * in one-shot mode to produce a pulse equal to the duration
     * of 8 conversion pulses.  This is 30usec x 8 = 240usec.
     */
    outp(AC1_TCTRL_RW, 0x52);	/* counter 1, LSB write, mode 1, binary */
    outp(AC1_CNTR1_RW, 241);	/* add 1 for safety */

    /*
     * Output of counter 2 is connected by external jumper to gate
     * of counter 1.  Program counter 2 to generate a pules every
     * msec.  This will triger the one shot composed of counter 1.
     */
    outp(AC1_TCTRL_RW, 0xb4);	/* counter 2, LSB/MSB write, mode 2, binary */
    outp(AC1_CNTR2_RW, shortlo_(1000));	/* LSB of count of 1000 */
    outp(AC1_CNTR2_RW, shorthi_(1000));	/* MSB of count of 1000 */

    /*
     * Set a/d modes.
     */
    outp(AC1_LASTCHAN_WO, 8);	    /* set last channel register */
    outp(AC1_ADCSR1_RW, 0x0);	    /* set mux address to 0 */
    outp(AC1_CONFIG1_RW, AC1_DMAEN | AC1_LCEN);	/* enable DMA, last channel */
/*    outp(AC1_ADCSR0_RW, AC1_TREN | AC1_SEQ | 0x18); *//* gain of 1 */
    outp(AC1_ADCSR0_RW, AC1_TREN | AC1_SEQ); /* gain of 8 */

#ifdef GOO
doutput_rot= 0;
{
    int stat_sav0= 0, stat_sav1= 0;
    int stat_new0, stat_new1;

    while(1) {
	stat_new0= inp(AC1_ADCSR0_RW);
	if(stat_new0 != stat_sav0) {
	    dprintf(" 0:%x ", stat_new0);
	    stat_sav0= stat_new0;
	}
	stat_new1= inp(AC1_ADCSR1_RW);
	if(stat_new1 != stat_sav1) {
	    dprintf(" 1:%x ", stat_new1);
	    stat_sav1= stat_new1;
	}
    }
}
#endif

}

void
ad_ds_end(void)
{
    /*
     * Clear control registers.
     */
    outp(AC1_CONFIG1_RW, 0x0);
    outp(AC1_ADCSR0_RW, 0x0);
    outp(AC1_ADCSR1_RW, 0x0);
    outp(AC1_LASTCHAN_WO, 0x0);
    outp(AC1_IAK_ST, 0x0);

    /*
     * Clear done bit by reading a/d data registers.
     */
    inp(AC1_ADDATAL_RO);
    inp(AC1_ADDATAH_RO);
    if(inp(AC1_ADCSR0_RW) & AC1_DONE) {
	rxerr("ad_ds_begin(): done bit is not clear");
	return;
    }
}

#endif

/*
 * Analogic LSDAS-16 16 bit a/d converter.  Also has 2 d/a converters,
 * 16 bits of digital I/O.  Uses single 16 bit dma channel for a/d, single
 * 16 bit dma channel for d/a.
 * ----------------------------------------------------------------------
 */
#ifdef ANLSDAS16

u_int ad_sel= -1;
DMA dma_a= {0};

int
ad_ds_init(void)
{
    struct _seginfo sbuf;
    int rval;
    
    /*
     * Setup DMA controller.  Operate in single DMA mode
     * using 1 16 bit channel.  All 8 channels are sampled and stored
     * each msec.
     */

    /*
     * Get segment for dma buffer.
     */
    if(ad_sel == -1) {
	if((ad_sel= qnx_segment_alloc_flags(64, _PMF_DMA_SAFE)) == -1) {
	    rxerr("Cannot alloc a/d DMA segment");
	    return(-1);
	}
    }
    if(qnx_segment_info(0, 0, ad_sel, &sbuf) == -1) {
	    rxerr("Cannot 'qnx_segment_info' on a/d DMA segment");
	    return(-1);
    }
#ifdef NEED_FAR
    dma_a.dma_lbufp= MK_FP(ad_sel, 0);
#endif
    dma_a.dma_pbufp.dma_phys= sbuf.addr;
    dma_a.dma_chan= AN0_ADDMACHAN;
    dma_a.dma_mode= (DMA_M_WRITE | DMA_M_AUTOINIT | DMA_M_SINGLE);
    dma_a.dma_bcount= 16;
    dma_a.dma_inuse= 1;
    if((rval= dma_init(&dma_a)) != 0) return(rval); 

    return(0);
}

int
ad_ds_uninit(void)
{
    dma_uninit(&dma_a);
    dma_a.dma_inuse= 0;

    if(ad_sel != -1) {
	if(qnx_segment_free(ad_sel) == -1) {
	    rxerr("ad_ds_uninit(): Cannot free a/d DMA segment");
	    return(-1);
	}
	ad_sel= -1;
    }
    return(0);
}

void
ad_ds_begin(void)
{
    ad_ds_end();    /* init board */

    /*
     * Program timer 0- a/d conversion pacer clock.
     * In a/d mode 3, each tick of timer 0 results in all 8 differential
     * channels being sampled at the max rate of 50Khz.  Therefore,
     * set timer 0 to tick at a 1Khz rate.  This results in all 8 channels
     * being sampled once per msec.  On board clock is 5MHz.
     * Timer registers must be selected thru the extended register
     * mechanism.
     */
    Wsetport_WO(AN0_CTRL_WO_P, an0_ctrl, AN0_TCTRL0, 0x1f);
    outpw(AN0_EXTEND_WO, 0x34);	/* counter 0, LSB/MSB write, mode 2, binary */
    Wsetport_WO(AN0_CTRL_WO_P, an0_ctrl, AN0_T0CNTR0, 0x1f);
    outpw(AN0_EXTEND_WO, shortlo_(5000)); 
    outpw(AN0_EXTEND_WO, shorthi_(5000)); 

    /*
     * Program input range.
     */
    Wsetport_WO(AN0_CTRL_WO_P, an0_ctrl, AN0_RANGE0, 0x1f);
    outpw(AN0_EXTEND_WO, 0xaa);	    /* -10, +10 */
    Wsetport_WO(AN0_CTRL_WO_P, an0_ctrl, AN0_RANGE1, 0x1f);
    outpw(AN0_EXTEND_WO, 0xaa);	    /* -10, +10 */
    Wsetport_WO(AN0_CTRL_WO_P, an0_ctrl, AN0_RANGE2, 0x1f);
    outpw(AN0_EXTEND_WO, 0xaa);	    /* -10, +10 */
    Wsetport_WO(AN0_CTRL_WO_P, an0_ctrl, AN0_RANGE3, 0x1f);
    outpw(AN0_EXTEND_WO, 0xaa);	    /* -10, +10 */

    /*
     * Program storage registers.
     */
    Wsetport_WO(AN0_CTRL_WO_P, an0_ctrl, AN0_STORAGE0, 0x1f);
    outpw(AN0_EXTEND_WO, 0xf);
    Wsetport_WO(AN0_CTRL_WO_P, an0_ctrl, AN0_STORAGE1, 0x1f);
    outpw(AN0_EXTEND_WO, 0xf);
    Wsetport_WO(AN0_CTRL_WO_P, an0_ctrl, AN0_STORAGE2, 0x1f);
    outpw(AN0_EXTEND_WO, 0xf);
    Wsetport_WO(AN0_CTRL_WO_P, an0_ctrl, AN0_STORAGE3, 0x1f);
    outpw(AN0_EXTEND_WO, 0xf);

    /*
     * a/d control register.
     */
    Wsetport_WO(AN0_CTRL_WO_P, an0_ctrl, AN0_ADCTRL, 0x1f);
    outpw(AN0_EXTEND_WO, (AN0_ADRUN | AN0_ADENABLE | AN0_ADINPUT |
			  AN0_BIPOLAR));
/*
 * Following version grounds a/d inputs for calibration.
 */
/*    outpw(AN0_EXTEND_WO, (AN0_ADENABLE | AN0_ADINPUT |
			  AN0_BIPOLAR));*/

    /*
     * Other registers.
     */
    outpw(AN0_ADMODE_WO, (AN0_STRIGEN | 0x13)); /* timer pacing, mode 3 */
    Wsetport_WO(AN0_ICTRL_WO_P, an0_ictrl,
		(AN0_BIMASK | AN0_BIRENA | AN0_FIRENA | AN0_ADTCIM |
		AN0_ADTCIEN), 0xffff);
    Wsetport_WO(AN0_CTRL_WO_P, an0_ctrl, (AN0_DMASTART | AN0_DMAREQENA),
		0x1f);
#ifdef GOO
doutput_rot= 0;
{
    int stat_sav0= 0, stat_sav1= 0;
    int stat_new0, stat_new1;

    while(1) {
	stat_new0= inpw(AN0_STATUS_RO);
	if(stat_new0 != stat_sav0) {
	    dprintf(" 0:%x ", stat_new0);
	    stat_sav0= stat_new0;
	}
    }
}
#endif
}

void
ad_ds_end(void)
{
    /*
     * Reset board.
     */
    Wsetport_WO(AN0_CTRL_WO_P, an0_ctrl, 0x0, 0xffff);
    Wsetport_WO(AN0_CTRL_WO_P, an0_ctrl, (AN0_ADRESET | AN0_MRESET), 0x0);
}

#endif

/*
 * Analogic DAS12 12 bit a/d converter with 2 12 bit d/as.  Uses
 * a single 16 bit DMA channel.  Also has 16 bits dio.
 * ----------------------------------------------------------------------
 */
#ifdef ANDAS12

u_int ad_sel= -1;
DMA dma_a= {0};

int
ad_ds_init(void)
{
    struct _seginfo sbuf;
    int rval;
    
    /*
     * Setup DMA controller.  Operate in single DMA mode
     * using 1 16 bit channel.  All 8 channels are sampled and stored
     * each msec.
     */

    /*
     * Get segment for dma buffer.
     */
    if(ad_sel == -1) {
	if((ad_sel= qnx_segment_alloc_flags(64, _PMF_DMA_SAFE)) == -1) {
	    rxerr("Cannot alloc a/d DMA segment");
	    return(-1);
	}
    }
    if(qnx_segment_info(0, 0, ad_sel, &sbuf) == -1) {
	    rxerr("Cannot 'qnx_segment_info' on a/d DMA segment");
	    return(-1);
    }
#ifdef NEED_FAR
    dma_a.dma_lbufp= MK_FP(ad_sel, 0);
#endif
    dma_a.dma_pbufp.dma_phys= sbuf.addr;
    dma_a.dma_chan= AN1_DMACHAN;
    dma_a.dma_mode= (DMA_M_WRITE | DMA_M_AUTOINIT | DMA_M_SINGLE);
    dma_a.dma_bcount= 16;
    dma_a.dma_inuse= 1;
    if((rval= dma_init(&dma_a)) != 0) return(rval); 

    return(0);
}

int
ad_ds_uninit(void)
{
    dma_uninit(&dma_a);
    dma_a.dma_inuse= 0;

    if(ad_sel != -1) {
	if(qnx_segment_free(ad_sel) == -1) {
	    rxerr("ad_ds_uninit(): Cannot free a/d DMA segment");
	    return(-1);
	}
	ad_sel= -1;
    }
    return(0);
}

void
ad_ds_begin(void)
{
    u_int ad_vect= 0, ad_dma= 0, utmp;

    ad_ds_end();    /* init board */
    outpw(AN1_BDCTRL_RW, AN1_SRESET);	/* enable board */

    /*
     * Program timers 1,2- a/d conversion pacer clock.
     * In burst mode, each tick of timer results in all 8 differential
     * channels being sampled at the max rate of 50Khz.  Therefore,
     * set timer to tick at either 1 or 2Khz rate.  This results in all 8
     * channels being sampled.  On board clock is 1MHz.
     * Board cascades timer 1 and 2 together to get 32 bit counter.
     * Timer 2 is MS word.
     */
    outpw(AN1_TCTRL_RW, 0x94);	/* counter 2, LSB write, mode 2, binary */
    outpw(AN1_CNTR2_RW, 100);
    outpw(AN1_TCTRL_RW, 0x54);	/* counter 1, LSB write, mode 2, binary */
    if(ad_max_rate == 1000) outpw(AN1_CNTR1_RW, 10);
    else if(ad_max_rate == 2000) outpw(AN1_CNTR1_RW, 5);
    else {
	rxerr("ad_ds_begin(): Illegal ad_max_rate");
	return;
    }
    outpw(AN1_INCHCTRL_RW, 0x70);   /* start channel 0, end channel 7 */
    utmp= AD_VECT;
    switch(utmp) {
	case 5:
	    ad_vect= 0x40;
	    break;
	case 7:
	    ad_vect= 0x80;
	    break;
	case 10:
	    ad_vect= 0x100;
	    break;
	case 11:
	    ad_vect= 0x200;
	    break;
	case 15:
	    ad_vect= 0x400;
	    break;
	default:
	    rxerr("ad_ds_begin(): Illegal value for a/d interrupt.");
    }
    utmp= AN1_DMACHAN;
    switch(utmp) {
	case 5:
	    ad_dma= 0x800;
	    break;
	case 6:
	    ad_dma= 0x1000;
	    break;
	case 7:
	    ad_dma= 0x2000;
	    break;
	default:
	    rxerr("ad_ds_begin(): Illegal value for a/d dma chan.");
    }
    Wsetport_RW(AN1_BDCTRL_RW, (ad_dma | ad_vect), 0x0);
    AN1_delay;  /* must initialize dma and vector a little before enabling
		   interrupts */
    outpw(AN1_ADCTRL_RW, (AN1_ERRINTENA | AN1_TCINTENA | AN1_BURST
			  | (ad_cglist[0] & 03) << 6));
    Wsetport_RW(AN1_BDCTRL_RW, (AN1_CLADERR | AN1_CLTCDONE | AN1_MINTENA
				| AN1_ADDMAENA | AN1_GO), 0x0);

#ifdef GOO
doutput_rot= 0;
{
    int stat_sav0= 0, stat_sav1= 0;
    int stat_new0, stat_new1;

    while(1) {
	stat_new0= inpw(AN1_STATUS_RO);
	if(stat_new0 != stat_sav0) {
	    dprintf(" 0:%x ", stat_new0);
	    stat_sav0= stat_new0;
	}
    }
}
#endif
}

void
ad_ds_end(void)
{
    /*
     * Reset board.
     */
    outpw(AN1_BDCTRL_RW, 0x0);
    AN1_delay;
}
#endif
