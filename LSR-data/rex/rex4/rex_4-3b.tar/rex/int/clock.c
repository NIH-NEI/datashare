/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government.  The original
 * versions, REX 1.0-3.12, were developed for the pdp11 architecture and
 * distributed without restrictions.  This version, REX 4.0, is a port of
 * the original version to the Intel 80x86 architecture.  This version is
 * distributed only under license agreement from the National Institutes 
 * of Health, Laboratory of Sensorimotor Research, Bldg 10 Rm 10C101, 
 * 9000 Rockville Pike, Bethesda, MD, 20892, (301) 496-9375.
 *-----------------------------------------------------------------------*
 */

/*
 *----------------------------------------------------------------------------*
 *			STATE CHANGE PROCESSING, DISPLAYS
 * These routines have code to protect against reentering; this
 * is not needed currently.  Called every msec from system clock
 * via signal.
 *----------------------------------------------------------------------------*
 */
#include <stdio.h>
#include <i86.h>
#include <stdlib.h>
#include <signal.h>
#include <conio.h>
#include <sys/irqinfo.h>
#include <sys/proxy.h>
#include <sys/kernel.h>
#include "../hdr/sys.h"
#include "../hdr/cnf.h"
#include "../hdr/phys.h"
#include "../hdr/proc.h"
#include "../hdr/buf.h"
#include "../hdr/bufm.h"
#include "../hdr/menu.h"
#include "../hdr/state.h"
#include "../hdr/device.h"
#include "../hdr/ecode.h"
#include "../hdr/cdsp.h"
#include "../hdr/sac.h"
#include "../hdr/matrox.h"
#include "../hdr/idsp.h"
#include "../hdr/pcmsg.h"
#include "../hdr/int.h"

static int savA0, savA1, savB0, savB1;		/* used in rline */
static int w_dflags, w_xscale, w_yscale; 	/* used in disp */
static int w_xcen= WDI_XCEN;
static int w_ycen= WDI_YCEN;
static int newx, newy, oldx, oldy;		/* used in wdisp */
static WINDISP *savewp;
static ESCAPE *next;

extern int errprt;

/*
 * Simple table to provide random time escape function for state set.
 */
char rantbl[] = {0,2,1,4,1,3,2,3,0,4,3,1,2,0,2,0,4,3,0,1,2,4,1,1,3,0,2,
		4,4,0,2,3,4,2,2,3,0,3,1,2,4,1,3,2,4,2,0,1,0,3,4,0,2,3,2};

#pragma off (unreferenced)
void
msec_clock(int sig)
{
#pragma on (unreferenced)
  ESCAPE *escape_4;
  ACTION *act_3;
  int ptemp_3;
  STATE *pnew_3;
  ESCAPE *pesc_3;
  AWAKE *chng_2;
  AWAKE *awake_4;
  EVENT lev;
  int oldy_2;		    /* temp holds oldy add */
  int add_2;		    /* temp storage of addresses */
  int wxpos_2;		    /* temp storage of wind x position */
  int xoff_2;
  int y_2;
  WINDISP *wp_3;
  int *ip_3;		    /* integer pointer to step along
			       elements of structs */
  int yoff_4;
  int wypos_4;		    /* temp storage of wind y position */
  long l_time;			    /* local copy of time */
  extern sigset_t sig_state;	    /* mask for S_STATESIG */
  int shift_tmp;
  int *axp, *bxp;
  int *rlp_4;		/* pointer to rltab */

  /*
   * Note: sometime state processing may take more than one msec.
   * Therefore, l_time may increase by more than one between
   * invocations of this routine.
   */
  l_time= i_b->i_time;		/* pick up current time */

#ifdef PCMESSAGE

  /*
   * PC to PC Messaging.
   */
  pcm_msg_process();
#endif

  if((st_count -= ST_RATE) <= 0) {

  /*
   * Do not allow to be re-entered on reinterrupts.
   */
  if(sp_lock) {
    st_count= 1;
    goto l_disp;
  } else st_count= st_rate;
  sp_lock= 1;

  /*
   * Permit re-interrupts of 1msec clock to keep timer current.
   */
#ifdef GOO
  if(sigprocmask(SIG_UNBLOCK, &sig_state, NULL) == -1)
	rxerr("msec_clock(): cannot sigprocmask-1");
#endif

    escape_4 = firstesc;
    do {
		/*
		 * Process escapes.
		 */
	    st_top:

		ptemp_3= escape_4->sflags;
		switch(ptemp_3) {

		case TIME:
		    if(escape_4->awakestate->timer <= l_time) goto stchange;
		    break;

		case BITON:
		    if(*(int *)escape_4->funct & escape_4->smask)
			goto stchange;
		    break;

		case BITOFF:
		    if(!(*(int *)escape_4->funct & escape_4->smask))
					goto stchange;
		    break;

		case EQUAL:
		    if(*(int *)escape_4->funct == escape_4->smask)
					goto stchange;
		    break;

		case LESSOR:
		    if(*(int *)escape_4->funct > escape_4->smask)
					goto stchange;
		    break;

		case GREATER:
		    if(*(int *)escape_4->funct < escape_4->smask)
					goto stchange;
		    break;

		case QUERY:
		    if((*(int *)escape_4->funct)-- <= escape_4->smask)
					goto stchange;
		    break;

		case FUNC:
		    if((*(int (*)())escape_4->funct)() == escape_4->smask)
			goto stchange;
		    break;

		default:
		    rxerr("msec_clock(): bad escape type");
		    break;
		}
		continue;

	/*
	 * Transition to another state.
	 */
    stchange:

	if(errprt) {
	    fputs(&escape_4->stateptr->statename[0], stderr);
	    fputc(' ', stderr);
	}

	/*
	 *	Execute action.
	 */
	if ((act_3 = &escape_4->stateptr->device)->action)
		ptemp_3= (*act_3->action)(act_3->act_code,act_3->act_2code,
			act_3->act_3code);
	else ptemp_3 = 0;


	/*
	 *	Possibly enter event code.
	 */
	if (escape_4->stateptr->code != 0
	|| ptemp_3) {

		lev.e_key = l_time;

		if (ptemp_3) {
			lev.e_code = ptemp_3;
			if (ptemp_3 & INIT_MASK) {   /* is there a new init? */

				/* load into gobal location */
				i_b->i_iev.e_key = l_time;
				i_b->i_iev.e_code = ptemp_3;

				sendmsg(COMM, CM_STATUS);
			}
		}
		else {
			lev.e_code = escape_4->stateptr->code;
		}
		ldevent(&lev);

		/*
		 * If this code matches the raster wakeup event, wake
		 * up raster to update raster display.
		 */
		if( (lev.e_code == i_b->d_rwakecd)
		&& (i_b->d_flags & (D_RASTH|D_HSIG)) ) {
		    sendmsg(DISP, DS_DRAS);
		}
	}

	/*
	 *	Process running line and escape time.
	 */
	pnew_3 = escape_4->stateptr;
	switch(pnew_3->rlflag) {

		case RL_NOCHANGE:
			break;
		case RL_ABS:
			astate= pnew_3->rlval;
			break;
		case RL_ADD:
			astate += pnew_3->rlval;
			break;
		case RL_SUB:
			astate -= pnew_3->rlval;
			break;
		default:
			break;
	}

	if (pnew_3->preset >= 0)
		escape_4->awakestate->timer= pnew_3->preset + l_time;

	if (pnew_3->random) {
		static char *prant= rantbl;

		ptemp_3 = pnew_3->random;

		switch (*prant) {
		case 0:
			ptemp_3 = 0;
			break;
		case 1:
			ptemp_3 >>= 1;
			ptemp_3 >>= 1;
			break;
		case 2:
			ptemp_3 >>= 1;
			break;
		case 3:
			ptemp_3 >>= 1;
			ptemp_3 += ptemp_3 >> 1;
			break;
		case 4:
			break;
		}

		escape_4->awakestate->timer += ptemp_3;

		if (++prant >= rantbl + sizeof(rantbl))
			prant = rantbl;
	}

	/*
	 * Change escape pointers.  chng_2 points to awakestate of old
	 * state.
	 */
	chng_2 = escape_4->awakestate;

	/*
	 * pesc_3 is address of new state's first escape.
	 */
	pesc_3 = &escape_4->stateptr->escape;

	/*
	 * Find last escape of new state.
	 */
	for(escape_4 = pesc_3; escape_4->nextesc; escape_4 = escape_4->nextesc);

	/*
	 * Get nextesc from last esc of old state, put
	 * in nextesc of last esc of new state,
	 * and set old state's last escape's nextesc to zero.
	 */
	next = escape_4->nextesc = chng_2->lastesc->nextesc;
	chng_2->lastesc->nextesc = 0;

	/*
	 * Change lastesc of new state's awakestate.
	 */
	escape_4->awakestate->lastesc = escape_4;

	/*
	 * If there is a prior chain, link it to new state.
	 */
	if ((awake_4 = (AWAKE *)chng_2->prestate) > 0)
		awake_4->lastesc->nextesc = pesc_3;
	else firstesc = pesc_3;

	/*
	 * Get back next escape and see if non-zero.
	 */
	if (escape_4 = next) {
		goto st_top;
	} else goto end_behave;

    } while((escape_4 = escape_4->nextesc) != 0);

  end_behave:

    /*
     * Block re-interrupts.
     */
#ifdef GOO
    if(sigprocmask(SIG_BLOCK, &sig_state, NULL) == -1)
	rxerr("msec_clock(): cannot sigprocmask-2");
#endif

    sp_lock= 0;
  }


/*
 *----------------------------------------------------------------------------*
 *				REAL-TIME DISPLAYS
 * Table driven running line;  eye position window.  Runs only every "rlrate"
 * interrupts.
 *----------------------------------------------------------------------------*
 */
l_disp:

  /*
   * Time for displays?
   */
  if( (run_count--) <= 0)  {		/* Level A */
   if(ds_lock == 0) {			/* Level B */
     run_count= (i_b->d_flags & D_WIND ? w_rate : rlrate);
     if((i_b->d_flags & (D_RLINE|D_WIND))
     && (dina & RLSTOP) == 0)  {	/* Level C */

      ds_lock= 1;	/* display cannot be re-entered on reinterrupts */

      /*
       *	Running line.
       */
      if(i_b->d_flags & D_RLINE) {

	mxwrap= rl_wrap;
	switch(Cstate) {

		case 0:		/* C off */
			if(Ctraceon) {
				rline |= CHANC;
				rlinenew |= CHANC;
				Cstate= 1;
			}
			break;
		case 1:
			if( ! Ctraceon) {
				rlinenew &= ~CHANC;
				Ctcount= WDI_RIGHT + 100;
				Cstate= 2;
			}
			break;
		case 2:
			if(Ctcount--) break;
			rline &= ~CHANC;
			Cstate= 0;
			break;
	}

	/*
	 * Algorithm: structure 'matbuf' holds coordinates of points
	 * that are currently plotted on the screen.  Each time thru
	 * following code, the point ahead of the current position
	 * is erased, and new data is plotted in the current position.
	 * This leaves a single erased dot to mark where on the screen
	 * new data is being plotted.  'aindex' is the address of the
	 * point to be erased, 'bindex' is the address of the new
	 * point to be plotted.
	 */
	axp= (int *)&matbuf[aindex];
	bxp= (int *)&matbuf[bindex];
	rlp_4= (int *)&rltab;

	if(rline & CHANA)  {		/* chanA */
	    savA0= *axp;
	    mxfast(aindex, *axp, MXDRK);
	    savA1= *bxp= shift_(*rlp_4++, **(int **)rlp_4++) + *rlp_4++;
	    mxfast(bindex, *bxp, MXBRT);
	    axp++, bxp++;
	} else {
	    rlp_4 += 3;
	    axp++, bxp++;
	}
	if(rline & CHANB)  {		/* chanB */
	    savB0= *axp;
	    mxfast(aindex, *axp, MXDRK);
	    savB1= *bxp= shift_(*rlp_4++, **(int **)rlp_4++) + *rlp_4++;
	    mxfast(bindex, *bxp, MXBRT);
	    axp++, bxp++;
	} else {
	    rlp_4 += 3;
	    axp++, bxp++;
	}
	if(rline & CHANC)  {	
	    mxfast(aindex, *axp, MXDRK);
	    *bxp= shift_(*rlp_4++, **(int **)rlp_4++) + *rlp_4++;
	    if(rlinenew & CHANC) mxfast(bindex, *bxp, MXBRT);
	    axp++, bxp++;
	} else {
	    rlp_4 += 3;
	    axp++, bxp++;
	}
	if(rline & BARL)  {
	    mxfast(aindex, *axp, MXDRK);
	    *bxp= astate + *rlp_4++;
	    mxfast(bindex, *bxp, MXBRT);
	    axp++, bxp++;
	} else {
	    rlp_4++;
	    axp++, bxp++;
	}
	if(rline & SPIKES)  {		/* spikes */

	    /*
	     * Spikes are currently always cleared, and not stored
	     * in matbuf.
	     */
	    mxfast(aindex, *rlp_4, MXDRK);
	    if(aspike) {
		mxfast(bindex, *rlp_4, MXBRT);
		aspike= 0;
	    }
	    rlp_4++;
	} else {
	    rlp_4++;
	}
	if(rline & (MARKA | MARKB))  {	/* marks */
	    if(*axp & MARKA) {
		savA0 += 18;	    /* offset above line for mark dot */
		mxfast(aindex, savA0, MXDRK);
		savA0 += 5;
		mxfast(aindex, savA0, MXDRK);
	    }
	    if(*axp & MARKB) {
		savB0 += 18;	    /* offset above line for mark dot */
		mxfast(aindex, savB0, MXDRK);
		savB0 += 5;
		mxfast(aindex, savB0, MXDRK);
	    }
	    *bxp= 0;	    /* clear old marks in matbuf */
	    if(amarkA) {    /* put up new marks */
		amarkA= 0;
		savA1 += 18;
		mxfast(bindex, savA1, MXBRT);
		savA1 += 5;
		mxfast(bindex, savA1, MXBRT);
		*bxp |= MARKA;
	    }
	    if(amarkB) {    /* put up new marks */
		amarkB= 0;
		savB1 += 18;
		mxfast(bindex, savB1, MXBRT);
		savB1 += 5;
		mxfast(bindex, savB1, MXBRT);
		*bxp |= MARKB;
	    }
	}
	axp++, bxp++;

	/*
	 * Increment indices
	 */
	bindex= aindex;
	if(++aindex == WDI_RIGHT) aindex= 0;
	mxwrap= 0;

      /*
       *	Eye position window display;  needs i_b.
       */
      } else if(i_b->d_flags & D_WIND)  {

	/*
	 * Begin window display.  Compute new position of cursors.
	 * Note!  This code assumes the cursors are 0: eye, 1: center
	 * screen, 2: window, and 3: mirror, 4: oeye,
      	 * 5: eye xoff, 6: eye yoff, 7: oeye xoff, 8: oeye yoff,
      	 * 9: oeye window, 10: joystick.
	 */
	w_dflags= i_b->d_flags;		/* save d_flags for when r2 isnt i_b */
	i_b->d_flags &= ~D_REWIND;	/* reset if set */

	wxpos_2= *wdxptr;
	wypos_4= *wdyptr;
	wp_3= &windisp[0];
	if(w_dflags & D_WMOV) {		/* absolute display */
		wp_3->wd_newx= eyeh;	/* cursor 0: eye */
		wp_3++->wd_newy= eyev;
		wp_3->wd_newx= 0;	/* cursor 1: center of screen */
		wp_3++->wd_newy= 0;
		wp_3->wd_newx= wxpos_2;	/* cursor 2: window position */
		wp_3++->wd_newy= wypos_4;
		wp_3->wd_newx= mrxcur;	/* cursor 3: mirror position */
		wp_3++->wd_newy= mrycur;
		wp_3->wd_newx= oeyeh;	/* cursor 4: oeye */
		wp_3++->wd_newy= oeyev;
		wp_3->wd_newx= eho;	/* cursor 5: xoff */
		wp_3++->wd_newy= WDI_OHOR;
		wp_3->wd_newx= WDI_OVERT;	/* cursor 6: yoff */
		wp_3++->wd_newy= evo;
		wp_3->wd_newx= oeho;	/* cursor 7: oxoff */
		wp_3++->wd_newy= WDI_OHOR;
		wp_3->wd_newx= WDI_OVERT;	/* cursor 8: ovoff */
		wp_3++->wd_newy= oevo;
		wp_3->wd_newx= wxpos_2;	/* cursor 9: oeye window position */
		wp_3++->wd_newy= wypos_4;
		wp_3->wd_newx= joyh;	/* cursor 10: joystick */
		wp_3++->wd_newy= joyv;

	} else {		/* disp is relative to window position */
		wp_3->wd_newx= eyeh - wxpos_2;	/* cursor 0: eye position */
		wp_3++->wd_newy= eyev - wypos_4;
		wp_3->wd_newx= -wxpos_2;	/* cursor 1: center of screen */
		wp_3++->wd_newy= -wypos_4;
		wp_3->wd_newx= 0;		/* cursor 2: window position */
		wp_3++->wd_newy= 0;
		wp_3->wd_newx= mrxcur - wxpos_2;    /* cursor 3: mir position */
		wp_3++->wd_newy= mrycur - wypos_4;
		wp_3->wd_newx= oeyeh - wxpos_2;		/* cursor 5: oeye */
		wp_3++->wd_newy= oeyev - wypos_4;
		wp_3->wd_newx= eho;	/* cursor 5: xoff */
		wp_3++->wd_newy= WDI_OHOR;
		wp_3->wd_newx= WDI_OVERT;	/* cursor 6: yoff */
		wp_3++->wd_newy= evo;
		wp_3->wd_newx= oeho;	/* cursor 7: oxoff */
		wp_3++->wd_newy= WDI_OHOR;
		wp_3->wd_newx= WDI_OVERT;	/* cursor 8: ovoff */
		wp_3++->wd_newy= oevo;
		wp_3->wd_newx= 0;	/* cursor 9: oeye window position */
		wp_3++->wd_newy= 0;
		wp_3->wd_newx= joyh - wxpos_2;	/* cursor 10: joystick */
		wp_3++->wd_newy= joyv - wypos_4;
	}

	/*
	 * Update cursor positions if necessary.
	 */
      	wdchange= 0;
 	for(wp_3= &windisp[0]; wp_3 < &windisp[WDI_NCURS]; wp_3++) {

 	    /*
 	     * If wind is being restarted, old cursor address are invalid
 	     * and shouldnt be erased.  Also cause window cursor to be
 	     * regenerated incase window size or mag has changed.
 	     */
 	    if(w_dflags & D_REWIND) wp_3->wd_flag |=
 	    				(WDI_OLDINVALID|WDI_NEWSIZ);

 	    if(wp_3->wd_flag & WDI_SWON) {
 	    	if((wp_3->wd_flag & WDI_ON) == 0) {
 	    
	 	    	/*
 		    	 * Request to turn on cursor
 	    		 */
 	    		wp_3->wd_flag |= (WDI_ON|WDI_OLDINVALID|WDI_NEWSIZ);
 	    	}
    		wp_3->wd_flag &= ~(WDI_SWON|WDI_SWOFF);
 	    }
	    wp_3->wd_flag &= ~WDI_CHANGE;

	    /*
 	     * Check cursors to see which ones need to be updated.
	     */
	    if(wp_3->wd_flag & WDI_ON
	    &&
	    (  (wp_3->wd_newx != wp_3->wd_oldx)
	    || (wp_3->wd_newy != wp_3->wd_oldy)
	    || wp_3->wd_flag & (WDI_NEWSIZ|WDI_SWOFF|WDI_OLDINVALID)) )  {

		savewp= wp_3;		/* save windisp pointer */
		ip_3= (int *)savewp;

		/*
		 * Start using an int pointer to step through WINDISP
		 * and CURSOR.  Scale and convert to off binary.
		 */
	    	w_xscale= *ip_3++ - IC_TO_MAT;
	    	w_yscale= *ip_3++ - IC_TO_MAT;

		newx= (shift_(w_xscale, *ip_3++)) + w_xcen;
		newy= (shift_(w_yscale, *ip_3++)) + w_ycen;
		oldx= (shift_(w_xscale, *ip_3++)) + w_xcen;
		oldy= (shift_(w_yscale, *ip_3++)) + w_ycen;

		/*
		 * Erase old cursor if OLDINVALID is not true.
		 */
		if( ! (*ip_3 & WDI_OLDINVALID)) {
		    ip_3= (int *)savewp->wd_cur;
		    oldy_2= oldy;
		    for(;;) {
			mxnewx(oldx + *ip_3++);
			mxnewy(oldy_2 + *ip_3++);
			if(*ip_3 < 0) break;	/* done */
			if(*ip_3++) continue;	/* point is out of margins,
						   or not owner */
			mxwrite(MXDRK);		/* erase it */
		    }
		} else (*ip_3 &= ~WDI_OLDINVALID);

		/*
		 * Plot new cursor.
		 */
		wp_3= savewp;
		if(wp_3->wd_flag & WDI_SWOFF) {
		    wp_3->wd_flag &= ~(WDI_SWOFF|WDI_SWON|WDI_ON|WDI_NEWSIZ);
		} else {

		    /*
		     * Check to see if any cursors have changed size.
		     */
		    if(wp_3->wd_flag & WDI_NEWSIZ) {
		      wp_3->wd_flag &= ~WDI_NEWSIZ;

		      /*
		       * Change dimensions of window cursors
		       * to reflect new size.  Note that the window
		       * cursors are actually defined here;  their declarations
		       * in i.c must allocate as many points as
		       * are assumed here.
		       */
		      if(wp_3 == &windisp[CU_WIND]) {

		      	/*
		      	 * Eye window, 8 points.
		      	 */
			xoff_2= shift_(w_xscale, wdxsiz);
			yoff_4= shift_(w_yscale, wdysiz);
			ip_3= (int *)savewp->wd_cur;
			*ip_3++= xoff_2, *ip_3++= 0, ip_3++;
			*ip_3++= xoff_2, *ip_3++= yoff_4, ip_3++;
			*ip_3++= 0, *ip_3++= yoff_4, ip_3++;
			*ip_3++= -xoff_2, *ip_3++= yoff_4, ip_3++;
			*ip_3++= -xoff_2, *ip_3++= 0, ip_3++;
			*ip_3++= -xoff_2, *ip_3++= -yoff_4, ip_3++;
			*ip_3++= 0, *ip_3++= -yoff_4, ip_3++;
			*ip_3++= xoff_2, *ip_3++= -yoff_4;

		      } else if(wp_3 == &windisp[CU_OWIND]) {

		      	/*
		      	 * Other eye window, 12 points.
		      	 */
			xoff_2= shift_(w_xscale, wdoxsiz);
			yoff_4= shift_(w_yscale, wdoysiz);
			ip_3= (int *)savewp->wd_cur;
			*ip_3++= xoff_2, *ip_3++= yoff_4 >> 1, ip_3++;
			*ip_3++= xoff_2, *ip_3++= yoff_4, ip_3++;
			*ip_3++= xoff_2 >> 1, *ip_3++= yoff_4, ip_3++;
		      	*ip_3++= -(xoff_2 >> 1), *ip_3++= yoff_4, ip_3++;
			*ip_3++= -xoff_2, *ip_3++= yoff_4, ip_3++;
			*ip_3++= -xoff_2, *ip_3++= yoff_4 >> 1, ip_3++;
		      	*ip_3++= -xoff_2, *ip_3++= -(yoff_4 >> 1), ip_3++;
			*ip_3++= -xoff_2, *ip_3++= -yoff_4, ip_3++;
			*ip_3++= -(xoff_2 >> 1), *ip_3++= -yoff_4, ip_3++;
		      	*ip_3++= xoff_2 >> 1, *ip_3++= -yoff_4, ip_3++;
			*ip_3++= xoff_2, *ip_3++= -yoff_4, ip_3++;
		      	*ip_3++= xoff_2, *ip_3++= -(yoff_4 >> 1);
		      }
		    }
		    ip_3= (int *)savewp->wd_cur;

		    /*
		     * Loop on each dot of cursor.
		     */
		    for(;;) {
			if(((CURSOR *)ip_3)->cu_flag < 0) break;	/* done */
			add_2= newx + *ip_3++;
			if(add_2 < WDI_CLEFT || add_2 > WDI_CRIGHT) {

				/*
				 * If dot is out of margins do not plot.
				 * Set cu_flag so that it wont be erased
				 * next time.
				 */
				ip_3++;    /* prepare to point to cu_flag */
				goto nodot;
			}
			mxnewx(add_2);
			add_2= newy + *ip_3++;
			if(add_2 < WDI_CBOT || add_2 > WDI_CTOP) goto nodot;
			mxnewy(add_2);

			/*
		    	 * Check if the dot at this location is already set.
		    	 * If so, set the WDI_NOT_OWNER bit in cu_flag.
		    	 * Note that this is accomplished for efficiency
		    	 * reasons by loading the value of the matrox data
		    	 * register into cu_flag.  This sets or clears the
		    	 * not_owner bit corresponding to whether the bit
		    	 * on the screen is set or clear.  The WDI_OMARGINS
		    	 * bit is also cleared at the same time.  Therefore,
		    	 * WDI_NOT_OWNER must be defined to
		    	 * correspond to the data bit in the matrox register.
			 */
			if((*ip_3++ = mxread()) == 0) mxwrite(MXBRT);
			continue;

		    nodot:
			*ip_3++ = WDI_OMARGINS;	/* set out of margins bit,
						   and clear not_owner bit */
		    }
		}

		wp_3= savewp;			/* restore wp_3 pointer */
		wp_3->wd_oldx= wp_3->wd_newx;	/* update old addresses */
		wp_3->wd_oldy= wp_3->wd_newy;
	    	wp_3->wd_flag |= WDI_CHANGE;	/* this cursor was changed */
	    	wdchange= 1;			/* a cursor was changed */

	    }			/* end cursor update if */
	}			/* end for loop */

      	/*
      	 * Check for dots that should be set that might have been cleared
      	 * when the owner moved away.  Find new owners for these
      	 * dots and turn them on again.
      	 */
      	if(wdchange) {
 	  for(wp_3= &windisp[0]; wp_3 < &windisp[WDI_NCURS]; wp_3++) {

 	  	/*
 	  	 * Only need to check cursors that were not changed
 	  	 * above.
 	  	 */
 	  	if((wp_3->wd_flag & WDI_ON) == 0) continue;
 	  	if(wp_3->wd_flag & WDI_CHANGE) continue;
      		
 	  	savewp= wp_3;
		ip_3= (int *)savewp;
	    	w_xscale= *ip_3++ - IC_TO_MAT;
	    	w_yscale= *ip_3++ - IC_TO_MAT;
      		newx= (shift_(w_xscale, *ip_3++)) + w_xcen;
		y_2= (shift_(w_yscale, *ip_3++)) + w_ycen;
 	  	ip_3= &savewp->wd_cur->cu_flag;
 	  	
 	  	for(;; ip_3 += 3) {	/* loop for each dot in cursor */
 	  		
 	  	    if(*ip_3 < 0) break;		/* done */
		    if(shorthi_(*ip_3)) continue;	/* out of margins */
 	  	    if(shortlo_(*ip_3) == 0) continue;	/* we are owner */
 	  	    
 	  	    ip_3 -= 2;
		    mxnewx(newx + *ip_3++);
		    mxnewy(y_2 + *ip_3++);
		    if(mxread()) {
 	  	    	
 	  	    	/*
 	  	    	 * Bit is set.
 	  	    	 */
 	  	    	continue;
 	  	    }
 	  	    
 	  	    /*
 	  	     * Set bit, and make this cursor the new owner.
 	  	     */
		    mxwrite(MXBRT);
		    *ip_3 &= ~0377;
 	  	}
		wp_3= savewp;
 	  }
      	}

      }				/* end wind disp */

      ds_lock= 0;		/* done with displays */
     }				/* Level C */
   } else run_count= 1;		/* Level B */
  }				/* Level A */

/*
 * Return from signal routine.
 */

  /*
   * Send signal if requested from interrupt routine.
   */
  _disable();
  if(i_b->int_msg_pid) {
    pid_t tmp;

    tmp= i_b->int_msg_pid;
    i_b->int_msg_pid= 0;
    _enable();
    kill(tmp, S_ALERT);
  } else _enable();
  return;
}
