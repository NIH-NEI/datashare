/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government.  The original
 * versions, REX 1.0-3.12, were developed for the pdp11 architecture and
 * distributed without restrictions.  This version, REX 4.0, is a port of
 * the original version to the Intel 80x86 architecture.  This version is
 * distributed only under license agreement from the National Institutes 
 * of Health, Laboratory of Sensorimotor Research, Bldg 10 Rm 10C101, 
 * 9000 Rockville Pike, Bethesda, MD, 20892, (301) 496-9375.
 *-----------------------------------------------------------------------*
 */

/*
 * Int process main.
 */
#include <sys/types.h>
#include <sys/wait.h>
#include <process.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <setjmp.h>
#include <signal.h>
#include "../hdr/sys.h"
#include "../hdr/phys.h"
#include "../hdr/proc.h"
#include "../hdr/buf.h"
#include "../hdr/tty.h"
#include "../hdr/cnf.h"
#include "../hdr/menu.h"
#include "../hdr/device.h"
#include "../hdr/state.h"
#include "../hdr/matrox.h"
#include "../hdr/pcmsg.h"
#include "../hdr/int.h"

jmp_buf env= {0};
extern char version[];
extern sigset_t	alert_set;

main(int argc, char *argv[])
{
	int tmp;

	tmp= argc;

	/*
	 * Get paramfile and map INT_BLOCK.
	 */
	paramfd = atoi(argv[1]);
	getparam(paramfd, &param);
	if((i_b= (INT_BLOCK_P)padr_map(&param.i_bl)) == -1) {
		fprintf(stderr, "Comm: cannot map INT_BLOCK\n");
		exit(1);
	}
	if((r_b= (RAW_BLOCK_P)padr_map(&param.r_bl)) == -1) {
		fprintf(stderr, "Comm: cannot map RAW_BLOCK\n");
		exit(1);
	}

#ifdef GOO
	setbuf(stdout, NULL);		/* unbuffer stdout */
#endif

	myptx= atoi(argv[2]);
	myptp= &i_b->ptbl[myptx];
	myptp->p_state |= P_INTPROC_ST;
#ifdef NEED_FAR
	_fstufs(version, myptp->p_version, &myptp->p_version[P_LVERSION]);
#else
	stufs(version, myptp->p_version, &myptp->p_version[P_LVERSION]);
#endif

	sigemptyset(&alert_set);
	sigaddset(&alert_set, S_ALERT);	    /* set up signal mask for alert */
	signal(S_CNTRLC, SIG_IGN);
	signal(S_CNTRLB, oncntrlb);
	signal(S_ALERT, alert);
	signal(S_DEBUG_PRINT, doutput);
	sendname(myptp, nouns, menus);
	stateinit();		/* initialize the state lists */
	p_mksroot= &mksroot;

	/*
	 * Map in matrox display.
	 */
	mxinit(1);
	dio_init();	/* initialize digital i/o index list */
#ifdef CLRMIRRORS
	XYmout(0,0);	/* put mirrors at 0,0 */
#endif
	null_sig_arrays();  /* initialize signal arrays */
#ifdef PCMESSAGE
	pcm_init(-1);
#endif	

	/*
	 * Check if invoked from a root file.
	 */
	if(i_b->i_rtflag & RT_READ) rt_read();

	setjmp(env);
	for(;;) sleep(32000);
}

/*
 * On cntlb reset interprocess communication to a default state.
 */
void
oncntrlb(int sig)
{
	int tmp;
	PROCTBL_P p;

	tmp= sig;

	signal(S_CNTRLB, oncntrlb);
	p= myptp;
	p->p_state |= P_NOSIG_ST;		/* prevent IPC */
	sleep(1);				/* let comm run first */
	p->p_msg= p->p_vindex= p->p_rmask= 0;
	p->p_sem= HIGHBIT;
	n_clock("e", NS);
	p->p_state &= ~P_NOSIG_ST;
	longjmp(env, 0);
}

/*
 *	Routines for calibration paradigms.
 */

/*
 *	Print calibration points.
 */
void
cal_print(void)
{
	struct c_eyekeep *p;
	int i = 0;

	printf("Calibration points;  current is %d\n", c_curp);
	for(p= &c_eyekeep[0]; p <= &c_eyekeep[C_KEEPMAX]; p++) {
		printf("%d:  xpos %d \t ypos %d \t oxpos %d \t oypos %d\n", i,
			p->c_xsav, p->c_ysav, p->c_oxsav, p->c_oysav);
		i++;
	}
	tflush_;
}

void
cl_cal(void)
{
	struct c_eyekeep *p;

	for(p= &c_eyekeep[0]; p <= &c_eyekeep[C_KEEPMAX]; p++) {
		p->c_xsav= 0;
		p->c_ysav= 0;
		p->c_oxsav= 0;
		p->c_oysav= 0;
	}
}
