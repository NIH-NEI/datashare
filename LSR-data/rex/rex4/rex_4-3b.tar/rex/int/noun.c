/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government.  The original
 * versions, REX 1.0-3.12, were developed for the pdp11 architecture and
 * distributed without restrictions.  This version, REX 4.0, is a port of
 * the original version to the Intel 80x86 architecture.  This version is
 * distributed only under license agreement from the National Institutes 
 * of Health, Laboratory of Sensorimotor Research, Bldg 10 Rm 10C101, 
 * 9000 Rockville Pike, Bethesda, MD, 20892, (301) 496-9375.
 *-----------------------------------------------------------------------*
 */

/*
 * Int noun processing.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include "../hdr/sys.h"
#include "../hdr/proc.h"
#include "../hdr/buf.h"
#include "../hdr/menu.h"
#include "../hdr/state.h"
#include "../hdr/cnf.h"
#include "../hdr/device.h"
#include "../hdr/tty.h"
#include "../hdr/phys.h"
#include "../hdr/int.h"

/*
 * Noun 'statelist'.
 */
void
n_slist(char *vstr, char *astr)
{
	extern STATE *snames[];

	switch(*vstr) {
	case 's':		/* change statelist variables */
		s_access(snames, astr);
		break;

	case 'r':		/* reset and reinitialize */
		again();
		break;
	default:
		badverb();
		break;
	}
}

/*
 * Noun 'mirror'.
 */
#pragma off (unreferenced)
void
n_mirror(char *vstr, char *astr)
{
#pragma on (unreferenced)

	switch(*vstr) {
	case 'c':
		mr_mov(0,0);
		break;

	default:
		badverb();
		break;
	}
}

/*
 *	Commands for calibration paradigms.
 */
#pragma off (unreferenced)
void
n_calib(char *vstr, char *astr)
{
#pragma on (unreferenced)

	switch(*vstr) {
	case 't':		/* type previous positions */
		cal_print();
		break;

	case 'c':		/* clear position storage */
		cl_cal();
		break;

	default:
		badverb();
		break;
	}
}

/*
 * Process verbs for noun "clock".
 */
char lockmsg[] = "n_clock(): Error on lock/unlock in clock";

#pragma off (unreferenced)
void
n_clock(char *vstr, char *astr)
{
#pragma on (unreferenced)

	extern INT_BLOCK_P i_b;

	switch(*vstr) {

	case 'e':

		if ((i_b->i_flags & I_GO) == 0) return;
		if(i_b->i_flags & (I_EOUT|I_AOUT) ) {
			rxerr("n_clock(): Cannot end clock while keeping.");
			return;
		}

	    	/*
	    	 * Reset a/d and stop clock.
	    	 */
		ad_stop();
		clk_stop();
		return;

	case 'b':

		if (i_b->i_flags & I_GO)  return;
		if(i_b->scrb_pi <= 0) {
			rxerr("n_clock(): Illegal, no scribe process");
			return;
		}
		if(prego() != 0) return;
		clk_start();	/* must start msec clock first */
		ad_start();
		return;

	default:
		badverb();
		break;
	}
}

/*
 * Noun 'bit'
 */
void
n_bit(char *vstr, char *astr)
{
    extern DIO_DEV *dio_index[];
    DIO_DEV *dp;
    u_char pinit;
    char *parray[P_NARG], *rptr;
    char **pbuf= parray;
    int pcnt, port, bitpat, i;
    int set= 0;
    
    switch(*vstr) {
    case 's':	    /* set */
	set= 1;
	break;
	
    case 'c':	    /* clear */
	set= 0;
	break;

    case 'r':	    /* reset */
	    if((dp= dio_index[m_bitdio]) == 0) {
		rxerr("n_bit(): nonexistant device");
		return;
	    }

	    /*
	     * Loop for each possible port.
	     */
	    for(i= 0; i < DIO_PORT_PORTMAX; i++) {
		pinit= dp->dio_pinit[i];
		if(Dio_type(pinit) != D_OUT) continue;
		if(pinit & D_NOCLR) continue;	/* dont clear if NOCLR set */
		dio_off(Dio_id(m_bitdio, i, 0xffff));
	    }
	    return;

    default:
	badverb();
	break;
    }

    /*
     * Parse arguments.  Arguments are of form 'port bitnum|bitpat'.
     * A 'bitnum' is the bit number, from 0 to 15.  A 'bitpat' is
     * a hex bit pattern to be loaded into the specified port.
     * The 'bitpat' must begin with "0x".
     */
    if((pcnt= parse(1, astr, parray, P_NARG)) < 0 ) {
	rxerr("n_bit(): error on parse of argument string");
	return;
    }

    /*
     * Loop for each port, bitnum|bitpat pair.
     */
    for(;;) {
	if(pcnt-- > 0) {
	    port= strtoul(*pbuf, &rptr, 16);
	    if(rptr != (*pbuf + strlen(*pbuf))) {
		rxerr("n_bit(): bad port specification");
		return;
	    }
	    pbuf++;
	} else break;	    /* done */
	if(pcnt-- > 0) {
	    if(strncmp("0x", *pbuf, 2) == 0) 
		bitpat= strtoul(*pbuf, &rptr, 16);
	    else bitpat= bit_(strtoul(*pbuf, &rptr, 10));
	    if(rptr != (*pbuf + strlen(*pbuf))) {
		rxerr("n_bit(): bad bit specification");
		return;
	    }
	    pbuf++;
	} else {
	    rxerr("n_bit(): missing argument");
	    return;
	}
	if(set) dio_on(Dio_id(m_bitdio, port, bitpat));
	else dio_off(Dio_id(m_bitdio, port, bitpat));
    }
}

/*
 * Noun 'signals'
 */
#pragma off (unreferenced)
void
n_signals(char *vstr, char *astr)
{
#pragma on (unreferenced)

    SIG *sgp;
    int snum;

    switch(*vstr) {
    case 't':		/* type signals */
      printf("Sig type chan arate srate cal gain delay\t    name\t        title\n");
      printf("--------------------------------------------------------------------------------\n");
      for(snum= 0, sgp= &sig; sgp < &sig[SA_MAXSIG]; snum++, sgp++) {
#if (defined AD_CGLIST)
	if(sgp->sig_enable == SIG_AD_SOURCE) {
	  printf("%3d %4s %3d %5d %5d %3d  %3d  %3d %20s %20s\n",
	    snum, "a/d", sgp->sig_ad_chan, sgp->sig_ad_rate,
	    (sgp->sig_store_rate == NULLI ? 0 : sgp->sig_store_rate),
	    sgp->sig_ad_calib,
	    sgp->sig_ad_gain, sgp->sig_ad_delay,
	    sgp->sig_ad_mem_var, sgp->sig_title);
	}
#else
	if(sgp->sig_enable == SIG_AD_SOURCE) {
	  printf("%3d %4s %3d %5d %5d %3d  %3d  %3d %20s %20s\n",
	    snum, "a/d", sgp->sig_ad_chan, sgp->sig_ad_rate,
	    (sgp->sig_store_rate == NULLI ? 0 : sgp->sig_store_rate),
	    sgp->sig_ad_calib,
	    ad_ov_gain, sgp->sig_ad_delay,
	    sgp->sig_ad_mem_var, sgp->sig_title);
	}
#endif
	else if(sgp->sig_enable == SIG_MEM_SOURCE) {
	  printf("%3d %4s %3s %5s %5d %3s  %3s  %3s %20s %20s\n",
	    snum, "mem",
	    "-", "-", sgp->sig_store_rate, "-", "-", "-",
	    sgp->sig_mem_source, sgp->sig_title);
	}
      }
      break;
    default:
      badverb();
      break;
    }
}
