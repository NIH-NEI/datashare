#include <stdio.h>
#include <sys/types.h>
#include "../hdr/sys.h"
#include "../hdr/cnf.h"
#include "../hdr/proc.h"
#include "../hdr/buf.h"
#include "../hdr/menu.h"
#include "../hdr/state.h"
#include "../hdr/ecode.h"
#include "../hdr/device.h"
#include "../hdr/cdsp.h"
#include "../hdr/int.h"




extern int drinput;
extern int drinput;
extern int drinput;
extern int tst_tx_rdy();
extern int send_msg();
extern int bel();
extern int tst_rx_new();
extern int print_msg();
extern int ack();
extern int rec_enab();



STATE sfirst;
STATE spause1;
STATE spause2;
STATE sgo;
STATE ssend;
STATE sdo_bell;
STATE srec0;
STATE srec;
STATE srec1;
STATE srec2;
STATE senab;



STATE *snames[] = {
&sfirst,
&spause1,
&spause2,
&sgo,
&ssend,
&sdo_bell,
&srec0,
&srec,
&srec1,
&srec2,
&senab,
0};

/*
 * Test PC to PC Messaging.  REX side transmits message to PC, and the
 * PC responds.
 */

#include <stdio.h>
#include "../hdr/pcmsg.h"

bel(long a)
{
	dputchar((char)a);
	return(0);
}

char msg[]=
"For I am the way, the truth, and the life.";

send_msg()
{
	pcm_send(0, &msg, PCM_TYPE2, sizeof(msg));
	return(0);
}

/*
 * Test to see if transmit is idle.  Cannot call 'pcm_send()' unless
 * PCM_TX_BUSY is not set.
 */
tst_tx_rdy()
{
	if(!(pcm[0].pcm_status & PCM_TX_BUSY)) {
		return(0);
	}
	else return(1);
}

/*
 * Test to see if a new message has arrived.
 */
tst_rx_new()
{
	if(pcm[0].pcm_status & PCM_MSG_WAITING) return(0);
	else return(1);
}

print_msg()
{
        printf("MSG: status %x, type %d, count %d\n",
	   pcm[0].pcm_status, pcm[0].pcm_msg_type, pcm[0].pcm_msg_cnt);
	printf("%s\n", pcm[0].pcm_rbufp);
	return(0);
}

/*
 * Acknowledge receipt of message.  This permits a new message
 * to be received.
 */
ack()
{
	pcm_ack(0);
	return(0);
}

/*
 * Enable message receiving.
 */
rec_enab()
{
	pcm_rec_enable(0);
	return(0);
}

VLIST state_vl[] = {
NS,
};

/*
 * Help message.
 */
char hm_sv_vl[] = "";

STATE sfirst = {
	{"first"},STARTCD
	,1,0
	,{0,0,0,0}
	,0,0
	,{0,0,&spause1,TIME,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
};
STATE spause1 = {
	{"pause1"},0
	,0,0
	,{0,0,0,0}
	,0,0
	,{0,0,&spause2,BITON,&drinput,PSTOP }
	,{0,0,&sgo,BITOFF,&drinput,PSTOP }
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
};
STATE spause2 = {
	{"pause2"},PAUSECD
	,0,0
	,{0,0,0,0}
	,0,0
	,{0,0,&sgo,BITOFF,&drinput,PSTOP }
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
};
STATE sgo = {
	{"go"},0
	,0,0
	,{0,0,0,0}
	,0,0
	,{0,0,&ssend,FUNC,&tst_tx_rdy,0 }
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
};
STATE ssend = {
	{"send"},0
	,0,0
	,{send_msg,0,0,0}
	,2000,0
	,{0,0,&sdo_bell,TIME,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
};
STATE sdo_bell = {
	{"do_bell"},0
	,0,0
	,{bel,'\007',0,0}
	,0,0
	,{0,0,&sfirst,TIME,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
};
STATE srec0 = {
	{"rec0"},0
	,0,0
	,{0,0,0,0}
	,0,0
	,{0,0,&srec,TIME,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
};
STATE srec = {
	{"rec"},0
	,0,0
	,{0,0,0,0}
	,0,0
	,{0,0,&srec1,FUNC,&tst_rx_new,0 }
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
};
STATE srec1 = {
	{"rec1"},0
	,0,0
	,{print_msg,0,0,0}
	,0,0
	,{0,0,&srec2,TIME,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
};
STATE srec2 = {
	{"rec2"},0
	,0,0
	,{ack,0,0,0}
	,0,0
	,{0,0,&srec,TIME,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
};
STATE senab = {
	{"enab"},0
	,0,0
	,{rec_enab,0,0,0}
	,0,0
	,{0,0,&srec0,TIME,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
};



STATE *aborta[] = {
0};

STATE *abortb[] = {
&senab,
0};

int sf_init();

STATE sps_state;

AWAKE init_state[] = {
	{0,ON,ON,&sps_state,&sps_state,0,&init_state[1],0,
			&sps_state.escape}
	,{0,0,0,0,0,&sps_state.es2}
};
STATE sps_state = {
	{"spec"},1
	,1,0
	,{sf_init,700}
	,0,0
	,{0,init_state,&sps_state,TIME}
	,{0,0,0,0}
};
AWAKE nowstate[] = {
	{0,ON,ON,&sfirst,&sfirst,aborta,0,0,0}
	,{0,ON,ON,&srec0,&srec0,abortb,0,0,0}
	,{0,0,0,0,0,0,0,0,0}
};

int (*init_list[])() = {
0};
