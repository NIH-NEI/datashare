/* modified by D. Waitzman for fldsac_400.d 	September, l986 */
/* modified by D. Waitzman for dblgap_431.d, July 20, 1987 */
/* modified by D. Waitzman for dblgap_433.d, May 16, 1989 */

#define TARGONCD	2000
#define TARGOFFCD	2002
#define BARUPCD		2020
#define BARDOWNCD	2030

#define TARGON1CD	2100
#define TARGON2CD	2101
#define FIX1CD		2110
#define FIX2CD		2111
#define JUMP1CD		2200

#define ELECTR1		0001
#define ELECTR2		0002
#define ELECTR3		0004	/* drll definitions, byte 0, bit #3 */


/* pos flags */
#define P_ENDLST	01
#define P_CDONE		02

/* calc sac flags  for cs_flag */
#define CS_ENDLST	01
#define CS_CDONE	02
#define CS_STPDONE	04

/* calc rashbass flags for rs_flag */
#define RS_ENDLST	01
#define RS_CDONE	02
#define RS_ADONE	04
#define RS_MONITOR	010
#define RS_TDONE	020

#define SHUTTER_DEL	30		/* milliseconds of delay */

/*
 * SACCADE POSITION TABLES
 * sac_pos[] holds the x,y values for a saccade jump, and the
 *	event codes for that jump.
 *	Units of position are 10ths of a degree.
 * sac_shuffle[] is an array that will hold the shuffled indices
 *	to sac_pos[].  It must be initialized to a
 *	list of the ordinal integers, 0 to n_sac-1.
 * n_sac holds the number of jumps in the table.
 * sh_i is the index into the shuffled table.
 * sac_i is the index into the sac_pos table.
 */
typedef struct {
	int sac_x0;		/* final x-coord */
	int sac_y0;		/* final y-coord */
	int sac_ecode;		/* event code for this jump */
	int sac_para;		/* paradigm flag, 0 saccade task */
	int sac_count;		/* count for this jump */
} SAC_POS;

/* STP_POS
 *	Like SAC_POS, but with mode added for Staircase stepping
 */
typedef struct {
	int stp_x0, stp_x1;	/* initial and final x-coord */
	int stp_y0, stp_y1;	/* initial and final y-coord */
	int stp_mode;		/* selects size of step */
	int stp_ecode;		/* event code for this jump */
	int stp_count;		/* count for this jump */
} STP_POS;

/* ORDER
 *	Similar to SAC_POS but for a much wider table which contains time
 * modifers as well as beginning and ending postions and a paradigm flag.
 */
typedef struct {
	int x0;			/* first x-coord */
	int y0;			/* first y-coord */
	int time0;		/* time for first event */
	int x1;			/* second x-coord */
	int y1;			/* second y-coord */
	int time1;		/* time for second event */
	int flag;		/* paradigm flag, summary of values in dblgap_431.d */
	int bcode;		/* base code for this jump */
	int count;		/* count for this saccade */
} ORDER;
/*
 * RASHBASS STIMULUS TABLE
 *	Contains the starting position and the velocity in cartesian
 * coordinates for the ramp, as well as the polar coordinates for the
 * ramp.  It also holds the adaptable time-of-zero-crossing.
 * Note that the adaptable time-of-zero-crossing is
 * in milliseconds.
 */
typedef struct {
	int rs_x0, rs_y0;	/* fixation postion, in 10ths of deg */
	int rs_vx, rs_vy;	/* cartesian velocities, in deg/sec */
	int rs_vel, rs_ang;	/* polar velocity, in deg/sec and deg */
	int rs_tz;	/* adaptable zero-crossing time in msec */
	int rs_ecode;		/* event code for this stimulus */
	int rs_count;		/* number of successful trials */
} RASHTBL ;

/*
 * SAC_SAVE
 *	Place to save information about the first saccade needed
 * by adaptive controller
 */
typedef struct {
	int ss_xsz, ss_ysz;	/* saccade size */
} SAC_SAVE ;

/*
 * definitions of positions and velocities for Rashbass table
 */
#define TZ_MAX	350	/* maximum time-of-zero crossing */
#define RS_DEL	200	/* default zero-crossing in msec */

#define RS_X1	0
#define RS_Y1	0
#define RS_X2	250
#define RS_Y2	0
#define RS_X3	-250
#define RS_Y3	0
#define RS_V1	15
#define RS_V2	5

#define MAXSCREEN	400	/* max screen position in 10ths deg */
