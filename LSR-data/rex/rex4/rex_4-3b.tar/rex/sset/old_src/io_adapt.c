
/*
 * GET_AF
 *	get adapt file name.
 * d = direction string
 * Returns NULL on failure
 */
FILE *
get_af(d)
	char *d;
{
	register char *p;
	char buf[40];

	setbuf(stdout, &_sobuf);
	printf("Enter Adapt File Name:\n");
	fflush(stdout);
	*buf = 0;
	gets(buf);
	for (p = buf; *p == ' '; p++);

	if (*p == '\0') return(NULL);
	return(fopen(p, d));
}

/*
 * IO_ADAPT
 *	Write out or read in the Rashbass adapter table.
 */
io_adapt(v)
	char v;
{
	register RASHTBL *r, *rl;
	FILE *strm, *get_af();
	int num, sz;

	if ((strm = get_af((v == 'i' ? "r" : "w"))) == NULL) {
		printf("Can't open Adapt file \n");
		return;
	}
	if (v == 'o') {		/* output */
		fprintf(strm, "%d %d\n", n_rs, sizeof(RASHTBL));
		for (r = &rs_tbl, rl = &rs_tbl[n_rs]; r < rl; r++)
			fprintf(strm,
			  "%7d %7d %7d %7d %7d %7d %7d %7d\n",
			r->rs_x0, r->rs_y0, r->rs_vx, r->rs_vy,
			r->rs_vel, r->rs_ang, r->rs_tz, r->rs_ecode);
	}
	else {		/* input */
		fscanf(strm, "%d %d\n", &num, &sz);
		if (num != n_rs || sz != sizeof(RASHTBL)) {
			fprintf("Bad Adapt File Size\n");
			return;
		}
		for (r = &rs_tbl, rl = &rs_tbl[n_rs]; r < rl; r++)
			fscanf(strm,
			  "%d %d %d %d %d %d %d %d\n",
			&r->rs_x0, &r->rs_y0, &r->rs_vx, &r->rs_vy,
			&r->rs_vel, &r->rs_ang, &r->rs_tz, &r->rs_ecode);
	}

	fclose(strm);
}
