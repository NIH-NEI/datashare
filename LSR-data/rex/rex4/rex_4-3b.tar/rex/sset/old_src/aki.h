/*
 * aki.h
 *      		... A. Mikami / 22-MAY-82
 */

#define ONE		01
#define NO_BAR		01

#define	RD_ENDLST	01
#define	RD_CDONE	02
#define	RD_PHI		010
#define	RD_STAT		020
#define	RD_NORND	040

#define RP_ENDLST	01
#define RP_CDONE	02
#define RP_MULTI	04
#define RP_NEXT		010

#define RL_ENDLST	01
#define RL_CDONE	02
#define RL_SNGL		04
#define RLSTIMCD	2040
#define RLOFFCD		2041

#define DD_ENDLST	01
#define DD_CDONE	02
#define DD_DISCRIM	04
#define DD_GO		010
#define RAMPCD		1999
#define DIMCD		1900
#define GOTRLCD		1800
#define NOGOTRLCD	1801

#define HP_NEXT		040
#define YESBAR		02000
#define NOBAR		01000
#define BEEPCD		1808
#define YESCODE		1810
#define NOCODE		1811
#define EOG	01

/* Random direction and random velocity experiments using LED spot
 */

typedef struct {
	int rd_ang;
	int rd_vel;
	int rd_ecode;
	int rd_count;
} RDTBL;

/* Random Phi experimnet ... Paradigm 215, 224, 225
 */

typedef struct {
	int rp_int;	/* inter-flash interval */
	int rp_angle;
	int rp_ecode;
	int rp_count;
} PHITBL;

/* Random location factor table for the Random 2 flash Paradigm
 */

typedef struct {
	int rl_m;	/* location factor */
	int rl_angle;
	int rl_ecode;
	int rl_count;
} RLTBL;

/* Random table for behavior experiment */

typedef struct {
	int dd_factor;
	int dd_gonogo;
	int dd_ecode;
	int dd_count;
} RNDTBL;

/* Human Phi Experiments */

typedef struct {
	int hp_int;
/*
	int hp_angle;
*/
	int hp_ecode;
	int hp_yes;
	int hp_no;
	int hp_count;
} HPTBL;
