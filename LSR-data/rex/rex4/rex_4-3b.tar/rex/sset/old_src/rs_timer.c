
/*
 * RS_TIMER
 *	Rashbass timer.  Puts time for window to pass fixation point
 * into time of state g_state.
 * The window widths are in ra_xwind, ra_ywind, in 10ths of degrees for
 * the half width.  The velocities are in rs_tbl[].rs_vx, rs_tbl[].rs_vy
 * in deg/sec.  Time is in milliseconds.
 */
rs_timer(g_state)
	register STATE * g_state;
{
	register RASHTBL *r;
	register int tx;
	int ty;

	rs_flag &= ~ RS_TDONE;
	r = & rs_tbl[rs_i];
	if (r->rs_vx != 0) {
		tx = (100 * ra_xwind) / r->rs_vx;
		if (tx < 0) tx = -tx;
		tx += r->rs_tzx;
	}
	if (r->rs_vy != 0) {
		ty = (100 * ra_ywind) / r->rs_vy;
		if (ty < 0) ty = -ty;
		ty += r->rs_tzy;
		if (ty > tx) tx = ty;
	}

	g_state->preset = tx;
	rs_flag |= RS_TDONE;
	return(0);
}
