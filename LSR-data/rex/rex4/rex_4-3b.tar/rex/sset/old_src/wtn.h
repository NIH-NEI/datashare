#define TARGONCD	3000
#define TARGOFFCD	3002
#define BARUPCD		3020
#define BARDOWNCD	3030

#define TARGON1CD	3100
#define TARGON2CD	3101
#define FIX1CD		3110
#define FIX2CD		3111
#define JUMP1CD		3200
#define STRAMPCD	1300
#define ONSTABCD	4100
#define OFFSTABCD	4101
#define TARG2OFFCD	4200
#define BRANCHCD 	4300


/* pos flags */
#define P_ENDLST	01
#define P_CDONE		02


/* calc rashbass flags for rs_flag */
#define RS_ENDLST	01
#define RS_CDONE	02
#define RS_ADONE	04
#define RS_MONITOR	010
#define RS_TDONE	020
#define RS_SAC		040
#define RS_STAB		0100
#define RS_OFF		0200


/*
 * RASHBASS TABLE
 *		Contains fixation position, ramp length, polar
 *	coordinates for ramp, and step dimensions for generalized
 *	step-ramp tracking paradigm.
 */
typedef struct {
	int rs_xw, rs_yw;	/* eye window dimensions, in 10ths of deg */
	int rs_vel, rs_ang;	/* polar velocity, in deg/sec and deg */
	int rs_xoff, rs_yoff;	/* step dimensions */
	int rs_ecode;		/* event code for this stimulus */
	int rs_good;		/* number of good trials */
	int rs_count;		/* number of successful trials */
} RASHTBL ;

/*
 * STABILIZATION TABLE
 *		Contains fixation position, ramp length, polar
 *	coordinates for ramp, and step dimensions for generalized
 *	step-ramp tracking paradigm.
 *		Modified from RASHTBL - instead of a vertical step
 *	dimension, structure STABTBL contains a flag which
 *	indicates trials which are open-loop or stim off controls.
 *	Flags are bits RS_STAB and RS_OFF for word rs_flag as
 *	above. (modified 9-19-83)
 */
typedef struct {
	int rs_xw, rs_yw;	/* eye window dimensions, in 10ths of deg */
	int rs_vel, rs_ang;	/* polar velocity, in deg/sec and deg */
	int rs_xoff;		/* horizontal step dimension */
	int rs_trfl;		/* flag to identify open-loop and 
				 * stim off control trials
				 */
	int rs_ecode;		/* event code for this stimulus */
	int rs_good;		/* number of good trials */
	int rs_count;		/* number of successful trials */
} STABTBL ;

/*
 * definitions of positions and velocities for Rashbass table
 */
#define RS_X1	0
#define RS_Y1	0
#define RS_V1	16
#define RS_XW	50
#define RS_YW	50

