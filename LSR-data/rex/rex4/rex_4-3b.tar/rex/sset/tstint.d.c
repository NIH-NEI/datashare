#include <stdio.h>
#include <sys/types.h>
#include "../hdr/sys.h"
#include "../hdr/cnf.h"
#include "../hdr/proc.h"
#include "../hdr/buf.h"
#include "../hdr/menu.h"
#include "../hdr/state.h"
#include "../hdr/ecode.h"
#include "../hdr/device.h"
#include "../hdr/cdsp.h"
#include "../hdr/int.h"




extern int drinput;
extern int drinput;
extern int drinput;
extern int bel();
extern int dio_on();
extern int dio_on();
extern int dtoa();
extern int awind();
extern int awind();
extern int dio_off();
extern int dio_off();



STATE sfirst;
STATE spause1;
STATE spause2;
STATE sgo;
STATE sgo1;
STATE sgo12;
STATE sgo13;
STATE sgo2;
STATE scwind;
STATE swait;
STATE swait2;



STATE *snames[] = {
&sfirst,
&spause1,
&spause2,
&sgo,
&sgo1,
&sgo12,
&sgo13,
&sgo2,
&scwind,
&swait,
&swait2,
0};

/*
 * Simple test paradigm
 */

#include <stdio.h>
#include "ldev_tst.h"

#define RCODE0 2000
#define RCODE1 2001


bel(long a)
{
	dputchar((char)a);
	return(0);
}

dtoa(long x, long y)
{
	XYmout((int)x, (int)y);
	return(0);
}

/*
 * Declaration of statelist menu.
 */
 
long a= 0x1f2f;
int b= 0x1f2f;
int c= 123;
int d= 0123;

VLIST state_vl[] = {
"a",		&a, NP, NP, 0, ME_LHEX,
"b",		&b, NP, NP, 0, ME_HEX,
"c",		&c, NP, NP, 0, ME_DEC,
"d",		&d, NP, NP, 0, ME_OCT,
NS,
};

/*
 * Help message.
 */
char hm_sv_vl[] = "";

STATE sfirst = {
	{"first"},STARTCD
	,1,0
	,{0,0,0,0}
	,0,0
	,{0,0,&spause1,TIME,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
};
STATE spause1 = {
	{"pause1"},0
	,0,0
	,{0,0,0,0}
	,0,0
	,{0,0,&spause2,BITON,&drinput,PSTOP }
	,{0,0,&sgo,BITOFF,&drinput,PSTOP }
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
};
STATE spause2 = {
	{"pause2"},PAUSECD
	,0,0
	,{0,0,0,0}
	,0,0
	,{0,0,&sgo,BITOFF,&drinput,PSTOP }
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
};
STATE sgo = {
	{"go"},RCODE0
	,0,0
	,{bel,007,0,0}
	,10,0
	,{0,0,&sgo1,TIME,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
};
STATE sgo1 = {
	{"go1"},RCODE1
	,1,35
	,{dio_on,LED1,0,0}
	,1000,0
	,{0,0,&sgo12,TIME,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
};
STATE sgo12 = {
	{"go12"},0
	,0,0
	,{dio_on,LED2,0,0}
	,0,0
	,{0,0,&sgo13,TIME,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
};
STATE sgo13 = {
	{"go13"},0
	,0,0
	,{dtoa,0, 0,0}
	,0,0
	,{0,0,&sgo2,TIME,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
};
STATE sgo2 = {
	{"go2"},0
	,1,50
	,{awind,OPEN_W,0,0}
	,2000,0
	,{0,0,&scwind,TIME,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
};
STATE scwind = {
	{"cwind"},0
	,1,0
	,{awind,CLOSE_W,0,0}
	,0,0
	,{0,0,&swait,TIME,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
};
STATE swait = {
	{"wait"},ENABLECD
	,0,0
	,{dio_off,LED1,0,0}
	,1000,0
	,{0,0,&swait2,TIME,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
};
STATE swait2 = {
	{"wait2"},0
	,0,0
	,{dio_off,LED2,0,0}
	,1000,0
	,{0,0,&sfirst,TIME,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
};



STATE *aborta[] = {
&scwind,
0};

int sf_init();

STATE sps_state;

AWAKE init_state[] = {
	{0,ON,ON,&sps_state,&sps_state,0,&init_state[1],0,
			&sps_state.escape}
	,{0,0,0,0,0,&sps_state.es2}
};
STATE sps_state = {
	{"spec"},1
	,1,0
	,{sf_init,700}
	,0,0
	,{0,init_state,&sps_state,TIME}
	,{0,0,0,0}
};
AWAKE nowstate[] = {
	{0,ON,ON,&sfirst,&sfirst,aborta,0,0,0}
	,{0,0,0,0,0,0,0,0,0}
};

int (*init_list[])() = {
0};
