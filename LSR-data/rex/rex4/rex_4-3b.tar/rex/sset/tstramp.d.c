#include <stdio.h>
#include <sys/types.h>
#include "../hdr/sys.h"
#include "../hdr/cnf.h"
#include "../hdr/proc.h"
#include "../hdr/buf.h"
#include "../hdr/menu.h"
#include "../hdr/state.h"
#include "../hdr/ecode.h"
#include "../hdr/device.h"
#include "../hdr/cdsp.h"
#include "../hdr/int.h"




extern int drinput;
extern int drinput;
extern int drinput;
extern int nextramp();
extern int ra_compute();
extern int rampflag;
extern int ra_start();
extern int awind();
extern int rampflag;
extern int dio_on();
extern int eyeflag;
extern int dio_on();
extern int eyeflag;
extern int set_wsiz();
extern int ramptset();
extern int eyeflag;
extern int rampflag;
extern int dio_off();
extern int dio_off();
extern int awind();
extern int set_wsiz();
extern int dio_on();
extern int dio_off();
extern int ra_stop();
extern int score();
extern int awind();
extern int reset_s();
extern int score();
extern int rampflag;
extern int rampflag;
extern int ramptd();



STATE sfirst;
STATE spause1;
STATE spause2;
STATE sgo;
STATE sselramp;
STATE scramp;
STATE sstramp;
STATE sopenw;
STATE sfpon;
STATE seyeon;
STATE sstimon;
STATE swdchange;
STATE ssetpres;
STATE sfpoff;
STATE sstoff;
STATE sclosew;
STATE swdback;
STATE srewon;
STATE srewoff;
STATE sstopramp;
STATE scorrect;
STATE serror;
STATE sreset;
STATE swrong;
STATE sramptw;
STATE stimeramp;
STATE sramptd;



STATE *snames[] = {
&sfirst,
&spause1,
&spause2,
&sgo,
&sselramp,
&scramp,
&sstramp,
&sopenw,
&sfpon,
&seyeon,
&sstimon,
&swdchange,
&ssetpres,
&sfpoff,
&sstoff,
&sclosew,
&swdback,
&srewon,
&srewoff,
&sstopramp,
&scorrect,
&serror,
&sreset,
&swrong,
&sramptw,
&stimeramp,
&sramptd,
0};

/*
 * Rex ramp test paradigm.
 *
 */

#include "../hdr/ramp.h"
#include "ldev_tst.h"
#include "lcode_tst.h"

struct ra_list {
	int	len;
	int	ang;
	int	vel;
	int	xoff, yoff;
	int	xwind, ywind;
	int	oxwind, oywind;
	int	eyehoff, eyevoff, oeyehoff, oeyevoff;
	int	type;
	int	ecode;
};

#define E_D0	2000		/* ramp direction series */
#define E_D45	2001
#define E_D90	2002
#define E_D135	2003
#define E_D180	2004
#define E_D225	2005
#define E_D270	2006
#define E_D315	2007

/*
 *	Direction series for tracking.
 */
struct ra_list list0[] = { 
200,	315,	5,	0,0,	50,50,40,40,40,40,0,0,	RA_CENPT, E_D315,
200,	90,	10,	0,0,	50,50,40,40,20,20,0,0,	RA_CENPT, E_D90,
200,	225,	15,	0,0,	50,50,40,40,10,10,0,0,	RA_CENPT, E_D225,
200,	0,	20,	0,0,	50,50,40,40,30,30,0,0,	RA_CENPT, E_D0,
200,	180,	25,	0,0,	50,50,40,40,40,40,0,0,	RA_CENPT, E_D180,
200,	45,	30,	0,0,	50,50,40,40,20,20,0,0,	RA_CENPT, E_D45,
200,	270,	35,	0,0,	50,50,40,40,10,10,0,0,	RA_CENPT, E_D270,
200,	135,	40,	0,0,	50,50,40,40,30,30,0,0,	RA_CENPT, E_D135,
200,	0,	5,	0,0,	50,50,40,40,20,40,0,0,	RA_CENPT, E_D0,
200,	315,	10,	0,0,	50,50,40,40,0,0,40,40,	RA_CENPT, E_D315,
200,	45,	15,	0,0,	50,50,40,40,0,0,20,20,	RA_CENPT, E_D45,
200,	225,	20,	0,0,	50,50,40,40,0,0,10,10,	RA_CENPT, E_D225,
200,	90,	25,	0,0,	50,50,40,40,0,0,30,30,	RA_CENPT, E_D90,
200,	180,	30,	0,0,	50,50,40,40,0,0,40,40,	RA_CENPT, E_D180,
200,	135,	35,	0,0,	50,50,40,40,0,0,20,20,	RA_CENPT, E_D135,
200,	270,	40,	0,0,	50,50,40,40,0,0,10,10,	RA_CENPT, E_D270,
-1,	-1,	-1,	-1,-1,	-1,-1,-1,-1,-1,-1,-1,-1, 0,	-1,
};

static struct ra_list *rlp= &list0[0];
static int rxwind= 0, rywind= 0;
static int roxwind= 0, roywind= 0;
int fxwd= 100, fywd= 100;
int foxwd= 50, foywd= 50;

int
nextramp(long flag)
{
	if(flag || (rlp->len == -1) ) rlp= &list0[0];
	ra_new(rlp->len, rlp->ang, rlp->vel, rlp->xoff, rlp->yoff,
			rlp->ecode, rlp->type);
	rxwind= rlp->xwind;
	rywind= rlp->ywind;
	roxwind= rlp->oxwind;
	roywind= rlp->oywind;
	rlp++;
	off_eye(rlp->eyehoff, rlp->eyevoff);
	off_oeye(rlp->oeyehoff, rlp->oeyevoff);
	return(0);
}

int
set_wsiz(long flag)
{
	wd_siz( (flag ? rxwind : fxwd), (flag ? rywind : fywd) );
	wd_osiz( (flag ? roxwind : foxwd), (flag ? roywind : foywd) );
	return(0);
}

void
rinitf(void)
{
	mr_set(MR_WFG, NULLI, NULLI);
	wd_ctl(WD_BEYE_ON, WD_MIR, D_W_ALLCUR);
	wd_siz(fxwd, fywd);
	wd_osiz(foxwd, foywd);
	wd_pos(NULLI, NULLI);
	rlp= &list0[0];
}

/*
 * Declaration of statelist menu.
 */
 
extern int fxwd, fywd, foxwd, foywd;
VLIST state_vl[] = {
"fix_xwind",		&fxwd, NP, NP, 0, ME_DEC,
"fix_ywind",		&fywd, NP, NP, 0, ME_DEC,
"fix_oxwind",		&foxwd, NP, NP, 0, ME_DEC,
"fix_oywind",		&foywd, NP, NP, 0, ME_DEC,
NS,
};

char hm_sv_vl[]= "";

STATE sfirst = {
	{"first"},STARTCD
	,0,0
	,{0,0,0,0}
	,1500,0
	,{0,0,&spause1,TIME,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
};
STATE spause1 = {
	{"pause1"},0
	,0,0
	,{0,0,0,0}
	,0,0
	,{0,0,&spause2,BITON,&drinput,PSTOP }
	,{0,0,&sgo,BITOFF,&drinput,PSTOP }
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
};
STATE spause2 = {
	{"pause2"},PAUSECD
	,0,0
	,{0,0,0,0}
	,0,0
	,{0,0,&sgo,BITOFF,&drinput,PSTOP }
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
};
STATE sgo = {
	{"go"},ENABLECD
	,0,0
	,{0,0,0,0}
	,0,0
	,{0,0,&sselramp,TIME,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
};
STATE sselramp = {
	{"selramp"},0
	,0,0
	,{nextramp,0,0,0}
	,0,0
	,{0,0,&scramp,TIME,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
};
STATE scramp = {
	{"cramp"},0
	,0,0
	,{ra_compute,0,0,0}
	,0,0
	,{0,0,&sstramp,BITON,&rampflag,RA_CDONE }
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
};
STATE sstramp = {
	{"stramp"},0
	,0,0
	,{ra_start,1, LED1,0}
	,0,0
	,{0,0,&sopenw,TIME,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
};
STATE sopenw = {
	{"openw"},0
	,0,0
	,{awind,OPEN_W,0,0}
	,0,0
	,{0,0,&sfpon,BITON,&rampflag,RA_STARTED }
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
};
STATE sfpon = {
	{"fpon"},FPONCD
	,0,0
	,{dio_on,LED1,0,0}
	,250,0
	,{0,0,&seyeon,TIME,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
};
STATE seyeon = {
	{"eyeon"},0
	,0,0
	,{0,0,0,0}
	,250,0
	,{0,0,&serror,BITON,&eyeflag,EYEALL }
	,{0,0,&sstimon,TIME,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
};
STATE sstimon = {
	{"stimon"},STIMCD
	,0,0
	,{dio_on,BACKLT,0,0}
	,0,0
	,{0,0,&serror,BITON,&eyeflag,EYEALL }
	,{0,0,&swdchange,TIME,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
};
STATE swdchange = {
	{"wdchange"},0
	,0,0
	,{set_wsiz,1,0,0}
	,0,0
	,{0,0,&ssetpres,TIME,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
};
STATE ssetpres = {
	{"setpres"},0
	,0,0
	,{ramptset,80, 20,0}
	,0,0
	,{0,0,&serror,BITON,&eyeflag,EYEALL }
	,{0,0,&sfpoff,BITON,&rampflag,RA_TIMEDONE }
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
};
STATE sfpoff = {
	{"fpoff"},FPOFFCD
	,0,0
	,{dio_off,LED1,0,0}
	,0,0
	,{0,0,&sstoff,TIME,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
};
STATE sstoff = {
	{"stoff"},STOFFCD
	,0,0
	,{dio_off,BACKLT,0,0}
	,0,0
	,{0,0,&sclosew,TIME,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
};
STATE sclosew = {
	{"closew"},0
	,0,0
	,{awind,CLOSE_W,0,0}
	,0,0
	,{0,0,&swdback,TIME,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
};
STATE swdback = {
	{"wdback"},0
	,0,0
	,{set_wsiz,0,0,0}
	,0,0
	,{0,0,&srewon,TIME,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
};
STATE srewon = {
	{"rewon"},0
	,0,0
	,{dio_on,BEEP,0,0}
	,35,0
	,{0,0,&srewoff,TIME,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
};
STATE srewoff = {
	{"rewoff"},0
	,0,0
	,{dio_off,BEEP,0,0}
	,0,0
	,{0,0,&sstopramp,TIME,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
};
STATE sstopramp = {
	{"stopramp"},0
	,0,0
	,{ra_stop,1,0,0}
	,0,0
	,{0,0,&scorrect,TIME,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
};
STATE scorrect = {
	{"correct"},0
	,0,0
	,{score,YES,0,0}
	,0,0
	,{0,0,&sfirst,TIME,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
};
STATE serror = {
	{"error"},0
	,0,0
	,{awind,CANCEL_W,0,0}
	,0,0
	,{0,0,&sreset,TIME,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
};
STATE sreset = {
	{"reset"},ERR1CD
	,0,0
	,{reset_s,-1,0,0}
	,0,0
	,{0,0,&swrong,TIME,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
};
STATE swrong = {
	{"wrong"},0
	,0,0
	,{score,NO,0,0}
	,0,0
	,{0,0,&sfirst,TIME,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
};
STATE sramptw = {
	{"ramptw"},0
	,0,0
	,{0,0,0,0}
	,0,0
	,{0,0,&stimeramp,BITON,&rampflag,RA_TIMESTART }
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
};
STATE stimeramp = {
	{"timeramp"},0
	,0,0
	,{0,0,0,0}
	,0,0
	,{0,0,&sramptw,BITOFF,&rampflag,RA_TIMESTART }
	,{0,0,&sramptd,TIME,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
};
STATE sramptd = {
	{"ramptd"},RTDONECD
	,0,0
	,{ramptd,0,0,0}
	,0,0
	,{0,0,&sramptw,TIME,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
	,{0,0,0,0,0,0}
};



STATE *aborta[] = {
&sfpoff,
&sstoff,
&srewoff,
&sstopramp,
&swdback,
0};

STATE *abortb[] = {
0};

int sf_init();

STATE sps_state;

AWAKE init_state[] = {
	{0,ON,ON,&sps_state,&sps_state,0,&init_state[1],0,
			&sps_state.escape}
	,{0,0,0,0,0,&sps_state.es2}
};
STATE sps_state = {
	{"spec"},1
	,1,0
	,{sf_init,700}
	,0,0
	,{0,init_state,&sps_state,TIME}
	,{0,0,0,0}
};
AWAKE nowstate[] = {
	{0,ON,ON,&sfirst,&sfirst,aborta,0,0,0}
	,{0,ON,ON,&sramptw,&sramptw,abortb,0,0,0}
	,{0,0,0,0,0,0,0,0,0}
};

void rinitf();
int (*init_list[])() = {
rinitf,
0};
