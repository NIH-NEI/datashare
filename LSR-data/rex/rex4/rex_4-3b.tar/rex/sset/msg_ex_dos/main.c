/*
 * Program to test PC to PC messaging.
 * This program runs on the DOS side.
 */

#define DOSPC
#define PCMESSAGE

#include "pcmsg.h"
#include <stdio.h>

char msg[]=
"No one comes to the Father but by me.";

main()
{
    PCM *p= &pcm[0];

    setbuf(stdout, NULL);	/* turn off output buffering */

    pcm_init(0);		/* init the channel */
    pcm_rec_enable(0);		/* enable receiving */

    for(;;) {
      while(1) {
	pcm_msg_process();	/* wait for message from REX */
	if(p->pcm_status & PCM_MSG_WAITING) break;
      }
      printf("rec: status %x, type %d, count %d\n",
	   p->pcm_status, p->pcm_msg_type, p->pcm_msg_cnt);
      printf("rec: %s\n", p->pcm_rbufp);
      pcm_ack(0);		/* acknowledge message */
      while(pcm[0].pcm_status & PCM_TX_BUSY);	/* wait for tx not busy */
      pcm_send(0, msg, PCM_TYPE1, sizeof(msg));/* send reply */
    }
}
