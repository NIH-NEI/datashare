/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government.  The original
 * versions, REX 1.0-3.12, were developed for the pdp11 architecture and
 * distributed without restrictions.  This version, REX 4.0, is a port of
 * the original version to the Intel 80x86 architecture.  This version is
 * distributed only under license agreement from the National Institutes 
 * of Health, Laboratory of Sensorimotor Research, Bldg 10 Rm 10C101, 
 * 9000 Rockville Pike, Bethesda, MD, 20892, (301) 496-9375.
 *-----------------------------------------------------------------------*
 */

#define STATE	300
#define CODE	301
#define ACTION	302
#define TIME	303
#define RANDOM	304
#define	GOTO	305
#define ON	306
#define IF	307
#define OFF	308
#define STRING	309
#define NUMBER	310
#define ERROR	311
#define OPEN	312
#define CLOSE	313
#define PLUS	314
#define MINUS	315
#define OF	316
