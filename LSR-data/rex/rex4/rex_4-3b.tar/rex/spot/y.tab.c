#ifndef lint
char yysccsid[] = "@(#)yaccpar	1.4 (Berkeley) 02/25/90";
#endif
#line 17 "sp.y"
typedef union {
	int ival;
	char cval;
	char *cpval;
} YYSTYPE;
#line 26 "sp.y"
#define YY_READ_BUF_SIZE 2000
#line 13 "y.tab.c"
#define STATE 257
#define CODE 258
#define TIME 259
#define RANDOM 260
#define TO 261
#define MINUS 262
#define PLUS 263
#define RUNL 264
#define FIRST 265
#define ABORT 266
#define NAME 267
#define STATUS 268
#define ACTION 269
#define ON 270
#define PNUM 271
#define RESTART 272
#define STRING 273
#define CAPS 274
#define NUMBER 275
#define YYERRCODE 256
short yylhs[] = {                                        -1,
    0,    0,    5,    5,    5,    6,    6,    7,    8,    8,
   10,   10,   11,   11,   11,   11,   12,   12,   12,   12,
   12,   12,   14,   14,   14,   14,   14,   17,   17,   16,
   16,   16,   16,   16,   15,   15,   15,   15,   13,   13,
   18,   18,   19,   19,   19,   19,   19,   19,   19,   19,
   19,   19,   19,   19,   19,    3,    3,    4,    4,    9,
    9,   20,   20,   20,    2,    1,    1,
};
short yylen[] = {                                         2,
    4,    2,    0,    3,    2,    6,    5,    2,    1,    2,
    3,    4,    4,    3,    2,    1,    3,    3,    3,    3,
    3,    3,    0,    4,    5,    7,    9,    0,    1,    0,
    2,    2,    4,    4,    0,    2,    3,    3,    1,    2,
    1,    2,    6,    7,    7,    6,    7,    6,    7,    6,
    7,    6,    7,    2,    4,    1,    1,    1,    1,    4,
    3,    0,    1,    2,    1,    1,    1,
};
short yydefred[] = {                                      0,
    0,    0,   67,   66,    0,   65,    0,    2,    0,    0,
    0,    0,    5,    1,    0,    0,    4,    8,    0,    0,
    0,    9,    0,    0,    0,    7,    0,   10,    0,    0,
    0,    0,    0,    0,   29,   11,    0,    0,    0,    0,
    0,    0,    0,   41,    0,    0,    6,   12,    0,    0,
    0,    0,    0,    0,   36,    0,    0,    0,    0,    0,
    0,    0,    0,    0,   42,   63,    0,    0,    0,    0,
    0,    0,    0,   38,   37,   17,   18,   20,   19,   22,
   21,    0,   64,    0,    0,   33,   34,   55,   59,   58,
    0,    0,   24,    0,    0,    0,    0,    0,    0,    0,
   25,    0,   56,   57,   43,   46,   48,   50,   52,    0,
    0,    0,    0,    0,    0,    0,   44,   45,   47,   49,
   51,   53,   26,    0,    0,   27,
};
short yydgoto[] = {                                       2,
  103,  104,  105,   92,   10,    8,   16,   21,   27,   22,
   36,   37,   38,   39,   40,   41,   42,   43,   44,   67,
};
short yysindex[] = {                                   -267,
 -141, -260,    0,    0, -257,    0, -106,    0,  -57, -260,
 -229, -260,    0,    0, -141, -259,    0,    0, -260,    9,
 -120,    0,   13, -129,  -56,    0,  -47,    0, -129, -141,
 -141, -141, -260, -172,    0,    0, -163, -163, -206, -187,
 -221, -260, -163,    0, -260,   42,    0,    0,  -86, -154,
 -143, -150, -141, -141,    0, -163, -163,  -83, -139,  -83,
 -127, -139, -127,   88,    0,    0, -260, -260, -163, -163,
 -141, -141, -170,    0,    0,    0,    0,    0,    0,    0,
    0,  -41,    0, -260, -163,    0,    0,    0,    0,    0,
    3, -141,    0,   39, -137, -137, -137, -137, -137,   14,
    0, -260,    0,    0,    0,    0,    0,    0,    0, -137,
 -137, -137, -137, -137, -137,   80,    0,    0,    0,    0,
    0,    0,    0, -260,  111,    0,
};
short yyrindex[] = {                                      0,
    0,    0,    0,    0, -119,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0, -117,    0,    0,    0,    0, -117,    0,
    0,    0,    0,    0,    0,    0,    0, -118,  -94, -217,
 -217,    0, -116,    0,   44,    0,    0,    0, -117, -147,
 -146, -122,    0,    0,    0, -107, -105,  -94,  -90,  -94,
 -217,  -90, -217,    0,    0,    0,   54,   44,    0, -103,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,   55, -101,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,
};
short yygindex[] = {                                      0,
   15,   17,   -2,    0,    0,  171,    0,    0,    0,  161,
  155,  136,  -12,  -29,  -31,   21,    0,  -15,  -22,  118,
};
#define YYTABLESIZE 232
short yytable[] = {                                      93,
   12,   45,   54,    1,   26,   19,   16,   58,   39,   63,
   60,   62,    6,    6,    9,    5,   11,   15,    7,   40,
   65,   14,   57,   13,   56,   13,    7,   77,   17,   18,
   80,   79,   20,   81,   65,   23,   70,   20,   15,   99,
   57,   46,   34,   23,   49,   50,   51,   35,   55,   52,
  115,  111,   31,   32,   57,   28,   85,   34,   64,   59,
   61,   66,   97,   95,   96,   98,   24,   74,   75,   57,
   29,   31,   32,  113,  110,  112,  114,   47,   76,  101,
   78,   35,  102,   83,   66,   86,   87,   91,   88,   53,
   54,   89,   90,  106,  107,  108,  109,   33,   94,   68,
   83,    3,    4,    3,    4,   71,  100,  117,  118,  119,
  120,  121,  122,   31,   32,   72,   31,   32,  116,   73,
  123,   31,   32,  124,   34,   31,   32,   82,   30,   31,
   32,   33,    3,    4,   34,    6,    3,    4,   54,   35,
  125,   35,   54,   54,   19,   25,   16,   16,   39,   39,
   54,  126,    6,    3,   16,   28,   39,   15,   15,   40,
   40,   14,   14,   13,   13,   15,   30,   40,   62,   14,
   35,   13,   31,   32,   33,   31,   32,   34,   61,   60,
   14,   28,   35,   48,   69,   84,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    6,    6,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    6,
};
short yycheck[] = {                                      41,
   58,   58,  125,  271,  125,  265,  125,   39,  125,   41,
   40,   41,  273,  273,  272,    1,  123,  125,    2,  125,
   43,  125,   38,  125,   37,    9,   10,   59,   12,   15,
   62,   61,   16,   63,   57,   19,   49,   21,  268,   37,
   56,   25,  264,  261,   30,   31,   32,  269,   34,   33,
   37,   38,  259,  260,   70,  273,   69,  264,   42,   39,
   40,   45,   60,   61,   62,   63,   58,   53,   54,   85,
   58,  259,  260,   60,   61,   62,   63,  125,   58,   41,
   60,  269,   44,   67,   68,   71,   72,   73,  259,  262,
  263,  262,  263,   96,   97,   98,   99,  261,   82,   58,
   84,  274,  275,  274,  275,  260,   92,  110,  111,  112,
  113,  114,  115,  261,  261,  259,  264,  264,  102,  270,
   41,  269,  269,   44,  264,  273,  273,   40,  258,  259,
  260,  261,  274,  275,  264,  273,  274,  275,  261,  269,
  124,  269,  265,  266,  265,  266,  265,  266,  265,  266,
  273,   41,  273,  273,  273,  273,  273,  265,  266,  265,
  266,  265,  266,  265,  266,  273,  261,  273,  125,  273,
  261,  273,  259,  260,  261,  259,  260,  264,  125,  125,
   10,   21,  269,   29,   49,   68,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,  273,  273,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,  273,
};
#define YYFINAL 2
#ifndef YYDEBUG
#define YYDEBUG 0
#endif
#define YYMAXTOKEN 275
#if YYDEBUG
char *yyname[] = {
"end-of-file",0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,"'%'","'&'",0,"'('","')'",0,0,"','",0,0,0,0,0,0,0,0,0,0,0,0,0,"':'",0,
"'<'","'='","'>'","'?'",0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,"'{'",0,"'}'",0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,"STATE","CODE","TIME","RANDOM","TO","MINUS","PLUS","RUNL",
"FIRST","ABORT","NAME","STATUS","ACTION","ON","PNUM","RESTART","STRING","CAPS",
"NUMBER",
};
char *yyrule[] = {
"$accept : statelist",
"statelist : PNUM newnum restart all",
"statelist : statelist all",
"restart :",
"restart : RESTART ':' newstring",
"restart : RESTART newstring",
"all : newstring '{' status states abort '}'",
"all : newstring '{' status states '}'",
"status : STATUS newnum",
"states : shortstate",
"states : states shortstate",
"shortstate : newstring ':' rest",
"shortstate : FIRST newstring ':' rest",
"rest : CODE newnum ta ahead",
"rest : CODE newnum ahead",
"rest : ta ahead",
"rest : ahead",
"ta : action runl time",
"ta : action time runl",
"ta : runl time action",
"ta : runl action time",
"ta : time runl action",
"ta : time action runl",
"action :",
"action : lact newstring '(' ')'",
"action : lact newstring '(' newstring ')'",
"action : lact newstring '(' newstring ',' newstring ')'",
"action : lact newstring '(' newstring ',' newstring ',' newstring ')'",
"lact :",
"lact : ACTION",
"time :",
"time : TIME newnum",
"time : RANDOM newnum",
"time : TIME newnum RANDOM newnum",
"time : RANDOM newnum TIME newnum",
"runl :",
"runl : RUNL newnum",
"runl : RUNL PLUS newnum",
"runl : RUNL MINUS newnum",
"ahead : esc",
"ahead : ahead esc",
"esc : escape",
"esc : esc escape",
"escape : TO newstring ON newnum '=' address",
"escape : TO newstring ON sign newnum '=' address",
"escape : TO newstring ON sign newnum '&' address",
"escape : TO newstring ON newnum '>' address",
"escape : TO newstring ON sign newnum '>' address",
"escape : TO newstring ON newnum '<' address",
"escape : TO newstring ON sign newnum '<' address",
"escape : TO newstring ON newnum '?' address",
"escape : TO newstring ON sign newnum '?' address",
"escape : TO newstring ON newnum '%' address",
"escape : TO newstring ON sign newnum '%' address",
"escape : TO newstring",
"escape : TO newstring ON TIME",
"address : newnum",
"address : newstring",
"sign : PLUS",
"sign : MINUS",
"abort : ABORT newstring ':' ab1",
"abort : ABORT ':' ab1",
"ab1 :",
"ab1 : newstring",
"ab1 : ab1 newstring",
"newstring : STRING",
"newnum : NUMBER",
"newnum : CAPS",
};
#endif
#define yyclearin (yychar=(-1))
#define yyerrok (yyerrflag=0)
#ifndef YYSTACKSIZE
#ifdef YYMAXDEPTH
#define YYSTACKSIZE YYMAXDEPTH
#else
#define YYSTACKSIZE 300
#endif
#endif
int yydebug;
int yynerrs;
int yyerrflag;
int yychar;
short *yyssp;
YYSTYPE *yyvsp;
YYSTYPE yyval;
YYSTYPE yylval;
#define yystacksize YYSTACKSIZE
short yyss[YYSTACKSIZE];
YYSTYPE yyvs[YYSTACKSIZE];
#line 415 "sp.y"
#include <stdio.h>
#include "lex.yy.c"
#include <ctype.h>
#include "sp.h"

struct names {
	char *sn,*sc;
	char *sa,*sa1,*sa2,*sa3;
	char *sl;
	char *sz;
	char *st,*sr;
	struct escp {
		char *se,*sf,*sad,*sm;
	} es[5];
	struct names *nptr;
};

/* list of string pointers for states */
#define MAXSTATE 400
struct names list[MAXSTATE] = {0};
/* pointer to state yacc currently working on */
struct names *sptr = list;

/* commonly used strings */
char *time = {"TIME"};
char *bitoff = {"BITOFF"};
char *biton = {"BITON"};
char *function = {"FUNC"};
char *equal = {"EQUAL"};
char *less = {"LESSOR"};
char *greater = {"GREATER"};
char *question = {"QUERY"};
char *zero = {"0"};
char *one = {"1"};
char *two = {"2"};
char *three = {"3"};

/* the buffer for the strings put away by lex */
char buffer[8000] = {0};
/* pointer to the null terminating the last string */
char *lptr = buffer - 1;


/* list of pointers to the start state of each loop */
char *begbuf[50] = {0};
char **begstack = begbuf;

/* the names of the control loops - not currently used */
char *names[50] = {0};
char **pnames = names;

/* the status of the loops at init time */
char *stat[50] = {0};
char **pstat = stat;

/* the pointers to the aborts of each loop. These are terminated by
 *	a 0 pointer.
 */
char *ablist[50] = {0};
/* the current number of aborts listed */
int abcount = {0};
char ab = {'a'};

/* the init function names */
char *fnlist[50] = {0};
char **fnptr = fnlist;

/* the paradigm number for this paradigm */
char *pnum = {0};
int i = {0};
int index = {0};
int loop = {0};


extern FILE *outfd;


/* copy string s2 to s1, return pointer s1 at end of string */
/*
char *
copystr(char *s1,char *s2)
{
	while (*s1++ = *s2++);
	return(s1 - 1);
}
*/
/* put out the required 'includes ' */
void
includes()
{
	fprintf(stdout,"#include <stdio.h>\n");
	fprintf(stdout,"#include <sys/types.h>\n");
	fprintf(stdout,"#include \"../hdr/sys.h\"\n");
	fprintf(stdout,"#include \"../hdr/cnf.h\"\n");
	fprintf(stdout,"#include \"../hdr/proc.h\"\n");
	fprintf(stdout,"#include \"../hdr/buf.h\"\n");
	fprintf(stdout,"#include \"../hdr/menu.h\"\n");
	fprintf(stdout,"#include \"../hdr/state.h\"\n");
	fprintf(stdout,"#include \"../hdr/ecode.h\"\n");
	fprintf(stdout,"#include \"../hdr/device.h\"\n");
	fprintf(stdout,"#include \"../hdr/cdsp.h\"\n");
	fprintf(stdout,"#include \"../hdr/int.h\"\n");
	fprintf(stdout,"\n\n");
}

/* put out the state in the correct format */
void
states_names()
{
	register struct names *fptr;
	register struct escp *eptr;
	register int i;

	for (fptr = list; fptr < sptr; fptr++) {
		fprintf(stdout,"STATE s%s = {\n",fptr->sn);
		fprintf(stdout,"\t{\"%s\"},%s\n",fptr->sn,fptr->sc);
		fprintf(stdout,"\t,%s,%s\n",fptr->sz,fptr->sl);
		fprintf(stdout,"\t,{%s,%s,%s,%s}\n",fptr->sa,fptr->sa1,fptr->sa2,fptr->sa3);
		fprintf(stdout,"\t,%s,%s\n",fptr->st,fptr->sr);

		eptr = fptr->es;
		for (i = 0; i < 5; i++) {
			if (*eptr->se == '0') {
				fprintf(stdout,"\t,{0,0,%s,%s,",eptr->se,eptr->sf);
				fprintf(stdout,"%s,%s}\n",eptr->sad,eptr->sm);
			}
			else {
				fprintf(stdout,"\t,{0,0,&s%s,%s,",eptr->se,eptr->sf);
				if (islower(*eptr->sad))
					fprintf(stdout,"&%s,%s}\n",eptr->sad,eptr->sm);
				else fprintf(stdout,"%s,%s}\n",eptr->sad,eptr->sm);
			}
			eptr++;
		}
		fprintf(stdout,"};\n");
	}
	fprintf(stdout,"\n\n\n");
}

/* put out all needed external declarations */
void
globals_names()
{
	register int i;
	register struct names *fptr;
	register struct escp *eptr;

	printf("\n\n");
	for (fptr = list; fptr < sptr; fptr++) {
		if (islower(*fptr->sa)) {
			fprintf(stdout,"extern int %s();\n",fptr->sa);
		}

		eptr = fptr->es;
		for (i = 0; i < 5; i++) {
			if (islower(*eptr->sad))
			  if(eptr->sf == function)
				fprintf(stdout,"extern int %s();\n",eptr->sad);
			  else fprintf(stdout,"extern int %s;\n",eptr->sad);
			eptr++;
		}
	}
	fprintf(stdout,"\n\n\n");

	for (fptr = list; fptr < sptr; fptr++) {
		fprintf(stdout,"STATE s%s;\n",fptr->sn);
	}
	fprintf(stdout,"\n\n\n");
	fprintf(stdout,"STATE *snames[] = {\n");
	for (fptr = list; fptr < sptr; fptr++) {
		fprintf(stdout,"&s%s,\n",fptr->sn);
	}
	fprintf(stdout,"0};\n\n");
}

/* make the state table in memory all "0". It is convenient */
void
ilist()
{
	register struct names *kptr;
	register int i;

	for (kptr = list; kptr < &list[MAXSTATE]; kptr++) {
			kptr->sn = zero;
			kptr->sc = zero;
			kptr->sl = zero;
			kptr->sz = zero;
			kptr->sa = zero;
			kptr->sa1 = zero;
			kptr->sa2 = zero;
			kptr->sa3 = zero;
			kptr->st = zero;
			kptr->sr = zero;
			for (i = 0; i < 5; i++) {
				kptr->es[i].sf = zero;
				kptr->es[i].sad = zero;
				kptr->es[i].se = zero;
				kptr->es[i].sm = zero;
			}
	}
}

/* get out the structures which are used by the state processor */
void
inittable()
{
	register char **fptr;
	int i;

	fprintf(stdout,"int sf_init();\n\n");
	fprintf(stdout,"STATE sps_state;\n\n");
	fprintf(stdout,"AWAKE init_state[] = {\n");
	fprintf(stdout,"\t{0,ON,ON,&sps_state,&sps_state,0,&init_state[1],0,\n\
			&sps_state.escape}\n");
	fprintf(stdout,"\t,{0,0,0,0,0,&sps_state.es2}\n};\n");

	fprintf(stdout,"STATE sps_state = {\n");
	fprintf(stdout, "\t{\"spec\"},1\n\t,1,0\n");
	fprintf(stdout, "\t,{sf_init,%s}\n", pnum);
	fprintf(stdout,"\t,0,0\n\t,{0,init_state,&sps_state,TIME}\n");
	fprintf(stdout,"\t,{0,0,0,0}\n};\n");

		fprintf(stdout,"AWAKE nowstate[] = {\n\t");
	for (i = 0; i < loop; i++) {
		fprintf(stdout,"{0,%s,%s,&s%s,&s%s,abort%c,0,0,0}\n\t,",stat[i],stat[i],begbuf[i],
			begbuf[i],'a' + i);
	}

	fprintf(stdout,"{0,0,0,0,0,0,0,0,0}");
	fprintf(stdout,"\n};\n\n");


	/* the following is the kludge for init routines to be called */
	for (fptr = fnlist; *fptr; fptr++) {
		fprintf(stdout,"void %s();\n",*fptr);
	}

	fprintf(stdout,"int (*init_list[])() = {\n");
	for (fptr = fnlist; *fptr; fptr++) {
		fprintf(stdout,"%s,\n",*fptr);
	}

	fprintf(stdout,"0};\n");
	fflush(stdout);
}

/* put out the abort lists for the different control loops */
void
aborts()
{
	int i;
	register char **fptr;

	fptr = ablist;

	for (i = 0; i < loop; i++) {
		fprintf(stdout,"STATE *abort%c[] = {\n",ab++);
		for (; *fptr; fptr++) {
			fprintf(stdout,"&s%s,\n",*fptr);
		}

		fprintf(stdout,"0};\n\n");
		fptr++;
	}
}

/* only error is return line number of error */
void
yyerror(char *s)
{
	extern int lineno;

	fprintf(stderr,"error %s: line %d\n", s, lineno);
}


void
spot()
{
	/* set up lex to be in the proper state */
	go(); 
	ilist();
	includes();
	yyparse();
	/* get out the result of all this fooling around */
	globals_names();
	usercode();
	states_names();
	aborts();
	inittable();
	varlist();
}

#line 561 "y.tab.c"
#define YYABORT goto yyabort
#define YYACCEPT goto yyaccept
#define YYERROR goto yyerrlab
int
yyparse()
{
    register int yym, yyn, yystate;
#if YYDEBUG
    register char *yys;
    extern char *getenv();

    if (yys = getenv("YYDEBUG"))
    {
        yyn = *yys;
        if (yyn >= '0' && yyn <= '9')
            yydebug = yyn - '0';
    }
#endif

    yynerrs = 0;
    yyerrflag = 0;
    yychar = (-1);

    yyssp = yyss;
    yyvsp = yyvs;
    *yyssp = yystate = 0;

yyloop:
    if (yyn = yydefred[yystate]) goto yyreduce;
    if (yychar < 0)
    {
        if ((yychar = yylex()) < 0) yychar = 0;
#if YYDEBUG
        if (yydebug)
        {
            yys = 0;
            if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
            if (!yys) yys = "illegal-symbol";
            printf("yydebug: state %d, reading %d (%s)\n", yystate,
                    yychar, yys);
        }
#endif
    }
    if ((yyn = yysindex[yystate]) && (yyn += yychar) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yychar)
    {
#if YYDEBUG
        if (yydebug)
            printf("yydebug: state %d, shifting to state %d\n",
                    yystate, yytable[yyn]);
#endif
        if (yyssp >= yyss + yystacksize - 1)
        {
            goto yyoverflow;
        }
        *++yyssp = yystate = yytable[yyn];
        *++yyvsp = yylval;
        yychar = (-1);
        if (yyerrflag > 0)  --yyerrflag;
        goto yyloop;
    }
    if ((yyn = yyrindex[yystate]) && (yyn += yychar) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yychar)
    {
        yyn = yytable[yyn];
        goto yyreduce;
    }
    if (yyerrflag) goto yyinrecovery;
#ifdef lint
    goto yynewerror;
#endif
yynewerror:
    yyerror("syntax error");
#ifdef lint
    goto yyerrlab;
#endif
yyerrlab:
    ++yynerrs;
yyinrecovery:
    if (yyerrflag < 3)
    {
        yyerrflag = 3;
        for (;;)
        {
            if ((yyn = yysindex[*yyssp]) && (yyn += YYERRCODE) >= 0 &&
                    yyn <= YYTABLESIZE && yycheck[yyn] == YYERRCODE)
            {
#if YYDEBUG
                if (yydebug)
                    printf("yydebug: state %d, error recovery shifting\
 to state %d\n", *yyssp, yytable[yyn]);
#endif
                if (yyssp >= yyss + yystacksize - 1)
                {
                    goto yyoverflow;
                }
                *++yyssp = yystate = yytable[yyn];
                *++yyvsp = yylval;
                goto yyloop;
            }
            else
            {
#if YYDEBUG
                if (yydebug)
                    printf("yydebug: error recovery discarding state %d\n",
                            *yyssp);
#endif
                if (yyssp <= yyss) goto yyabort;
                --yyssp;
                --yyvsp;
            }
        }
    }
    else
    {
        if (yychar == 0) goto yyabort;
#if YYDEBUG
        if (yydebug)
        {
            yys = 0;
            if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
            if (!yys) yys = "illegal-symbol";
            printf("yydebug: state %d, error recovery discards token %d (%s)\n",
                    yystate, yychar, yys);
        }
#endif
        yychar = (-1);
        goto yyloop;
    }
yyreduce:
#if YYDEBUG
    if (yydebug)
        printf("yydebug: state %d, reducing by rule %d (%s)\n",
                yystate, yyn, yyrule[yyn]);
#endif
    yym = yylen[yyn];
    yyval = yyvsp[1-yym];
    switch (yyn)
    {
case 1:
#line 42 "sp.y"
{
				pnum = yyvsp[-2].cpval ;
			}
break;
case 4:
#line 50 "sp.y"
{
				*fnptr++ = yyvsp[0].cpval ;
			}
break;
case 5:
#line 54 "sp.y"
{
				*fnptr++ = yyvsp[0].cpval ;
			}
break;
case 6:
#line 60 "sp.y"
{
				*pnames++ = yyvsp[-5].cpval ;
				loop++;
				abcount++;
			}
break;
case 7:
#line 66 "sp.y"
{
				*pnames++ = yyvsp[-4].cpval ;
				loop++;
				abcount++;
			}
break;
case 8:
#line 74 "sp.y"
{
			*pstat++ = yyvsp[0].cpval ;
		}
break;
case 9:
#line 80 "sp.y"
{
				sptr++;
				index = 0;
			}
break;
case 10:
#line 85 "sp.y"
{
				sptr++;
				index = 0;
			}
break;
case 11:
#line 92 "sp.y"
{
				sptr->sn = yyvsp[-2].cpval ;
				if (index >= 5) {
					fprintf(stderr,
						"STATE %s: too many escapes\n",
						sptr->sn);
					exit(1);
				}
			}
break;
case 12:
#line 102 "sp.y"
{
/*
static int first_loop = 0;
if (first_loop == 0) {
sptr = list;
first_loop ++;
sptr->sn = $2;
fprintf(stderr,"first state = %s\n",$2);
}
*/
				*begstack++ = yyvsp[-2].cpval ;
				sptr->sn = yyvsp[-2].cpval ;
				if (index >= 5) {
					fprintf(stderr,
						"STATE %s: too many escapes\n",
						sptr->sn);
					exit(1);
				}
			}
break;
case 13:
#line 124 "sp.y"
{
				sptr->sc = yyvsp[-2].cpval ;
			}
break;
case 14:
#line 128 "sp.y"
{
				sptr->sc = yyvsp[-1].cpval ;
			}
break;
case 24:
#line 145 "sp.y"
{
			sptr->sa = yyvsp[-2].cpval ;
		}
break;
case 25:
#line 149 "sp.y"
{
				sptr->sa = yyvsp[-3].cpval ;
				sptr->sa1 = yyvsp[-1].cpval ;
			}
break;
case 26:
#line 154 "sp.y"
{
				sptr->sa = yyvsp[-5].cpval ;
				sptr->sa1 = yyvsp[-3].cpval ;
				sptr->sa2 = yyvsp[-1].cpval ;
			}
break;
case 27:
#line 160 "sp.y"
{
				sptr->sa = yyvsp[-7].cpval ;
				sptr->sa1 = yyvsp[-5].cpval ;
				sptr->sa2 = yyvsp[-3].cpval ;
				sptr->sa3 = yyvsp[-1].cpval ;
			}
break;
case 31:
#line 172 "sp.y"
{
				sptr->st = yyvsp[0].cpval ;
			}
break;
case 32:
#line 176 "sp.y"
{
				sptr->sr = yyvsp[0].cpval ;
			}
break;
case 33:
#line 180 "sp.y"
{
				sptr->st = yyvsp[-2].cpval ;
				sptr->sr = yyvsp[0].cpval ;
			}
break;
case 34:
#line 185 "sp.y"
{
				sptr->sr = yyvsp[-2].cpval ;
				sptr->st = yyvsp[0].cpval ;
			}
break;
case 36:
#line 193 "sp.y"
{
				sptr->sz = one;
				sptr->sl = yyvsp[0].cpval ;
			}
break;
case 37:
#line 198 "sp.y"
{
				sptr->sz = two;
				sptr->sl = yyvsp[0].cpval ;
			}
break;
case 38:
#line 203 "sp.y"
{
				sptr->sz = three;
				sptr->sl = yyvsp[0].cpval ;
			}
break;
case 39:
#line 210 "sp.y"
{
			}
break;
case 40:
#line 213 "sp.y"
{
			}
break;
case 42:
#line 219 "sp.y"
{
			}
break;
case 43:
#line 224 "sp.y"
{
			sptr->es[index].se = yyvsp[-4].cpval ;
			sptr->es[index].sf = equal;
			sptr->es[index].sad = yyvsp[0].cpval ;
			sptr->es[index].sm = yyvsp[-2].cpval ;
			index++;
		}
break;
case 44:
#line 232 "sp.y"
{
			char *tmp;

			/* this will work because a leading ' ' exists */
			if (yyvsp[-3].cpval  == bitoff) {
				yyvsp[-2].cpval  = yyvsp[-2].cpval  - 1;
				tmp = yyvsp[-2].cpval ;
				*tmp = '-';
			}
			sptr->es[index].se = yyvsp[-5].cpval ;
			sptr->es[index].sf = equal;
			sptr->es[index].sad = yyvsp[0].cpval ;
			sptr->es[index].sm = yyvsp[-2].cpval ;
			index++;
		}
break;
case 45:
#line 248 "sp.y"
{
			sptr->es[index].se = yyvsp[-5].cpval ;
			sptr->es[index].sf = yyvsp[-3].cpval ;
			sptr->es[index].sad = yyvsp[0].cpval ;
			sptr->es[index].sm = yyvsp[-2].cpval ;
			index++;
		}
break;
case 46:
#line 256 "sp.y"
{
			sptr->es[index].se = yyvsp[-4].cpval ;
			sptr->es[index].sf = greater;
			sptr->es[index].sad = yyvsp[0].cpval ;
			sptr->es[index].sm = yyvsp[-2].cpval ;
			index++;
		}
break;
case 47:
#line 264 "sp.y"
{
			char *tmp;

			/* this will work because a leading ' ' exists */
			if (yyvsp[-3].cpval  == bitoff) {
				yyvsp[-2].cpval  = yyvsp[-2].cpval  - 1;
				tmp = yyvsp[-2].cpval ;
				*tmp = '-';
			}
			sptr->es[index].se = yyvsp[-5].cpval ;
			sptr->es[index].sf = greater;
			sptr->es[index].sad = yyvsp[0].cpval ;
			sptr->es[index].sm = yyvsp[-2].cpval ;
			index++;
		}
break;
case 48:
#line 280 "sp.y"
{
			sptr->es[index].se = yyvsp[-4].cpval ;
			sptr->es[index].sf = less;
			sptr->es[index].sad = yyvsp[0].cpval ;
			sptr->es[index].sm = yyvsp[-2].cpval ;
			index++;
		}
break;
case 49:
#line 288 "sp.y"
{
			char *tmp;

			/* this will work because a leading ' ' exists */
			if (yyvsp[-3].cpval  == bitoff) {
				yyvsp[-2].cpval  = yyvsp[-2].cpval  - 1;
				tmp = yyvsp[-2].cpval ;
				*tmp = '-';
			}
			sptr->es[index].se = yyvsp[-5].cpval ;
			sptr->es[index].sf = less;
			sptr->es[index].sad = yyvsp[0].cpval ;
			sptr->es[index].sm = yyvsp[-2].cpval ;
			index++;
		}
break;
case 50:
#line 304 "sp.y"
{
			sptr->es[index].se = yyvsp[-4].cpval ;
			sptr->es[index].sf = question;
			sptr->es[index].sad = yyvsp[0].cpval ;
			sptr->es[index].sm = yyvsp[-2].cpval ;
			index++;
		}
break;
case 51:
#line 312 "sp.y"
{
			char *tmp;

			/* this will work because a leading ' ' exists */
			if (yyvsp[-3].cpval  == bitoff) {
				yyvsp[-2].cpval  = yyvsp[-2].cpval  - 1;
				tmp = yyvsp[-2].cpval ;
				*tmp = '-';
			}
			sptr->es[index].se = yyvsp[-5].cpval ;
			sptr->es[index].sf = question;
			sptr->es[index].sad = yyvsp[0].cpval ;
			sptr->es[index].sm = yyvsp[-2].cpval ;
			index++;
		}
break;
case 52:
#line 328 "sp.y"
{
			sptr->es[index].se = yyvsp[-4].cpval ;
			sptr->es[index].sf = function;
			sptr->es[index].sad = yyvsp[0].cpval ;
			sptr->es[index].sm = yyvsp[-2].cpval ;
			index++;
		}
break;
case 53:
#line 336 "sp.y"
{
			char *tmp;

			/* this will work because a leading ' ' exists */
			if (yyvsp[-3].cpval  == bitoff) {
				yyvsp[-2].cpval  = yyvsp[-2].cpval  - 1;
				tmp = yyvsp[-2].cpval ;
				*tmp = '-';
			}
			sptr->es[index].se = yyvsp[-5].cpval ;
			sptr->es[index].sf = function;
			sptr->es[index].sad = yyvsp[0].cpval ;
			sptr->es[index].sm = yyvsp[-2].cpval ;
			index++;
		}
break;
case 54:
#line 352 "sp.y"
{
			sptr->es[index].se = yyvsp[0].cpval ;
			sptr->es[index].sf = time;
			index++;
		}
break;
case 55:
#line 358 "sp.y"
{
			sptr->es[index].se = yyvsp[-2].cpval ;
			sptr->es[index].sf = time;
			index++;
		}
break;
case 56:
#line 365 "sp.y"
{
				yyval.cpval  = yyvsp[0].cpval ;
			}
break;
case 57:
#line 369 "sp.y"
{
				yyval.cpval  = yyvsp[0].cpval ;
			}
break;
case 58:
#line 374 "sp.y"
{
				yyval.cpval  = biton;
			}
break;
case 59:
#line 378 "sp.y"
{
				yyval.cpval  = bitoff;
			}
break;
case 63:
#line 389 "sp.y"
{
				ablist[abcount++] = yyvsp[0].cpval ;
			}
break;
case 64:
#line 393 "sp.y"
{
				ablist[abcount++] = yyvsp[0].cpval ;
			}
break;
case 65:
#line 399 "sp.y"
{
			yyval.cpval  = yyvsp[0].cpval ;
			}
break;
case 66:
#line 405 "sp.y"
{
				yyval.cpval  = yyvsp[0].cpval ;
			}
break;
case 67:
#line 409 "sp.y"
{
				yyval.cpval  = yyvsp[0].cpval ;
			}
break;
#line 1113 "y.tab.c"
    }
    yyssp -= yym;
    yystate = *yyssp;
    yyvsp -= yym;
    yym = yylhs[yyn];
    if (yystate == 0 && yym == 0)
    {
#ifdef YYDEBUG
        if (yydebug)
            printf("yydebug: after reduction, shifting from state 0 to\
 state %d\n", YYFINAL);
#endif
        yystate = YYFINAL;
        *++yyssp = YYFINAL;
        *++yyvsp = yyval;
        if (yychar < 0)
        {
            if ((yychar = yylex()) < 0) yychar = 0;
#if YYDEBUG
            if (yydebug)
            {
                yys = 0;
                if (yychar <= YYMAXTOKEN) yys = yyname[yychar];
                if (!yys) yys = "illegal-symbol";
                printf("yydebug: state %d, reading %d (%s)\n",
                        YYFINAL, yychar, yys);
            }
#endif
        }
        if (yychar == 0) goto yyaccept;
        goto yyloop;
    }
    if ((yyn = yygindex[yym]) && (yyn += yystate) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yystate)
        yystate = yytable[yyn];
    else
        yystate = yydgoto[yym];
#ifdef YYDEBUG
    if (yydebug)
        printf("yydebug: after reduction, shifting from state %d \
to state %d\n", *yyssp, yystate);
#endif
    if (yyssp >= yyss + yystacksize - 1)
    {
        goto yyoverflow;
    }
    *++yyssp = yystate;
    *++yyvsp = yyval;
    goto yyloop;
yyoverflow:
    yyerror("yacc stack overflow");
yyabort:
    return (1);
yyaccept:
    return (0);
}
