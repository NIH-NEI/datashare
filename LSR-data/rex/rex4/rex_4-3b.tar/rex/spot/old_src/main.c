/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government.  The original
 * versions, REX 1.0-3.12, were developed for the pdp11 architecture and
 * are in the public domain.  This version, REX 4.0, is a port of the
 * original version to the Intel 80x86 architecture.  This version is
 * copyright (C) 1992 by the National Institutes of Health, Laboratory
 * of Sensorimotor Research, Bldg 10 Rm 10C101, 9000 Rockville Pike,
 * Bethesda, MD, 20892, (301) 496-9375.  All rights reserved.
 *-----------------------------------------------------------------------*
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

FILE *outfd = {0};
FILE *efd = {0};

void spot(void);

main(ac,av)
int ac;
char *av[];
{
	register char *ptr;
	FILE *ifd;
	char infile[50],outfile[50],ifile[50];
	char *iptr;
	char *copystr(char *, char *);

	av++;

	while (ac-- > 0 && **av == '-') {
		ptr = *av++;
		for (++ptr; *ptr; ptr++) {
			switch (*ptr) {
				default:
					fprintf(stderr,"bad flag: %c\n",*ptr);
					break;
			}
		}
	}

	if (ac--) {
		if (strcmp((iptr = copystr(infile,*av++)) - 2,".d")) {
			fprintf(stderr,"invalid input name - must be 'name.d'\n");
			exit(1);
		}
		/* open the file for user included code */
		copystr(copystr(ifile,infile) - 2,".i.c");

/*
		unlink(ifile);
*/

		if ((efd = fopen(ifile,"w")) == (FILE *) NULL){
fprintf(stderr,"efd = %o\n", efd);
			fprintf(stderr,"unable to open %s\n", ifile);
			perror("main: efd not assigned");
			exit(1);
		}
	}
	else {
		fprintf(stderr,"use -- spot file.d [name.d.c]\n");
		fprintf(stderr,"file.d - input file, must be '.d'\n");
		fprintf(stderr,"name - optional output name, will have '.d.c' added\n");
		exit(1);
	}

	if (!ac) {
		copystr(copystr(outfile,infile),".c");
	}
	else {
		copystr(copystr(outfile,*av++),".d.c");
	}

	if ((ifd = freopen(infile,"r",stdin)) == 0) {
		fprintf(stderr,"spot: failed to open %s\n",infile);
		exit(1);
	}

	if ((outfd = freopen(outfile,"w",stdout)) == 0) {
		perror("spot: failed to open output");
	}

	spot();

	exit(0);
}

/* copy string s2 to s1, return pointer s1 at end of string */
char *
copystr(char *s1,char *s2)
{
	while (*s1++ = *s2++);
	return(s1 - 1);
}
