/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government.  The original
 * versions, REX 1.0-3.12, were developed for the pdp11 architecture and
 * distributed without restrictions.  This version, REX 4.0, is a port of
 * the original version to the Intel 80x86 architecture.  This version is
 * distributed only under license agreement from the National Institutes 
 * of Health, Laboratory of Sensorimotor Research, Bldg 10 Rm 10C101, 
 * 9000 Rockville Pike, Bethesda, MD, 20892, (301) 496-9375.
 *-----------------------------------------------------------------------*
 */

/*
 *	int.h:  Local header for interrupt process. Should not
 * place anything in here that requires previous inclusion of other
 * headers.
 */
#define TEN_TO_IC	2		/* converts TENs of deg to internal
					   calibration (40 st/deg) */

/*
 * Defs and macros for interprocess communication used in lower level of
 * int process.
 */
#define to_scrb_(msg)	(flag_msg |= (scrb_msg |= s_(msg)))
#define to_disp_(msg)	(flag_msg |= (disp_msg |= s_(msg)))
#define to_comm_(msg)	(flag_msg |= (comm_msg |= s_(msg)))
extern int scrb_msg, disp_msg, comm_msg, flag_msg;

#define TIMER_DEFAULT	10	    /* default for system timer in
				       msec;  should be 10msec */

/*
 * Flags controlling data storage windows.  User should only SET first three
 * bits; never CLEAR any bits.
 */
#define W_CANCEL	01	/* cancel an open window without writing
				   on disk */
#define W_OPEN		02	/* open data storage window */
#define W_CLOSE		04	/* close data window */
#define W_ISOPEN	010	/* window currently open */
#define W_WAITCLOSE	020	/* window has been closed; waiting until post
				   time w_post elapses */
#define W_NULLOPEN	040	/* window opened when keeping not on */
#define W_ERR		0100	/* err condition, causes window to close */

extern int (*p_mksroot)();

/*
 * This struct is used to hold variables from the signal menu.
 */
typedef struct {
#define SIG_OFF 0
#define SIG_AD_SOURCE 1
#define SIG_MEM_SOURCE 2
    int	sig_enable;	/* if NULLI, this signal is disabled */
    int sig_ad_chan;	/* a/d channel for this signal */
    char sig_ad_mem_var[P_LNAME];   /* memory variable for a/d channel */
    int sig_ad_rate;	/* a/d sample rate in hz */
    int	sig_ad_calib;	/* a/d scale factor */
    int	sig_ad_gain;	/* channel gain for a/d's that have channel-gain
			   lists */
    int sig_ad_delay;	/* delay in msec for a/d channel filters */
    char sig_mem_source[P_LNAME];   /* memory variable for non-a/d source */
    char sig_title[P_LNAME];	/* user specified title of signal */
    int sig_store_rate;	/* rate at which signal is stored to A-file */
} SIG;
extern SIG sig[];

/*
 * Holds names and addresses of signals that can be specified in the
 * signal menu.  Initialized in i.c.
 */
typedef struct {
    int	*gv_ptr;	/* pointer to global variable */
    char *gv_name;	/* ascii name of variable */
} GVPTR;
extern GVPTR gv_ad_mem[], gv_mem_src[];

extern int *sa_gvptr[];  /* pointers to internal global variables
			    for each signal, e.g. 'eyeh',
			    'eyev', etc.  These pointers are
			    currently local to int's address space;
			    when bit 'SA_MEMSIG' is set, this
			    is address of incore variable that is
			    source instead of a/d channel */
extern int ad_ov_gain;	/* overall gain for a/d's without individual
			   gains */
extern int ad_max_rate;	/* max acquisition rate and a/d interrupt rate */
extern int ad_min_rate;	/* lowest support a/d acquisition rate */
extern int w_pre;	/* time in msec before window opening that data will
			   be saved */
extern int w_post;	/* time in msec after window closing that data will
			   be kept */
extern int m_pre, m_post;	/* menu prototypes of above */
extern int adumpinc;	/* initialization for high water mark */
extern unsign w_flags;	/* contains window flags */
extern int inside_int;	/* flag is true when int routine is running */
extern short *sa_frame;	/* pointer to current position in frame array */
extern int sa_mfrbeglx;	/* most recent load index pointer to beginning
			   of master sample frame */
extern long sa_mfrbegtime;  /* time of most recent master frame */
extern int sa_1msec_ctd;    /* countdown timer for 1msec intervals */
extern int sa_int_P_ms;	    /* number of ticks of current a/d interrupt
			       rate to equal 1msec;  used to initialize
			       sa_1msec_ctd */
extern int fillcheck;	/* used to check for abuf overflow */
extern int eyeh, eyev;	/* globals to store current eye pos samples */
extern int otherh, otherv;	/* other channels stored in h and v buffers */
extern int oeyeh, oeyev;	/* other eye channel */
extern int addh, addv;		/* additional channels */
extern int joyh, joyv;		/* joystick inputs */
extern unsigned r4_clicks , r5_clicks;
extern unsigned ib4_clicks, ib5_clicks;
extern int sdctl;		/* saccade detection control */
extern int eyeflag;		/* eye position checking flag */
extern int Ctraceon;		/* C running line trace on/off */
extern int rl_wrap;		/* when true, running line wraps */
extern int rl_sig, rl_caddr;	/* variables for assigning C trace */
extern int dina, dinb;		/* holds digital input words */
extern int tyes, tno;		/* trial counts */
extern unsign sig_flags;	/* holds signal flags */
extern int noflag;		/* flag set by score() on bad trials */
extern int c_eyeshift;		/* scale factor for eye coil calibration */
extern int m_calnum;		/* temp storage for variables that live in
				   int_block */
extern int t_wrate;		/* number of ms to skip between eye window
				   checks */
extern int w_rate;		/* refresh rate for wind display */
extern int int_request;		/* interrupt services request flag */
extern int m_sdctl;		/* saccade detector control */
extern int m_uwind, uwind;	/* unit window control flags */
extern int st_rate;		/* state processor execution rate */
extern int sp_lock, ds_lock;	/* locks to prevent re-entering state
				   set proc and display */
extern int phistate, phicount;
extern int Ctcount, Cstate;
extern long c_count;		/* continuation record count */
extern int a_count;		/* analog record write count */
extern long awtime;		/* analog write time */
extern int winrate;		/* rate for eye window check */
extern int rurate;		/* ramp update rate */
extern int eyeint;		/* alternates each int */
extern int samcnt;		/* determines which interrupts data is saved */
extern int hiwat;		/* high water point for writing to disk */
extern int windcnt;		/* fill count of unwritten data for
				   the current window opening */
extern int postcnt;		/* count of samples to save after window
				   closes */
extern int lowx;		/* low index for next write of analog buffers */
extern int lasthighx;		/* last high index of write, or open index */
extern int skip_cnt;		/* skip count for sections of int that may
				   not be executed every interrupt */
extern int mrxout, mryout;
extern int st_count;
#ifdef DMRBLOCK
extern int rlevel;		/* re-interrupt level */
#endif

/*
 * Defines for backward compatibility.
 */
#define drinput		dina

/*
 * Defines for interrupt service requests.
 */
#define IR_RCOMP	01	/* compute ramp */
#define IR_MRMENU	02	/* mirror menu change */
#define IR_RAMENU	04	/* ramp menu change */
#define IR_WDMENU	010	/* window menu change */
#define IR_STMENU	020	/* stabilization menu change */
#define IR_CLEARM	040	/* return mirrors to 0,0 */
#define IR_PREPOST	0100	/* pre, post time menu change */
#define IR_OFFSET	0200	/* change to eye channel offsets */
#define IR_BUSY		0100000	/* negative bit when busy */


/*
 * Window position type and control.
 */
#define WD_OFF		00	/* values of wdctl */
#define WD_EYE_ON	01	/* eye window on */
#define WD_OEYE_ON	02	/* other eye window on */
#define WD_BEYE_ON	03	/* both eye windows on */

#define WD_APOS		0	/* values of wdtype; window position
				   determined by absolute position
				   coordinates */
#define WD_MIR		1	/* window follows current mirror position */
#define WD_RAMP		2	/* follows output of ramp gen */
#define WD_JOY		3	/* follows joystick */

extern int m_wdmenu;		/* menu overides enable for window control */
extern int m_wdxpos;		/* menu specified xpos of window */
extern int m_wdypos;
extern int m_wdxsiz;
extern int m_wdysiz;
extern int m_wdoxsiz;
extern int m_wdoysiz;
extern int m_wdctl;
extern int m_wdtype;
extern int m_wddisp;
extern int wdctl;		/* actual (not menu) variables controlling wd */
extern int wdtype;
extern int *wdxptr, *wdyptr;	/* pointers to window position */
extern int wdxpos, wdypos;	/* x, y pos for absolute position window */
extern int wdxsiz, wdysiz;	/* x, y size of window */
extern int wdoxsiz, wdoysiz;	/* x, y size of window for other eye */
extern int m_bitdio;		/* default device for noun 'bit' */

/*
 * Mirror control.
 */
#define MR_OFF		0	/* values of mrctl */
#define MR_APOS		1	/* mirror position det. by abs position
				   coord */
#define MR_WFG		2	/* position det. by approp. wave form gen */
#define MR_JOY		3	/* mirror follows joystick */

extern int m_mrmenu;		/* menu overides enabled */
extern int m_mrxpos, m_mrypos;	/* menu variables for x, y absolute position */
extern int m_mrctl;
extern int mrctl;		/* actual control values */
extern int mrxpos, mrypos;
extern int mrxcur, mrycur;	/* actual current location of mirrors */

/*
 * Eye channel offsets.
 */
extern int m_offmenu;		/* menu overides enabled */
extern int m_eho, m_evo;	/* menu variables for eye offsets */
extern int m_oeho, m_oevo;	/* menu variables for other eye offsets */
extern int eho, evo, oeho, oevo;

/*
 * Stabilization control.
 */
#define ST_OFF		0	/* note that stctl contains bit flags and is
				   not a scalar value, as other 'ctls */
#define ST_HOR		01	/* horiz stab */
#define ST_VERT		02	/* vert stab */

extern int m_stmenu;
extern int m_stxoff, m_styoff;	/* menu copies of stab offsets */
extern int m_stctl;
extern int stctl;		/* actual control values */
extern int stxoff, styoff;
extern int c_fp;	/* fixation point */
extern int c_dim;	/* dim device */
extern int c_curp;	/* index to current eye position structure */
extern int c_xhold;	/* temp holds eye positions */
extern int c_yhold;
extern int c_oxhold;
extern int c_oyhold;

/*
 * 	Values for eye positions are accumulated in this struct.
 */
#define C_KEEPMAX	10	/* save 10 previous values */
extern struct c_eyekeep {
	int c_xsav;
	int c_ysav;
	int c_oxsav;
	int c_oysav;
} c_eyekeep[C_KEEPMAX];

/*
 * Prototypes.
 */
void clk_stop(void);
void clk_set(int msec);
void clk_start(void);
void ad_start(void);
void ad_stop(void);
int ad_ds_init(void);
int ad_ds_uninit(void);
void ad_ds_begin(void);
void ad_ds_end(void);
void oncntrlb(int sig);
void alert(int sig);
int flag_af(int flag, MENU *mp, char *astr, VLIST *vlp, int *tvadd);
void n_clock(char *vstr, char *astr);
void n_slist(char *vstr, char *astr);
void n_mirror(char *vstr, char *astr);
void n_calib(char *vstr, char *astr);
void n_bit(char *vstr, char *astr);
void n_signals(char *vstr, char *astr);
void cal_print(void);
void cl_cal(void);
void again(void);
#ifdef CC_RAMP
int ra_vaf(int flag, MENU *mp, char *astr, VLIST *vlp, int *tvadd);
int ras0_rate_vaf(int flag, MENU *mp, char *astr, VLIST *vlp, int *tvadd);
#endif
int cp_chan_vaf(int flag, MENU *mp, char *astr, VLIST *vlp, int *tvadd);
int cp_rate_vaf(int flag, MENU *mp, char *astr, VLIST *vlp, int *tvadd);
int cp_cal_vaf(int flag, MENU *mp, char *astr, VLIST *vlp, int *tvadd);
void cal_init(void);
int sd_vaf(int flag, MENU *mp, char *astr, VLIST *vlp, int *tvadd);
int wd_sc_vaf(int flag, MENU *mp, char *astr, VLIST *vlp, int *tvadd);
int wd_vaf(int flag, MENU *mp, char *astr, VLIST *vlp, int *tvadd);
int mr_vaf(int flag, MENU *mp, char *astr, VLIST *vlp, int *tvadd);
int cp_aw_vaf(int flag, MENU *mp, char *astr, VLIST *vlp, int *tvadd);
int cp_uw_vaf(int flag, MENU *mp, char *astr, VLIST *vlp, int *tvadd);
int off_vaf(int flag, MENU *mp, char *astr, VLIST *vlp, int *tvadd);
int st_vaf(int flag, MENU *mp, char *astr, VLIST *vlp, int *tvadd);
int rl_vaf(int flag, MENU *mp, char *astr, VLIST *vlp, int *tvadd);
void wd_iscale(void);
int uw_set(long flag);
int sd_set(long flag);
int prego(void);
void tclock(void);
void wd_scur(int wind, int disp);
#ifdef NEED_FAR
pid_t far ad_int_hand();
#else
pid_t ad_int_hand();
#endif
void msec_clock(int sig);
int mr_set(long ctlval, long xpos, long ypos);
int awind(long flag);
int pre_post(long pre, long post);
int hold_eye(void);
int keep_eye(void);
int mr_mov(long xpos, long ypos);
int off_eye(long hoff, long voff);
int off_oeye(long hoff, long voff);
int score(long x);
int sd_set(long ctlval);
int uw_set(long flag);
int stab_set(long ctlval, long xoff, long yoff);
int wd_ctl(long ctlval, long type, long disp);
int wd_osiz(long xsiz, long ysiz);
int wd_pos(long xpos, long ypos);
int wd_siz(long xsiz, long ysiz);
int sig_init(void);
int sig_ck_sig_enable(int snum, int enable);
int sig_ck_chan(int snum, int chan);
int sig_ck_ad_mem_var(int snum, char *sp);
int sig_ck_ad_acq_rate(int snum, int rate);
int sig_ck_ad_max_rate(int snum, int rate);
void sig_compute_ad_rates(void);
int sig_ck_ad_calib(int snum, int calib);
int sig_ck_ad_gain(int snum, int gain);
int sig_ck_mem_src_var(int snum, char *sp);
int sig_ck_sig_store_rate(int snum, int store_rate);
int sig_ck_sig_title_var(int snum, char *sp);
int sig_check_str(char *sp);
GVPTR *gv_look(GVPTR *gvp, char *sp);
int get_rates_index(int snum, int rate);
void sig_e(int snum, char *sp);
void null_samp_arrays(void);
void null_sig_arrays(void);

