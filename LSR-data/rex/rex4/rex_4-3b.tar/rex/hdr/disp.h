/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government.  The original
 * versions, REX 1.0-3.12, were developed for the pdp11 architecture and
 * distributed without restrictions.  This version, REX 4.0, is a port of
 * the original version to the Intel 80x86 architecture.  This version is
 * distributed only under license agreement from the National Institutes 
 * of Health, Laboratory of Sensorimotor Research, Bldg 10 Rm 10C101, 
 * 9000 Rockville Pike, Bethesda, MD, 20892, (301) 496-9375.
 *-----------------------------------------------------------------------*
 */

/*
 * Display process header.
 */

/*
 * Size defines.
 */
#define RASTHNUM	16	/* max num of rast, hist pairs */
#define TLISTNUM	400	/* size of tlist */
#define NBINS		(RASTHNUM * 130)	/* max num of hist bins for
						   all hists together */
#define MAXSHF		5	/* max shift factor for ms_P_dot and
				   dots_P_bin */

/*
 * Histograms are cumulative and scaled by powers of two for speed.  When
 * a bin reaches the top all bins are divided by two.  Then, in order to
 * maintain proper proportions the bin count is incremented once for every
 * two units that fall in.  This process repeats:  if the bins have been
 * scaled by 4, 8, 16, 32, etc, then 4, 8, 16, 32 units must occur for
 * each bin to be incremented.  The histogram can also be scaled in the
 * reverse direction- for each unit the bin is incremented by 2, 4, 8, etc.
 * This algorithm requires a bin count and an accumulator.  The accumulator
 * is incremented for each unit and then divided by the current scaling
 * factor.  If there is a quotient it is added to the bin count, the remainder
 * is put in the accumulator.  A byte each is devoted to the bin count
 * and accumulator.  Therefore the max scaling factor is 128 (base 2 log 7)
 * and the max bin count is 256 (size of bin) * 128 = 32,768.
 */
typedef struct {
	u_char	b_bcnt;		/* bin count */
	u_char	b_acc;		/* accumulator */
} BIN;
extern BIN bins[];

/*
 * Each raster, histogram pair is specified by an instance of the following
 * structure.  Both the raster and hist may be active, or either one alone
 * as determined by the rh_flag field.  All routines that process rasters,
 * histograms operate on data in these structures ONLY.  There are no
 * global data apart from these structures that characterize rasters, hists.
 * Therefore such parameters as number of, size, position on screen, time
 * base, horiz length, etc. can be easily changed simply by specifing
 * appropriate initializations below without making changes to code.
 *
 * NOTE:  Display assumes times in event buffer are on a 1 msec clock.
 */
typedef struct {
	int	rh_flag;	/* flags controlling rast, hists */
	int	r_sf_ms_P_dot;	/* shift factor, log base 2 of ms_P_dot */
	int	h_sf_dots_P_bin;
	int	rh_xlen;	/* x and y length in dots of screen occupied */
	int	rh_ylen;	/* 	by rast or hist */
	int	r_xadd;		/* x address of lower left corner of raster */
	int	r_yadd;
	int	h_xadd;		/* address of lower left corner of hist */
	int	h_yadd;
	int	r_dely;		/* delta between raster lines */
	int	rh_trig;	/* trigger event code */
	int	r_trigtoff;	/* time offset in msec of trigger line from
				   center of raster; - (left), + (right) */
	int	rh_laba_yo;	/* yoffset of a label line */
	int	rh_labb_yo;	/* b label line */
	int	rh_tics_yo;	/* y offset of tic mark line */
	int	r_unitcode;	/* unit event code for this raster */
	int	h_isfact;	/* initial hist scaling factor; ignored if
				   h_autosel is true */
	int	h_autosel;	/* when true, select initial scaling factor
				   automatically */
	int	rh_trig_xo;	/* x offset of trigger line */
	int	r_top_yo;	/* yoff of top raster line */
	int	r_bot_yo;	/* yoff of bot raster line */
	int	r_ms_P_dot;	/* time scale of rast, hist is specified in
				   msec per matrox dot;  both ms_P_dot and
				   dots_P_bin must be powers of 2 */
	int	h_dots_P_bin;	/* width of bin is specified in dots_P_bin */
	int	r_cline_yo;	/* yoff of current raster line */
	int	r_nlines;	/* number of lines */
	int	r_tplus;	/* msec from trigger to right margin */
	int	r_tminus;	/* msec from trigger to left margin */
	long	h_ltime;	/* time of last trigger for this hist */
	long	r_ltime;	/* time of last trigger for this rast */
	long	rh_itime;	/* time rast, hist was last cleared;  triggers
				   before this time are not processed */
	int	h_btop;		/* max displayable bin count */
	int	h_bbot_yo;	/* yoff of bottom of hist (above tics line) */
	int	h_sfact;	/* base 2 log of scaling factor */
	int 	h_smask;	/* mask generated from h_sfact */
	int	h_tcnt;		/* cumulative num of triggers for this hist */
	BIN	*h_sbp;		/* pointer to start of bins for this hist */
	BIN	*h_ebp;		/* points to end of this hist's bins + 1 */
} RASTH;

/*
 * Defines for rh_flag.
 */
#define RH_RAST		01	/* rast is being displayed */
#define RH_HIST		02	/* hist is being displayed */

/*
 * dras() searches for past triggers and stores them here for fillras().
 */
typedef struct {
	EVENT_P	tl_trig;	/* pointer to trigger in event buffer */
	RASTH	*tl_rasth;	/* pointer to rasth struct for this trigger */
	long	tl_time;	/* time of this trigger */
} TLIST;
extern TLIST tlist[];

/*
 * Spacing of tic marks for different values of ms_P_dot kept in this
 * struct.
 */
typedef struct {
	int	ts_small;	/* spacing in dots between small tic marks */
	int	ts_large;	/* spacing between large marks */
} TSCALE;
extern TSCALE tscale[];

#define LARGESZ		3	/* size in dots of large tic mark */
#define SMALLSZ		1	/* size of small mark */

/*
 * Pointer to various screen configurations.
 */
typedef struct {
	RASTH	*c_rhp;		/* pointer to this cnf's RASTH structs */
	int	c_rhnum;	/* number of RASTHs for this configuration */
} CONFIG;
extern CONFIG conf[];

/*
 * Triggers that are currently being displayed are stored here for dras()
 * to compare during search.  Index of trigger in array is also the index
 * of its RASTH entry.
 */
typedef struct {
	int	ts_trig;	/* trigger event code */
	int	ts_tcnt;	/* count field used by dras() to stop queueing
				   triggers when r_nlines are found */
	RASTH	*ts_rhp;	/* pointer to this trig's RASTH */
} TSEARCH;
extern TSEARCH tsearch[];

/*
 * Array of approximations for initial histogram scaling factors.
 */
extern int sfact[];

extern int	myptx;
extern int	confnum;	/* current screen config; indexes config[] */
extern int	t_confnum;	/* temp variable for menus */
extern int	htogether;	/* if flag true all hists are scaled
				   together when any one needs to be scaled */
extern int	loc_msg;	/* used to send msgs to myself */
extern int	rwakecd;	/* menu prototype of d_rwakecd */
extern long	tsrchtime;	/* time of last trigger processed */
extern int	dmag;		/* display magnification for window */

/*
 * Function prototypes.
 */
void go_wind(void);
void endact(void);
void dras(void);
void set_wind(void);
void dlabel(RASTH *rasthp, int argenab, int argflag);
void dtrig(RASTH *rasthp, int argenab, int argflag);
void dhist(RASTH *rasthp, int color);
void clhist(RASTH *rasthp, int tinit);
int cinit(void);
int rhinit(RASTH *rasthp);
void derase(int x, int xlen, int y, int ylen);
void dtics(RASTH *rasthp, int argenab, int argflag);
void fillras(TLIST *tlp);
void rscroll(int bot_ya, int top_ya, int dely, int xstart, int xend);
void oncntrlb(int sig);
void alert(int sig);
int conf_vaf(int flag, MENU *mp, char *astr, VLIST *vlp, int *tvadd);
int ras_vaf(int flag, MENU *mp, char *astr, VLIST *vlp, int *tvadd);
int ras_maf(int flag, MENU *mp, char *astr, VLIST *vlp, int *tvadd);
void rhnew(RASTH *rhp, int tinit);
int ras_agf(int call_cnt, MENU *mp, char *astr);
void begras(void);
void n_ras(char *vstr, char *astr);
void n_hist(char *vstr, char *astr);
void n_dsp(char *vstr, char *astr);
void set_axis(void);
void set_grid(int xcen, int ycen, int dots_t);
void mxhtic(int xcen, int ycen, int dots_t, int degs_t, int upflag);
void mxvtic(int xcen, int ycen, int dots_t, int degs_t, int rightflag);
void mxhtext(char *s, int ix, int iy);
void mxvtext(char *s, int ix, int iy);

