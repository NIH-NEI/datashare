/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government.  The original
 * versions, REX 1.0-3.12, were developed for the pdp11 architecture and
 * distributed without restrictions.  This version, REX 4.0, is a port of
 * the original version to the Intel 80x86 architecture.  This version is
 * distributed only under license agreement from the National Institutes 
 * of Health, Laboratory of Sensorimotor Research, Bldg 10 Rm 10C101, 
 * 9000 Rockville Pike, Bethesda, MD, 20892, (301) 496-9375.
 *-----------------------------------------------------------------------*
 */

/*
 *	Configuration header.  This header is local to each version
 * of REX.  Configuration options, conditional compiles, hardware
 * versions, etc. are specified here.
 */

/*
 *-----------------------------------------------------------------------*
 *	Device defines:  #define to include, #undef to exclude.
 *-----------------------------------------------------------------------*
 */
#undef  DT2821			/* Data Translation DT2821 */
#undef  NIATMIO			/* National Instruments ATMIO16 */
#undef  NIATMIOX		/* National Instruments ATMIO16X 16 bit */
#undef  AC5508HR		/* ADAC 5508Super HR 16 bit */
#undef  AC5525MF		/* ADAC 5525MF 12 bit a/d */
#undef  ANLSDAS16		/* Analogics LSDAS16 16 bit */
#define ANDAS12			/* Analogics ANDAS12 */
#undef  KMPIO12			/* Keithley-Metrabyte PIO-12 */
#define CIO_DA			/* Computer Boards DDA06, DAC08, or DAC16 */
#undef  DCC20			/* ICS DCC20A counter timer card */
#define PCDIO			/* ICS PCDIO-P digital i/o card */

/*
 *-----------------------------------------------------------------------*
 *	Software configuration includes.
 *-----------------------------------------------------------------------*
 */
#undef  HARD_ABORT		/* include code for hardware initiated abort;
				   the hardware equivalent of a cntrl B */
#define	CC_RAMP 		/* ramp generator code */
#define	CC_RAPHI 		/* phi code */
#define	CC_UNIT 		/* collect single units */
#undef  FAKE_UNITS		/* generate fake units for testing */
#define OEYE 			/* sample two eyes */
#define JOY			/* sample joystick instead of addh, addv */
#define CLRMIRRORS		/* set mirror d/as to 0,0 when process
				   is started, killed */
#undef  PCMESSAGE		/* PC to PC messaging */
				   
/*
 *-----------------------------------------------------------------------*
 *	Sampling configuration parameters;  note: other sampling related
 * defines are in buf.h
 *-----------------------------------------------------------------------*
 */
#define CLOCK_RATE	1	/* clock interrupt rate in msec */
#define	ST_RATE		1	/* processing rate of state set in msec */
#define W_PRE		100	/* default size of pre and post times in
				   msec */
#define W_POST		100

/*
 *-----------------------------------------------------------------------*
 * Device id assignments.  Each d/a or digital i/o device must have
 * a UNIQUE device id.  Range: 1-0xff.  These should not be changed.
 *-----------------------------------------------------------------------*
 */
#ifdef DT2821
    #define DT2821_DA	    0x1	    /* d/a */
    #define DT2821_DIO	    0x2	    /* digital i/o, not implemented */
#endif
#ifdef AC5508HR
    #define AC5508HR_DIO    0x3	    /* digital i/o, not implemented */
#endif
#ifdef AC5525MF
    #define AC5525MF_DIO    0x5	    /* digital i/o, not implemented */
#endif
#ifdef ANLSDAS16
    #define ANLSDAS16_DIO   0x7	    /* digital i/o, not implemented */
#endif
#ifdef NIAMTIO
    #define NIATMIO_DA	    0x9
    #define NIATMIO_DIO	    0xa	    /* digital i/o, not implemented */
#endif
#ifdef NITAMIOX
    #define NIATMIOX_DIO    0xb	    /* digital i/o, not implemented */
#endif
#ifdef ANDAS12
    #define ANDAS12_DA	    0xd
    #define ANDAS12_DIO	    0xe	    /* digital i/o, not implemented */
#endif
#ifdef CIO_DA
    #define CIO_DA_DA	    0x10
#endif
#ifdef KMPIO12
    #define KMPIO120_DIO    0x14
    #define KMPIO121_DIO    0x15
#endif
#ifdef PCDIO
    #define PCDIO_DIO	    0x20
#endif    

/*
 *-----------------------------------------------------------------------*
 * Default device specifications.  Make sure devices used below
 * have been #defined above.  For example, if one has a CIO_DA card
 * the DAX_ID can be defined to use CIO_DA_DA.  However, if one doesn't
 * have a CIO_DA card and wants to use the d/as on the DT2821, the
 * DAX_ID must be defined to use DT2821_DA.
 *-----------------------------------------------------------------------*
 */
/*
 * Device to pulse to reset unit latch.
 */
#define LATCH_RESET    Dio_id(PCDIO_DIO, 2, 0x1)

/*
 * Device definitions for d/as that drive scanner mirrors (used by
 * the Xmout, Ymout, and XYmout macros defined in device.h).
 */
#define DAX_ID	    Dio_id(CIO_DA_DA, 0, 0xfff)
#define DAY_ID	    Dio_id(CIO_DA_DA, 1, 0xfff)
#define DA0_ID	    Dio_id(CIO_DA_DA, 0, 0xfff)
#define DA1_ID	    Dio_id(CIO_DA_DA, 1, 0xfff)
#define DA2_ID	    Dio_id(CIO_DA_DA, 2, 0xfff)
#define DA3_ID	    Dio_id(CIO_DA_DA, 3, 0xfff)
#define DA4_ID	    Dio_id(CIO_DA_DA, 4, 0xfff)
#define DA5_ID	    Dio_id(CIO_DA_DA, 5, 0xfff)
#define DA6_ID	    Dio_id(CIO_DA_DA, 6, 0xfff)
#define DA7_ID	    Dio_id(CIO_DA_DA, 7, 0xfff)

/*
 * Default device for 'bit' noun.  This device is used for commands
 * 'set bit' and 'clr bit'.
 */
#define BIT_DEFAULT PCDIO_DIO

/*
 * REX reads 16 bits of digital input every interrupt (msec).  Following
 * defines are args for function 'dio_in()', used to pick up this input.
 * The result is stored in a variable named 'dina' (a #define
 * also allows this variable to be accessed as 'drinput' for backward
 * compatability).  Bits in this variable can then be tested for on/off
 * from Spot files, e.g. "to nextstate on +BAR & drinput".
 */
#define DIN_LOW	    Dio_id(PCDIO_DIO, 0, 0xff)	/* low 8 bits of digital in */
#define DIN_HI	    Dio_id(PCDIO_DIO, 1, 0xff)	/* hi 8 bits of digital in */

/*
 * Standard definitions for digital input bits.
 */
#define CBAR		0x1	/* chair's bar */
#define EXBAR		0x2	/* experimenter's bar */
#define PSTOP		0x4	/* stop paradigm */
#define RLSTOP		0x8	/* freeze displays */
#define GOBAR		0x10
#define ABORT		0x20	/* REX abort- hardware equivalent
				   a cntrl B */
#define SOL		0x40	/* free reward button */
#define UNIT1		0x4000	/* units channel 1 */
#define UNIT0		0x8000	/* units channel 0 */

/*
 *-----------------------------------------------------------------------*
 * Device addresses, dma channels, vectors.
 * Note:  a/d sampling rate options are configured in int/cnf.c.
 *-----------------------------------------------------------------------*
 */
/*
 * Data Translation DT2821: 12 bit a/d, 2 12 bit d/a, 16 bits dio.
 * ---------------------------------------------------------------------
 */
#ifdef DT2821
/*
 * DT2821 is operated in dual-dma mode.  Must use 16 bit channels
 * 6 and 7.  Dont change.
 */
#define AD_CHANNELS	8	    /* 8 DI channels */
#define AD_RES		12	    /* 12 bit */
#define AD_RCOMP	0	    /* radix compensation- constant to subtract
				       from sample to produce 2's complement */
#define AD_VECT		3	    /* vector */
#define AD_CGLIST	1	    /* defined if a/d has a channel-gain
				       list */
#undef	AD_SINGLEDMA		    /* defined if a/d supports only
				       single-dma */
#define AD_DUALDMA	1	    /* defined if a/d supports dual-dma */
#define DT0_DMACHAN1	6	    /* DMA channel */
#define DT0_DMACHAN2	7	    /* DMA channel */
#define DT0_ADCSR_RW	0x240	    /* I/O port base address */
#endif

/*
 * National Instruments AT-MIO-16: 12 bit a/d, 2 12 bit d/a, 8 bits dio.
 * ---------------------------------------------------------------------
 */
#ifdef NIATMIO
/*
 * ATMIO-16 is operated in dual dma mode, with interval scanning.
 * Channels must be 6 and 7.  Don't change.
 */
#define AD_CHANNELS	8	    /* 8 DI channels */
#define AD_RES		12	    /* 12 bit */
#define AD_RCOMP	0	    /* radix compensation- constant to subtract
				       from sample to produce 2's complement */
#define AD_VECT		3	    /* vector */
#define AD_CGLIST	1	    /* defined if a/d has a channel-gain
				       list */
#undef	AD_SINGLEDMA		    /* defined if a/d supports only
				       single-dma */
#define AD_DUALDMA	1	    /* defined if a/d supports dual-dma */
#define NI0_DMACHAN1	6	    /* DMA channel */
#define NI0_DMACHAN2	7	    /* DMA channel */
#define NI0_PORT	0x240	    /* base address */
#endif

/*
 * National Instruments AT-MIO-16X: 16 bit a/d, 2 12 bit d/a, 8 bits dio.
 * ---------------------------------------------------------------------
 */
#ifdef NIATMIOX
/*
 * ATMIO-16X is operated in dual dma mode, with interval scanning.
 * Channels must be 6 and 7.  Don't change.
 */
#define AD_RATE		1000	    /* default interrupt rate */
#define AD_CHANNELS	8	    /* 8 DI channels */
#define AD_RES		16	    /* 16 bit */
#define AD_RCOMP	0	    /* radix compensation- constant to subtract
				       from sample to produce 2's complement */
#define AD_VECT		5	    /* vector */
#define AD_CGLIST	1	    /* defined if a/d has a channel-gain
				       list */
#undef	AD_SINGLEDMA		    /* defined if a/d supports only
				       single-dma */
#define AD_DUALDMA	1	    /* defined if a/d supports dual-dma */
#define NI1_DMACHAN1	6	    /* DMA channel */
#define NI1_DMACHAN2	7	    /* DMA channel */
#define NI1_PORT	0x240	    /* base address */
#endif

/*
 * ADAC 5508 Super HR 16 Bit A/D.
 * ---------------------------------------------------------------------
 */
#ifdef AC5508HR
#define AD_CHANNELS	8	    /* 8 DI channels */
#define AD_RES		16	    /* 16 bit */
#define AD_RCOMP	0	    /* radix compensation- constant to subtract
				       from sample to produce 2's complement */
#define AD_VECT		3	    /* vector */
#undef	AD_CGLIST		    /* defined if a/d has a channel-gain
				       list */
#define	AD_SINGLEDMA	1	    /* defined if a/d supports only
				       single-dma */
#undef  AD_DUALDMA		    /* defined if a/d supports dual-dma */
#define AC0_DMACHAN	3
#define AC0_PORT	0x240	    /* base address */
#endif

/*
 * ADAC 5525MF 12 bit a/d.
 * ---------------------------------------------------------------------
 */
#ifdef AC5525MF
#define AD_CHANNELS	8	    /* 8 DI channels */
#define AD_RES		12	    /* 12 bit */
#define AD_RCOMP	0	    /* radix compensation- constant to subtract
				       from sample to produce 2's complement */
#define AD_VECT		3	    /* vector */
#undef	AD_CGLIST		    /* defined if a/d has a channel-gain
				       list */
#define	AD_SINGLEDMA	1	    /* defined if a/d supports only
				       single-dma */
#undef  AD_DUALDMA		    /* defined if a/d supports dual-dma */
#define AC1_DMACHAN	1
#define AC1_PORT	0x240	    /* base address */
#endif

/*
 * Analogic LSDAS16 16 bit a/d converter with 2 12 bit d/as, 16 bits
 * digital I/O.  16 bit card, single DMA.
 * ---------------------------------------------------------------------
 */
#ifdef ANLSDAS16
/*
 * Uses a single 16 bit DMA channel, one for a/d, another for d/a.
 */
#define AD_CHANNELS	8	    /* 8 DI channels */
#define AD_RES		16	    /* 16 bit */
#define AD_RCOMP	010000	    /* radix compensation- constant to subtract
				       from sample to produce 2's complement */
#define AD_VECT		3	    /* vector */
#undef	AD_SINGLEDMA		    /* defined if a/d supports only
				       single-dma */
#define AD_DUALDMA	1	    /* defined if a/d supports dual-dma */
#define AN0_ADDMACHAN	6	    /* DMA channel- a/d */
#define AN0_DADMACHAN	7	    /* DMA channel- d/a */
#define AN0_PORT	0x240	    /* base address */
#endif

/*
 * Analogic DAS-12 12 bit a/d with 2 12 bit d/a converters.
 * ---------------------------------------------------------------------
 */
#ifdef ANDAS12
/*
 * Uses a single 16 bit DMA channel.
 */
#define AD_RATE		1000	    /* default interrupt rate */
#define AD_CHANNELS	8	    /* 8 DI channels */
#define AD_RES		12	    /* 12 bit */
#define AD_RCOMP	04000	    /* radix compensation- constant to subtract
				       from sample to produce 2's complement */
#define AD_VECT		5	    /* vector */
#undef	AD_CGLIST		    /* defined if a/d has a channel-gain
				       list */
#define	AD_SINGLEDMA	1	    /* defined if a/d supports only
				       single-dma */
#undef  AD_DUALDMA		    /* defined if a/d supports dual-dma */
#define AN1_DMACHAN	6	    /* DMA channel- a/d */
#define AN1_PORT	0x240	    /* base address */
#endif

/*
 * Computer Boards DDA06, DAC08, or DAC16
 * ---------------------------------------------------------------------
 */
#ifdef CIO_DA
#define CIO_DA_PORT	0x180		/* base address */
#endif

/*
 * Industrial Computer Source PCDIO-P Buffered Digital I/O Card.
 * ---------------------------------------------------------------------
 */
#ifdef PCDIO
#define PCDIO0_PORT	0x280		/* base address */
#endif

/*
 * Keithley-Metrabyte PIO-12
 * ---------------------------------------------------------------------
 */
#ifdef KMPIO12
#define KMPIO120_PORT	0x270		/* base address */
#define KMPIO121_PORT	0x274		/* base address */
#endif
