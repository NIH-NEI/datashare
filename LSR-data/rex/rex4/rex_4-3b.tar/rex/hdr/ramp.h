/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government.  The original
 * versions, REX 1.0-3.12, were developed for the pdp11 architecture and
 * distributed without restrictions.  This version, REX 4.0, is a port of
 * the original version to the Intel 80x86 architecture.  This version is
 * distributed only under license agreement from the National Institutes 
 * of Health, Laboratory of Sensorimotor Research, Bldg 10 Rm 10C101, 
 * 9000 Rockville Pike, Bethesda, MD, 20892, (301) 496-9375.
 *-----------------------------------------------------------------------*
 */

/*
 *	Header for ramp generator.
 */

/*
 *	Parameter struct for ramp.  One needed for x and y.
 */
struct ra_p {
	int	ra_mode;	/* mode of algorithm; see defines */
	int	ra_err;		/* error term */
	int	ra_rem;		/* remainder term */
	int	ra_inc;		/* increment for remainder slope */
	unsign	ra_d;		/* distance to cover */
	unsign	ra_de;		/* epsilon distance added for start */
	unsign	ra_dtime;	/* time to cover it in */
	int	ra_quot;	/* quotient if slope > 1 */
	int	ra_pos;		/* current position: 2s comp, 40 steps/deg */
};
extern struct ra_p ra_x, ra_y;

extern int	ra_len;		/* parameters specifing ramp; length in tenths
				   of degree */
extern int	ra_ang;		/* angle (polar coordinates) in degrees */
extern int	ra_vel;		/* velocity in deg/sec */
extern int	ra_xoff;	/* xoffset, yoffset (cart coord) of either
				   begin, middle, or end point of ramp */
extern int	ra_yoff;
extern int	ra_type;	/* ramp type; see defines below */
extern unsign	ra_duration;	/* duration of ramp less 24ms startup time */
extern unsign	ra_timeleft;	/* time remaining on current ramp */
extern int	ra_state;	/* state of ramp generator */
extern int	ra_urate;	/* update rate for ramp */
extern int	rampflag;	/* state change processor checks this */
extern int	ra_wtime;	/* timer for start delays */
extern int	ra_xflag;	/* flag used in ramp output section */
extern int	ra_vfactor;	/* velocity compensation factor for ramp
				   initial position.  See comment in ramp.c */
extern int	ra_ecode;	/* store ramp event code */
extern DIO_ID	ra_device;	/* if non-zero, ramp generator turns off
				   this device at end of ramp */

/*
 * Menu prototypes for ramp parameters.
 */
extern int	m_ramenu;
extern int	m_ralen;
extern int 	m_ravel;
extern int	m_raang;
extern int	m_raxoff;
extern int	m_rayoff;
extern int	m_ecode;
extern int	m_type;

#ifdef CC_RAPHI
extern DIO_ID	ra_phidev;	/* phi device */
extern int	ra_phiflag;	/* if set, do phi blinking */
extern int	ra_pontime;	/* phi on time in ms */
extern int	ra_pofftime;	/* phi off time in ms */
#endif

/*
 * Defines for ra_mode.
 */
#define RA_NOMOVE	0	/* either a vert or horiz line */
#define RA_EQINT	1	/* slope == integer value */
#define RA_LESS1	2	/* slope of time vs. distance is < 1 */
#define RA_GREAT1	3	/* slope of time vs. dist is > 1 
				   and not an integer value */

/*
 * Defines for ra_state.
 */
#define RA_OFF		0
#define RA_DELST	1	/* start ramp with initial 40ms delay for mirs
				   to settle after moving to start position */
#define RA_DELWAIT	2	/* wait for 40msec to elapse */
#define RA_NODEL	3	/* start ramp with no 40msec delay */
#define RA_GO		4	/* begin ramp */
#define RA_25WAIT	5	/* wait for 25msec accel delay to elapse if
				   NO25MS is not set */
#define RA_RUN		6	/* output ramp */

/*
 * Defines for rampflags.
 */
#define RA_STARTED	01	/* ramp has started */
#define RA_CDONE	02	/* computation for ramp completed */
#define RA_ENDLIST	04	/* set when end of a vector array has been
				   reached */
#define RA_TIMEDONE	010	/* set by function ramptd when times set
				   by function pre2set have elapsed;  used
				   in timing duration of ramps */
#define RA_TIMESTART	0100000	/* used to synchronize state set that times
				   ramp durations when setting RA_TIMEDONE
				   flag;  see a ramp paradigm for info */

/*
 *	Defines for ramp type.  Must fit in a char.
 */
#define RA_NO25MS	01	/* dont prepend 25ms acceleration time to
				   ramp  */
#define RA_CENPT	02	/* ramp xoffset, yoffset is center of ramp */
#define RA_BEGINPT	04	/* x, yoffset is begining of ramp */
#define RA_ENDPT	010	/* x, yoffset is end of ramp */

/*
 *	Defines for ra_phiflag (phi tracking flag).
 */
#ifdef CC_RAPHI
#define RA_PHIGO	0100000		/* phi tracking on/off */
#endif


/*
 * Prototypes.
 */
void rcompute(void);
int ra_start(long flag, DIO_ID device);
int ra_compute(void);
int ra_stop(long flag);
int ra_tostart(void);
#ifdef CC_RAPHI
int phistart(void);
int phiend(void);
#endif
int ramptd(void);
int ramptset(long presetper, long randper);
int ra_new(int len, int ang, int vel, int xoff, int yoff, int ecode, int type);

