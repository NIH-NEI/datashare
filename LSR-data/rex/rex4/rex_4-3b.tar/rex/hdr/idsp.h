/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government.  The original
 * versions, REX 1.0-3.12, were developed for the pdp11 architecture and
 * distributed without restrictions.  This version, REX 4.0, is a port of
 * the original version to the Intel 80x86 architecture.  This version is
 * distributed only under license agreement from the National Institutes 
 * of Health, Laboratory of Sensorimotor Research, Bldg 10 Rm 10C101, 
 * 9000 Rockville Pike, Bethesda, MD, 20892, (301) 496-9375.
 *-----------------------------------------------------------------------*
 */

/*
 * idsp.h: Header for displays updated by int (running line and window).
 */

/*
 *-----------------------------------------------------------------------
 * Running line display.
 *-----------------------------------------------------------------------
 */

/*
 * Matrox image array used to remember points plotted to be later
 * erased when scrolled off screen.
 *
 * NOTICE!  Members of both 'matbuf' and 'rltab' are accessed by pointers to
 * int in a sequential fashion.  Ordering of memebers of these structs cannot
 * be changed, or new members added, without also changing code that references
 * them.  This was necessary to increase speed of display.
 */
extern struct matbuf {
	unsigned	chanA;
	unsigned	chanB;
	unsigned	chanC;
	unsigned	bar;
	unsigned	marks;
} matbuf[];

/*
 * Parameters for running line display.
 *
 * NOTICE!  Members of both 'matbuf' and 'rltab' are accessed by pointers to
 * int in a sequential fashion.  Ordering of memebers of these structs cannot
 * be changed, or new members added, without also changing code that references
 * them.  This was necessary to increase speed of display.
 */
extern struct rltab {
	int	A_scale;	/* shift right by this to scale */
	void	*A_addr;	/* pointer to data to be displayed */
	int	A_offset;	/* offset on display */
	int	B_scale;
	void	*B_addr;
	int	B_offset;
	int	C_scale;
	void	*C_addr;
	int	C_offset;
	int	bar_os;		/* remaining items have only offsets */
	int	spike_os;
} rltab;

extern int rlrate;		/* display rate */
extern int Ctraceon;		/* flag for control of Ctrace */
extern int astate, aspike;	/* value for bar, flag for spike */
extern int amarkA, amarkB;	/* flags for marks */
extern addtmp;			/* needed to get around sign extend */
extern int run_count;		/* counter for rate */
extern int aindex;		/* pointers into matrox screen buffer */
extern int bindex;
extern int eyeh, eyev;		/* eye values acquired from A/D */
extern int oeyeh, oeyev;	/* other eye */
extern int wdchange;		/* flag is true when cursor changes have
				   occured during window display updates */

/*
 * Display on/off bit flags.
 */
#define	CHANA		0100000
#define	CHANB		0040000
#define	CHANC		0020000
#define	BARL		0010000
#define SPIKES		0004000

/*
 * Following marks MUST be defined in
 * low order byte;  these defines are also used to test bits in
 * matbuf.marks.
 */
#define	MARKA		01
#define MARKB		02

extern int rline, rlinenew;	/* runnline line control */


/*
 *-----------------------------------------------------------------------
 * Window display.
 *-----------------------------------------------------------------------
 */

/*
 * Cursors displayed by INT are specified as a series of bipolar x, y offsets
 * from a center position; one x, y coord pair for each dot of the cursor.
 * Cursors should not be composed of a large number of dots since each dot
 * must be erased and re-drawn when the cursor moves.
 *
 * The algorithm to handle cursor overlap works as follows:  Each dot
 * that is set on the screen is 'owned' by one and only one cursor.  This
 * cursor has the responsibility to erase the dot when it moves away.
 * If another cursor moves on top of a dot that is already 'owned', the
 * WDI_NOT_OWNER bit is set in the cu_flag for that dot.  When a cursor
 * moves away it does not erase dots it does not 'own', since other cursor(s)
 * are also using that dot.  A problem arises, however, if the cursor that
 * owns a dot moves away before other cursors containing the same dot.  In
 * this case the dot is cleared when it shouldn't be.  To solve this problem,
 * the other cursors are searched for all dots that have no owners.  These
 * dots should be set.  If one of these dots is found that is not set on the
 * screen, it is set again and this cursor is made the new owner of
 * the orphan dot.
 *
 * NOTICE!  Members of both CURSOR and WINDISP are accessed by pointers
 * to int in a sequential fashion;  the ordering of members cannot be
 * changed without also changing code.  Though undesirable, this results in
 * an essential efficiency increase.
 */
typedef struct {
	int	cu_xoff;	/* xoffset of a dot from center of cursor */
	int	cu_yoff;
	int	cu_flag;	/* if negative terminates the coordinates of
				   this cursor */
} CURSOR;

/*
 * Defines for cu_flag.  Note:  these values cannot be changed, nor can
 * any other bits be added to this flag.  For efficiency reasons, these
 * values are tested with byte instructions instead of bit instructions.
 * (e.g., cu_flag is tested to see if the low byte is non-zero instead of
 * whether bit 0 is on).  See window display code in int.c for details.
 */
#define WDI_NOT_OWNER	01	/* cursor does not 'own' this dot */
#define WDI_OMARGINS	0400	/* dot out of margins */

/*
 * Each cursor is controlled by an instance of this struct.
 */
typedef struct {
	int	wd_xscale;	/* x scale factor for this cursor */
	int	wd_yscale;	/* y scale factor for this cursor */
	int	wd_newx;	/* new x position of cursor */
	int	wd_newy;
	int	wd_oldx;	/* previous x position of cursor */
	int	wd_oldy;
	int	wd_flag;	/* flags described below */
	CURSOR	*wd_cur;	/* pointer to cursor */
} WINDISP;
extern WINDISP windisp[];

/* 
 * Defines for wd_flag.
 */
#define WDI_NEWSIZ	01	/* cursor has changed size (e.g. the window
				   cursor) */
#define WDI_ON		02	/* cursor is on and being plotted for wind
				   display */
#define WDI_SWOFF	04	/* request to turn off cursor when next
				   plotted */
#define WDI_OLDINVALID	010	/* old cursor add is invalid; dont erase it
				   when plotting new cursor */
#define WDI_CHANGE	020	/* when set, cursor was changed during
				   window display update */
#define WDI_SWON	040	/* request to turn on cursor */

/*
 * Cursor indices.  Note:  do not change order of these indices.  Code
 * assumes the order and doesnt explicitly use these defines.
 */
#define CU_EYE		0
#define CU_CENTER	1	/* center of screen */
#define CU_WIND		2	/* window */
#define CU_MIR		3	/* current mirror position */
#define CU_OEYE		4	/* other eye */
#define CU_XOFF		5	/* x offset for eye */
#define CU_YOFF		6	/* y offset for eye */
#define CU_OXOFF	7	/* x offset for other eye */
#define CU_OYOFF	8	/* y offset for other eye */
#define CU_OWIND	9	/* window for other eye */
#define CU_JOY		10	/* joystick */

/*
 * Parameters.
 */
#define WDI_NCURS	11	/* number of cursors */
