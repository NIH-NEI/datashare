/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government.  The original
 * versions, REX 1.0-3.12, were developed for the pdp11 architecture and
 * distributed without restrictions.  This version, REX 4.0, is a port of
 * the original version to the Intel 80x86 architecture.  This version is
 * distributed only under license agreement from the National Institutes 
 * of Health, Laboratory of Sensorimotor Research, Bldg 10 Rm 10C101, 
 * 9000 Rockville Pike, Bethesda, MD, 20892, (301) 496-9375.
 *-----------------------------------------------------------------------*
 */

/*
 * Definitions for devices such as a/d, d/a, and digital I/O.
 */

/*
 * The 386 architecture accesses I/O registers via special instructions
 * (in and out).  One therefore cannot change individual bits by
 * or'ing in as on the pdp11 architecture.
 *
 * These macros are for read/write registers.  These are registers which
 * keep the state of bits that are written, and can be read back to determine
 * bits that have been set.
 
 * NOTE:  It is not safe to use the forms 'port++', etc.
 * for 'port'- it is evaluated twice.
 */
#define Wsetport_RW(port, bit_set, bit_clr) \
	(outpw(port, (inpw(port) & (~bit_clr)) | (bit_set)))
#define Bsetport_RW(port, bit_set, bit_clr) \
	(outp(port, (inp(port) & (~bit_clr)) | (bit_set)))

/*
 * These macros are for registers which are write-only.
 * These are registers that read back bits other than those that were
 * set on a write.
 *
 * In the register definitions for various devices, suffix '_RW' signifies
 * a read/write register which reads back any bits that are currently set.
 * Registers that are write only are designated '_WO', read only '_RO'.
 * A register that needs to have a software prototype is designated with
 * suffix '_P'.  It should only be accessed with the following macros.
 */
#define Wsetport_WO(port, save_val, bit_set, bit_clr) \
	save_val &= ~(bit_clr); save_val |= (bit_set); outpw(port, save_val)
#define Bsetport_WO(port, save_val, bit_set, bit_clr) \
	save_val &= ~(bit_clr); save_val |= (bit_set); outp(port, save_val)
#define bit_(number)	(0x1 << number)

/*
 * Prototypes for digital I/O functions.
 */
typedef unsigned long DIO_ID;
void dio_init(void);			/* initialize index list */
int dio_in(DIO_ID);			/* input from digital I/O port */
int dio_on(DIO_ID);			/* turn on bit */
int dio_off(DIO_ID);			/* turn off bit */  
int dio_onoff(DIO_ID, DIO_ID);		/* turn on/off bits */	
int dio_out(DIO_ID, long value);	/* output value to port */
#define D_ON	1			/* defines for 'flag' below */
#define D_OFF	2
#define D_VAL	3
int dio_set(DIO_ID, int value, int flag);   /* routine that is called to
					       do the ouptut */
#define D_BOTH	0x1			/* output value2 to next d/a
					   as well as value1 */
#define D_NOMAP	0x2			/* dont map from internal 40step/deg
					   calib standard to d/a (e.g. offset
					   bin, 2s comp, etc.) */
int dio_da(DIO_ID, int value1, int value2, int flag);	/* output to d/a */

/*
 * Macros for scanner mirrors.
 */
#define Xmout(value) \
    {\
	mrxcur= (int)value;\
	dio_da(DAX_ID, (int)value, 0, 0);\
    }
#define Ymout(value) \
    {\
	mrycur= (int)value;\
	dio_da(DAY_ID, (int)value, 0, 0);\
    }
#define XYmout(xval, yval) \
    {\
	mrxcur= (int)xval; mrycur= (int)yval;\
	dio_da(DAX_ID, (int)xval, (int)yval, D_BOTH);\
    }

/*
 *-----------------------------------------------------------------------*
 *			A/D CONVERTERS
 *-----------------------------------------------------------------------*
 */

/*
 * Data Translation DT2821: 12 bit a/d, 2 12 bit d/a, 16 bits dio.
 * ---------------------------------------------------------------
 */
#ifdef DT2821
/*
 * DT2821 is operated in dual-dma mode.  Must use 16 bit channels
 * 6 and 7.  Channels are equally spaced in time.
 * For example, 8 channels at 1KHz each results in a pacer clock
 * freq of 8KHz and 125usec between channel samples.  The DT2821
 * does not have an interval scanning mode.
 *
 * The DT2821's registers are read/write.  There is no need to keep
 * software prototypes of them.
 */
#define DT0_IA		bit_(6)	    /* a/d interrupt enable */
#define DT0_DONE	bit_(7)	    /* a/d done */
#define DT0_MUXBUSY	bit_(8)	    /* mux busy */
#define DT0_CLK		bit_(9)	    /* a/d clock enable */
#define DT0_ERR		bit_(15)    /* a/d error */

#define DT0_CHANCSR_RW	(DT0_ADCSR_RW+0x2)
#define DT0_LLE		bit_(15)    /* load list enable */

#define DT0_ADDATA_RO	(DT0_ADCSR_RW+0x4)

#define DT0_DACSR_RW	(DT0_ADCSR_RW+0x6)
#define DT0_LBOE	bit_(0)	    /* enable digital out low byte */
#define DT0_HBOE	bit_(1)	    /* enable digital out high byte */
#define DT0_DACLK	bit_(5)	    /* enable pacer clock to start conv. */
#define DT0_DACRDY	bit_(7)	    /* d/a ready */
#define DT0_SSEL	bit_(8)	    /* single channel select */
#define DT0_YSEL	bit_(9)	    /* y channel select */

#define DT0_DADATA_WO	(DT0_ADCSR_RW+0x8)

#define DT0_DIO_RW	(DT0_ADCSR_RW+0xa)

#define DT0_SCSR_RW	(DT0_ADCSR_RW+0xc)
#define DT0_BDINIT	bit_(0)	    /* board initialization */
#define DT0_STRIG	bit_(3)	    /* start pacer clock */
#define DT0_PRLD	bit_(4)	    /* preload mux */
#define DT0_DACINIT	bit_(5)	    /* initialize D/A */
#define DT0_INIT	bit_(6)	    /* initialize A/D */
#define DT0_DACON	bit_(7)	    /* DAC single conversion */
#define DT0_BUFFB	bit_(9)	    /* select DMA buf in dual mode */
#define DT0_CLKDMA	bit_(10)    /* a/d clocked DMA mode */
#define DT0_DUALDMA	bit_(12)    /* dual dma mode */
#define DT0_CLRDMADNE	bit_(13)    /* clears DMAD */
#define DT0_ERRINT	bit_(14)    /* interrupt on error */

#define DT0_TMRCTR_RW	(DT0_ADCSR_RW+0xe)
#endif

/*
 * National Instruments AT-MIO-16: 12 bit a/d, 2 12 bit d/a, 8 bits dio.
 * ---------------------------------------------------------------------
 */
#ifdef NIATMIO
#define NI0_COM1_WO_P	(NI0_PORT)	/* this register is COM1 on writes,
				           STATUS on reads */
extern u_int ni0_com1;		/* software prototype */
#define NI0_SCANEN	bit_(3)	/* enable multiple channel scanning */
#define NI0_DAQEN	bit_(4)	/* enable timer controlled acquisitions */
#define NI0_DMAEN	bit_(5)	/* enable dma */
#define NI0_DBDMA	bit_(6)	/* select dual channel dma */
#define NI0_TCINTEN	bit_(8)	/* select dma tc interrupt */

#define NI0_STAT_RO	(NI0_PORT)
#define NI0_OVERRUN	bit_(8)	/* new conversion before prev. picked up */
#define NI0_OVERFLOW	bit_(9)	/* a/d fifo overflow */

#define NI0_COM2_WO_P	(NI0_PORT+0x2)	/* write only */
extern u_int ni0_com2;		/* software prototype */
#define NI0_SCN2	bit_(4)	/* enable interval scanning mode */
#define NI0_INTEN	bit_(7)	/* overall interrupt enable */
#define NI0_DOUTEN0	bit_(8)	/* enable low 4 bits for digital out */
#define NI0_DOUTEN1	bit_(9)	/* enable high 4 bits for digital out */

#define NI0_MUXCNT_WO	(NI0_PORT+0x4)	/* write only */
#define NI0_MUXGAIN_WO	(NI0_PORT+0x6)	/* write only */
#define NI0_LASTONE	bit_(4)

#define NI0_STCONV_ST	(NI0_PORT+0x8)	/* write only- strobe */
#define NI0_STDAQ_ST	(NI0_PORT+0xa)	/* write only- strobe */
#define NI0_ADCLR_ST	(NI0_PORT+0xc)	/* write only- strobe */
#define NI0_EXSTROBE_ST	(NI0_PORT+0xe)	/* write only- strobe */
#define NI0_DAC0_WO	(NI0_PORT+0x10)	/* write only */
#define NI0_DAC1_WO	(NI0_PORT+0x12)	/* write only */
#define NI0_INT2CLR_WO	(NI0_PORT+0x14)	/* write only */
#define NI0_TCINT_WO	(NI0_PORT+0x16)	/* TC INT register on writes,
					   AD FIFO register on reads */
#define NI0_ADFIFO_RO	(NI0_PORT+0x16)
#define NI0_TDATA_RW	(NI0_PORT+0x18)	/* read and write */
#define NI0_TCOM_WO	(NI0_PORT+0x1a)	/* timer command on writes,
					   timer status on reads */
#define NI0_TSTAT_RO	(NI0_PORT+0x1a)
#define NI0_DO_WO	(NI0_PORT+0x1c)	/* digital out on writes,
					   digital in on reads */
#define NI0_DI_RO	(NI0_PORT+0x1c)
#define NI0_RTSISW_8WO	(NI0_PORT+0x1e)	/* 8 bit port- write only */
#define NI0_RTSIST_8WO	(NI0_PORT+0x1f)	/* 8 bit port- write only */

/*
 * A 1.5usec delay is required between accesses to the 9513 timer
 * registers.  Implement this with some dummy reads to the command
 * register.  Each read should take app. 700ns.
 */
#define NI0_delay \
        inpw(NI0_STAT_RO),inpw(NI0_STAT_RO),inpw(NI0_STAT_RO),\
	inpw(NI0_STAT_RO)
	
#endif 

/*
 * National Instruments AT-MIO-16X: 16 bit a/d, 2 12 bit d/a, 8 bits dio.
 * ---------------------------------------------------------------------
 */
#ifdef NIATMIOX
#define NI1_COM1_WO_P	(NI1_PORT)
extern u_int ni1_com1;			/* software prototype */
#define NI1_CNT32	bit_(5)	/* sample count, 32 or 16 bits */
#define NI1_SCN2	bit_(6)	/* interval scanning mode */
#define NI1_SCANEN	bit_(7)	/* scan enable */
#define NI1_DAQEN	bit_(8)	/* enable timer controlled acquisitions */

#define NI1_COM2_WO_P	(NI1_PORT+0x2)	/* write only */
extern u_int ni1_com2;		/* software prototype */

#define NI1_COM3_WO_P	(NI1_PORT+0x4)	/* write only */
extern u_int ni1_com3;		/* software prototype */
#define NI1_DRVAIS	bit_(3)	/* drive analog input sense */
#define NI1_ADCREQ	bit_(6)	/* ADC request enable */
#define NI1_DMACHB	bit_(7)	/* dma channel B enable */
#define NI1_DMACHA	bit_(8)	/* dma channel A enable */
#define NI1_IO_INT	bit_(9)	/* input/Output interrupt enable */
#define NI1_DMATCINT	bit_(12)/* DMA T/C interrupt enable */
#define NI1_DIOPAEN	bit_(13)/* dio port A set to output */
#define NI1_DIOPBEN	bit_(14)/* dio port B set to output */

#define NI1_COM4_WO_P	(NI1_PORT+0x6)	/* write only */
extern u_int ni1_com4;		/* software prototype */
#define NI1_EXTTRIG_DIS	bit_(0)	/* disable external triggers */
#define NI1_ADCFIFOREQ	bit_(4)

#define NI1_STAT1_RO	(NI1_PORT+0x18)	/* read only */
#define NI1_OVERRUN	bit_(8)	/* data overrun */
#define NI1_OVERFLOW	bit_(9)	/* FIFO overflow */
#define NI1_DMATCB	bit_(10)/* dma T/C channel B */
#define NI1_DMATCA	bit_(11)/* dma T/C channel A */
#define NI1_DAQCOMP	bit_(15)/* data acquisition copmlete */

#define NI1_STAT2_RO	(NI1_PORT+0x1a)	/* read only */
#define NI1_ADC_BUSY	bit_(0)

#define NI1_ADCFIFO_RO	(NI1_PORT+0x0)	/* read only */

#define NI1_CFGMEM_WO	(NI1_PORT+0x8)	/* write only */
#define NI1_CHAN_LAST	bit_(2)	/* set for last chan of config mem */
#define NI1_CHAN_BIP	bit_(12)/* bipolar */

#define NI1_DAC0_WO	(NI1_PORT+0x10)	/* write only */
#define NI1_DAC1_WO	(NI1_PORT+0x12)	/* write only */

#define NI1_CMEMCLR_ROST_8  (NI1_PORT+0x1b) /* read-only strobe, 8 bits */
#define NI1_CMEMLD_WOST_8   (NI1_PORT+0x1b) /* write-only strobe, 8 bits */
#define NI1_DAQCLR_ROST_8   (NI1_PORT+0x19) /* read-only strobe, 8 bits */
#define NI1_DAQST_ROST_8    (NI1_PORT+0x1d) /* read-only strobe, 8 bits */
#define NI1_SINGLE_WOST_8   (NI1_PORT+0x1d) /* write-only strobe, 8 bits */
#define NI1_ADCCAL_WOST_8   (NI1_PORT+0x1f) /* write-only strobe, 8 bits */
#define NI1_TMRCLR_ROST_8   (NI1_PORT+0x1f) /* read-only strobe, 8 bits */
#define NI1_DACUPD_WOST_8   (NI1_PORT+0x18) /* write-only strobe, 8 bits */
#define NI1_DACCLR_ROST_8   (NI1_PORT+0x1e) /* read-only strobe, 8 bits */
#define NI1_DMACCLR_ROST_8  (NI1_PORT+0x0b) /* read-only strobe, 8 bits */
#define NI1_DMATCACL_WOST_8 (NI1_PORT+0x19) /* write-only strobe, 8 bits */
#define NI1_DMATCBCL_ROST_8 (NI1_PORT+0x09) /* read-only strobe, 8 bits */
#define NI1_EXTSTB_WOST_8   (NI1_PORT+0x1e) /* write-only strobe, 8 bits */
#define NI1_DAC0CAL_WOST_8  (NI1_PORT+0x0a) /* write-only strobe, 8 bits */
#define NI1_DAC1CAL_WOST_8  (NI1_PORT+0x1a) /* write-only strobe, 8 bits */

#define NI1_TDATA_RW    (NI1_PORT+0x14) /* read and write */
#define NI1_TCOM_WO	(NI1_PORT+0x16)	/* timer command on writes */
#define NI1_TSTAT_RO	(NI1_PORT+0x16)

#define NI1_DI_RO	(NI1_PORT+0x1c)	/* digital input */
#define NI1_DO_WO	(NI1_PORT+0x1c)	/* digital out */

#define NI1_RTSISW_WO_8		(NI1_PORT+0x0c)	/* 8 bit port- write only */
#define NI1_RTSIST_WOST_8	(NI1_PORT+0x0e)	/* 8 bit port- write only */
#endif 

/*
 * ADAC 5508 Super HR 16 Bit A/D.
 * Operated in single channel DMA mode.  This is an 8 bit card.
 * Output of counter/timer 1 (OUT1) must be connected to external trigger
 * (EXTRIG) to trigger scans.  Jumper W1 must be installed.
 * Counter/timer 1 then becomes the scan interval timer.
 * ---------------------------------------------------------------------
 */
#ifdef AC5508HR
#define AC0_PORT	0x240		/* base address */
#define AC0_DIO_RW	(AC0_PORT+0x0)	/* digital I/O */

#define AC0_ADCSR0_RW	(AC0_PORT+0x8)	/* status register 0 */
#define AC0_TREN	bit_(1)		/* hardware trigger enable */
#define AC0_SEQ		bit_(2)		/* sequential mode enable */
#define AC0_BP_UN	bit_(3)		/* if 1, bipolar 2's complement */
#define AC0_SOFTCAL	bit_(4)		/* initiate a/d calibration */
#define AC0_ERIE	bit_(5)		/* error interrupt enable */
#define AC0_ADIE	bit_(6)		/* a/d interrupt enable */
#define AC0_DONE	bit_(7)		/* a/d conversion done */

#define AC0_ADCSR1_RW	(AC0_PORT+0x9)	/* status register 1 */
#define AC0_CLOERR	bit_(4)		/* a/d clock overrun error */
#define AC0_DMAEN	bit_(5)		/* dma transfer enable */
#define AC0_DMAIP	bit_(6)		/* dma interrupt pending */
#define AC0_DERR	bit_(7)		/* read only- data error */
#define AC0_CLRERR	bit_(7)		/* write only- clear errors */

#define AC0_ADDATAL_RO	(AC0_PORT+0xa)	/* a/d data low byte */
#define AC0_ADDATAH_RO	(AC0_PORT+0xb)	/* a/d data low byte */
#define AC0_CNTR0_RW	(AC0_PORT+0xc)	/* counter 0 port */
#define AC0_CNTR1_RW	(AC0_PORT+0xd)	/* counter 1 port */
#define AC0_CNTR2_RW	(AC0_PORT+0xe)	/* counter 2 port */
#define AC0_TCTRL_WO	(AC0_PORT+0xf)	/* counter control port */

/*
 * Short delay.
 */
#define AC0_delay \
        inp(AC0_ADCSR0_RW),inp(AC0_ADCSR0_RW),inp(AC0_ADCSR0_RW),\
	inp(AC0_ADCSR0_RW)
#endif

/*
 * ADAC 5525MF 12 bit a/d.
 * Operated in single channel DMA mode.  This is an 8 bit card.
 * Output of counter/timer 2 (OUT2) must be connected to gate input
 * of counter/timer 1 (GATE1).  Timer 2 becomes scan interval timer,
 * counter 1 is used as a one shot to gate counter 0 which triggers
 * conversions.
 *
 * Jumper config: W1, W2: out; W3-W10: address 0x240; W11-W16: interrupt
 * level 3; W17-W22: DMA channel 1; JP1: A, JP2: A, JP3: A, JP4: B;
 * JP5: B, JP6,7,18,19: differential, JP20,21,22: A.  Others as
 * desired or default.
 * ---------------------------------------------------------------------
 */
#ifdef AC5525MF
#define AC1_STATUS0_RO	(AC1_PORT+0x0)	/* status register 0 */
#define AC1_DMAIP	bit_(7)		/* dma interrupt pending */

#define AC1_CONFIG1_RW	(AC1_PORT+0x1)	/* coniguration register 1 */
#define AC1_DMAEN	bit_(0)		/* dma transfer enable */
#define AC1_LCEN	bit_(1)		/* last channel reset enable */
#define AC1_DDC0	bit_(4)		/* dio direction control port 0 */
#define AC1_DDC1	bit_(5)		/* dio direction control port 1 */
#define AC1_DDC2	bit_(6)		/* dio direction control port 2 */
#define AC1_DDC3	bit_(7)		/* dio direction control port 3 */

#define AC1_IAK_ST	(AC1_PORT+0x7)	/* clear pending interrupts */
#define AC1_DIO0_RW	(AC1_PORT+0x8)	/* dio ports 0 and 1 */
#define AC1_DIO1_RW	(AC1_PORT+0x9)	/* dio ports 2 and 3 */
#define AC1_DAC0L_WO	(AC1_PORT+0xc)	/* low byte of dac0 */
#define AC1_DAC0H_WO	(AC1_PORT+0xd)	/* high byte, write this first */
#define AC1_DAC1L_WO	(AC1_PORT+0xe)	/* low byte of dac1 */
#define AC1_DAC1H_WO	(AC1_PORT+0xf)	/* high byte, write this first */

#define AC1_ADCSR0_RW	(AC1_PORT+0x10)	/* a/d status register 0 */
#define AC1_TREN	bit_(1)		/* hardware trigger enable */
#define AC1_SEQ		bit_(2)		/* sequential mode enable */
#define AC1_ADINTEN	bit_(6)		/* a/d interrupt enable */
#define AC1_DONE	bit_(7)		/* a/d conversion done */

#define AC1_ADCSR1_RW	(AC1_PORT+0x11)	/* a/d status register 1 */
#define AC1_ADOERR	bit_(7)		/* a/d overrun error */

#define AC1_LASTCHAN_WO	(AC1_PORT+0x12)	/* last channel register */
#define AC1_ADDATAL_RO	(AC1_PORT+0x12)	/* a/d data low byte */
#define AC1_ADDATAH_RO	(AC1_PORT+0x13)	/* a/d data high byte */
#define AC1_CNTR0_RW	(AC1_PORT+0x14)	/* counter 0 port */
#define AC1_CNTR1_RW	(AC1_PORT+0x15)	/* counter 1 port */
#define AC1_CNTR2_RW	(AC1_PORT+0x16)	/* counter 2 port */
#define AC1_TCTRL_RW	(AC1_PORT+0x17)	/* counter control port */

/*
 * Short delay.
 */
#define AC1_delay \
        inp(AC1_ADCSR0_RW),inp(AC1_ADCSR0_RW),inp(AC1_ADCSR0_RW),\
	inp(AC1_ADCSR0_RW)

#endif

/*
 * Analogic LSDAS16 16 bit a/d converter with 2 12 bit d/as, 16 bits
 * digital I/O.  16 bit card, single DMA.
 * ---------------------------------------------------------------------
 */
#ifdef ANLSDAS16
#define AN0_ADDATA_RO	(AN0_PORT+0x0)	/* a/d data */
#define AN0_DAC0DATA_WO	(AN0_PORT+0x0)	/* d/a data */
#define AN0_DAC1DATA_WO	(AN0_PORT+0x2)	/* d/a data */

#define AN0_DAMODE_WO	(AN0_PORT+0x4)	/* d/a mode register */
#define AN0_DACENABLE	bit_(5)		/* if 0, dac is enabled */

#define AN0_ADMODE_WO	(AN0_PORT+0x6)	/* a/d mode register */
#define AN0_SOFTPACE	bit_(6)		/* software pacing */
#define AN0_TRIGSEL	bit_(9)		/* trigger select */
#define AN0_EXTRIGEN	bit_(12)	/* external trigger enable */
#define AN0_STRIGEN	bit_(13)	/* software trigger enable */

#define AN0_EXTEND_WO	(AN0_PORT+0x8)	/* extended register */

#define AN0_CTRL_WO_P	(AN0_PORT+0xa)	/* control register */
extern u_int an0_ctrl;			/* software prototype */
#define AN0_RANGE0	0x0		/* addresses for extended registers */
#define AN0_RANGE1	0x1
#define AN0_RANGE2	0x2
#define AN0_RANGE3	0x3
#define AN0_STORAGE0	0x4
#define AN0_STORAGE1	0x5
#define AN0_STORAGE2	0x6
#define AN0_STORAGE3	0x7

#define AN0_ADCTRL	0x8		/* a/d control register */
#define AN0_BIPOLAR	bit_(4)		/* bipolar, convert 0 */
#define AN0_ADINPUT	bit_(8)		/* single ended or diff */
#define AN0_ADENABLE	bit_(9)		/* a/d enable */
#define AN0_ADRUN	bit_(11)	/* a/d calibrate/run */

#define AN0_T0CNTR0	0x10		/* timer 0, counter 0 */
#define AN0_TCTRL0	0x13		/* timer 0 control register */
#define AN0_ADRESET	bit_(7)		/* a/d reset */
#define AN0_MRESET	bit_(8)		/* master reset */
#define AN0_DIOLSBDIR	bit_(10)	/* dio direction, LSB */
#define AN0_DIOMSBDIR	bit_(11)	/* dio direction, MSB */
#define AN0_DMAREQENA	bit_(14)	/* dma request enable */
#define AN0_DMASTART	bit_(15)	/* a/d dma start */

#define AN0_ICTRL_WO_P	(AN0_PORT+0xc)	/* interrupt control register */
extern u_int an0_ictrl;			/* software prototype */
#define AN0_CALIBSEL	bit_(4)		/* calibration select */
#define AN0_ADDAIM	bit_(8)		/* a/d data available int mask */
#define AN0_ADTCIEN	bit_(9)		/* a/d terminal count int enable */
#define AN0_ADTCIM	bit_(10)	/* a/d terminal count int mask */
#define AN0_ADTRIGEN	bit_(11)	/* a/d trigger int enable */
#define AN0_ADTRIGIM	bit_(12)	/* a/d trigger interrupt mask */
#define AN0_FIRENA	bit_(13)	/* enable FIFO overflow int req */
#define AN0_BIRENA	bit_(14)	/* board interrupt request enable */
#define AN0_BIMASK	bit_(15)	/* board interrupt mask */

#define AN0_STATUS_RO	(AN0_PORT+0xc)	/* status register */
#define AN0_ADTCIST	bit_(9)		/* a/d terminal count status */
#define AN0_OVERFLOW	bit_(13)	/* fifo overflow */

#define AN0_EXTDATA_RW	(AN0_PORT+0xe)	/* external write register */

/*
 * Short delay.
 */
#define AN0_delay \
        inpw(AN0_STATUS_RO),inpw(AN0_STATUS_RO),inpw(AN0_STATUS_RO),\
	inpw(AN0_STATUS_RO)
#endif

/*
 * Analogic DAS-12 12 bit a/d with 2 12 bit d/a converters.
 * ---------------------------------------------------------------------
 */
#ifdef ANDAS12
#define AN1_BDCTRL_RW	(AN1_PORT+0x0)	/* board control */
#define AN1_SRESET	bit_(0)		/* software reset */
#define AN1_CLADERR	bit_(1)		/* clear a/d error */
#define AN1_CLTCDONE	bit_(2)		/* clear tc done */
#define AN1_MINTENA	bit_(4)		/* master interrupt enable */
#define AN1_ADDMAENA	bit_(5)		/* a/d dma enable */
#define AN1_GO		bit_(15)	/* go bit */

#define AN1_INCHCTRL_RW	(AN1_PORT+0x2)	/* input channel control reg */

#define AN1_ADCTRL_RW	(AN1_PORT+0x4)	/* a/d control register */
#define AN1_ERRINTENA	bit_(10)
#define AN1_TCINTENA	bit_(11)	/* tc interrupt enable */
#define AN1_DIO0	bit_(12)	/* dio0 direction */
#define AN1_DIO1	bit_(13)	/* dio1 direction */
#define AN1_BURST	0xc000		/* burst mode bits */

#define AN1_ADDATA_RO	(AN1_PORT+0x6)	/* a/d data */
#define AN1_DAC0_WO	(AN1_PORT+0x8)	/* dac0 output data */
#define AN1_DAC1_WO	(AN1_PORT+0xa)	/* dac1 output data */
#define AN1_DIO_RW	(AN1_PORT+0xc)	/* dio port */

#define AN1_STATUS_RO	(AN1_PORT+0xe)	/* board status register */
#define AN1_TCDONE	bit_(5)		/* tc reached */
#define AN1_ADERR	bit_(4)		/* a/d error */

#define AN1_CNTR0_RW	(AN1_PORT+0x10)	/* counter 0 port */
#define AN1_CNTR1_RW	(AN1_PORT+0x12)	/* counter 1 port */
#define AN1_CNTR2_RW	(AN1_PORT+0x14)	/* counter 2 port */
#define AN1_TCTRL_RW	(AN1_PORT+0x16)	/* counter control port */

/*
 * Short delay.
 */
#define AN1_delay \
        inpw(AN1_STATUS_RO),inpw(AN1_STATUS_RO),inpw(AN1_STATUS_RO),\
	inpw(AN1_STATUS_RO)
#endif

/*
 *-----------------------------------------------------------------------*
 *			DIGITAL I/O
 *-----------------------------------------------------------------------*
 */

/*
 * Output to digitial I/O devices is handled by routines that use
 * a 'DIO_ID' as an argument.  'DIO_ID' is a 32 bit long with
 * following description:
 *
 *       31		    HIGH WORD                 16
 *	 ___________-___________-___________-___________
 *	|__|__|__|__|__|__|__|__|__|__|__|__|__|__|__|__|
 *		  Device       	|    Port or d/a num
 *
 *       15		     LOW WORD                  0
 *	 ___________-___________-___________-___________
 *	|__|__|__|__|__|__|__|__|__|__|__|__|__|__|__|__|
 *			bit pattern or mask
 *
 * This programming interface yields 8 bits for 'device', which is
 * typically a card in the PC, and 8 bits to select the 'port' for cards
 * that implement multiple ports.  For the functions 'dio_on', 'dio_off',
 * and 'dio_onoff', the low 16 bits hold a bit pattern
 * which is output to the specified port.  For the functions 'dio_in' and
 * 'dio_out', the lower 16 bits are a bit mask.  For 'dio_in', this mask
 * is bitwise-anded with the input before being returned.  For 'dio_out',
 * this mask is bitwise-anded with the value before being output.
 *
 * At the beginning of a Spot file, one typically includes a header that
 * defines the 'DIO_ID' of devices in the laboratory by using the
 * following macro:
 *
 *	Dio_id(device, port, bit_pattern)
 *
 * As an example, suppose an LED is connected in one laboratory to
 * the digital I/O port on a Data Translation DT2821 a/d converter
 * as bit 6.  This LED would be defined as:
 *
 *  #define LED_FP0	Dio_id(DT2821_DIO, 0, 0x40)
 * 
 * In another laboratory, this LED might be connected to bit 2 on port B
 * on Metrabyte PIO-12 card number 0.  It would then be defined as:
 *
 *  #define LED_FP0	Dio_id(KMPIO120_DIO, 1, 0x4)
 *
 * These definitions could be used in a Spot file with the following
 * three actions:
 *
 *	    dio_on(LED_FP0)		* turn on LED_FP0) *
 *	    dio_off(LED_FP0)		* turn off LED_FP0 *
 *	    dio_onoff(LED_FP0, LED_FP1)	* turns FP0 on, FP1 off *
 *
 * The above functions keep a software copy of the state of the port.
 * Turning on or off a bit does not affect the state of other bits in
 * the port.
 *
 * In addition, an bit pattern can be sent directly to a port by
 * using the following action:
 *
 *	    dio_out(DIO_ID, output_data)	* output 'value' *
 * 
 * The above function does not keep a software copy of the state of the
 * port.  The 'output_data' is written as is directly to the port.
 * The functions 'dio_on', dio_off', and 'dio_onoff' all call this
 * function to do the actual output.
 *
 * The following example is for 2 12 bit d/a converters.
 *
 *  #define DA_X	Dio_id(DIO_DT2821_DA, 0, 0xfff)
 *  #define DA_Y	Dio_id(DIO_DT2821_DA, 1, 0xfff)
 *
 *	    dio_da(DA_X, output_data, 0, 0);
 * 
 * The 'dio_da' function is described earlier in this file, along with
 * macros 'Xmout', 'Ymout', and 'XYmout'.  These macros are useful
 * for sending output to the d/as that drive the scanner motors.
 *
 * This programming interface allows the body of Spot files to remain
 * unchanged when used in different laboratories.  Only the definitions
 * for the device ids needs to be changed in the headers.
 *
 * Digital input is not currently handled with such a lab-independent
 * programming interface.  Every msec, the interrupt routine reads 16 bits of
 * digital input and stores the result in variable 'dina' (a #define
 * also allows this variable to be accessed as 'drinput' for backward
 * compatability).  Bits in this variable can then be tested for on/off
 * from Spot files, e.g. "to nextstate on +BAR & drinput".
 */
#define DIO_DEV_DEVMAX		256		/* max number of devices */
#define DIO_PORT_PORTMAX	256		/* max number of ports */
#define DIO_DEV_MASK	(0xff000000)    /* device id mask and shift factor */
#define DIO_DEV_SHIFT	24
#define DIO_PORT_MASK	(0xff0000)	/* port id mask and shift factor */
#define DIO_PORT_SHIFT	16
#define DIO_DATA_MASK	(0xffff)
#define DIO_DATA_SHIFT	0

/*
 * Macros.
 */
#define Dio_mk_dev(x)	((((long)x) << DIO_DEV_SHIFT) & DIO_DEV_MASK)
#define Dio_mk_port(x)	((((long)x) << DIO_PORT_SHIFT) & DIO_PORT_MASK)
#define Dio_id(dev, port, bit_pat) \
		((Dio_mk_dev(dev)) | (Dio_mk_port(port)) | (bit_pat))
#define Dio_dev(id)	((int)((id & DIO_DEV_MASK) >> DIO_DEV_SHIFT))
#define Dio_port(id)	((int)((id & DIO_PORT_MASK) >> DIO_PORT_SHIFT))
#define Dio_data(id)	((int)((id & DIO_DATA_MASK) >> DIO_DATA_SHIFT))

/*
 * The following array of unsigned chars gives specific info about
 * each port.
 *		     ______________-________
 *		    |__|__|__|__|__|__|__|__|
 *			  Flags      Type     	
 *
 * First three bits encoded as type of port.
 */
#define Dio_type(x)	((x) & 0x7)
#define D_NUL		0	/* port unused */
#define D_IN		1	/* input */
#define D_OUT		2	/* output */
#define D_CTRL		3	/* control port */
#define D_DA		4	/* d/a port */

/*
 * Remaining five bits are flags.
 */
#define D_WORD		0x8	/* access port via word access */
#define D_REV		0x10	/* port sense is true for off or no input */
#define D_NOCLR		0x20	/* if an output port, dont set to off
				   state when device is initialized or
				   during a 'reset bit' command
				   (default case is to set to off) */

/*
 * Flags for 'dio_flags'.  These flags apply to device as a whole, i.e.
 * all the ports.
 */
#define D_INIT		0x1	/* set when device has been inited */
typedef struct {
    int	    dio_devid;	    /* device id for this device; array terminates
			       when this field is zero */
    int	    dio_flags;	    /* flags, see above */
    int	    dio_port_base;  /* port base address; 0 if a d/a */
    u_char  dio_pinit[DIO_PORT_PORTMAX];  /* for cards whose ports need to
					     be configured for input or
					     output */
    u_int   dio_state[DIO_PORT_PORTMAX];  /* software copy of current state
					     of port */
    void    (*dio_init)();  /* function to call for initialization */
    void    (*dio_uninit)();/* function to call for uninitialization */
} DIO_DEV;
extern DIO_DEV dio_dev[];

/*
 * An a/d converter may support different max sampling rates depending
 * on how many channels are sampled.  This array specifies various
 * workable configurations for an individual converter.  For each possible
 * maximum sampling rate, a max number of channels that can be acquired
 * is specified.
 *
 * Note: REX currently supports only one a/d at a time.  To support
 * multiple a/ds, this array should be expanded to include all the
 * configuration info now stored in hdr/cnf.h.
 */
typedef struct {
    int	    ad_samp_max;    /* max sampling rate */
    int	    ad_samp_num;    /* number of channels at above max sampling rate */
} AD_SAMP;
extern AD_SAMP ad_samp[];

/*
 * Gain lists.  Some a/d converters have channel-gain lists,
 * which allow a different gain for each channel.
 * Different a/d's have provide different gains, e.g.
 * the ANDAS12 has gains of 1, 2, 4, 8 and the ATMIO16-X has gains
 * of 1, 2, 5, 10, 20, etc.
 */
typedef struct {
    int	ad_gain_factor;	/* gain, -1 terminates array */
    int ad_gain_bits;	/* bits to load into register for this gain */
} AD_GAIN;
extern AD_GAIN ad_gain[];

/*
 * This array contains ad_gain_bits indexed by channel for converters
 * with channel-gain lists.  For converters with one global gain,
 * only first element is used.
 */
extern int ad_cglist[AD_CHANNELS];

/*
 * A/D calibration struct.  Specifies shift factors used to scale
 * a/d inputs for various full scale calibrations.
 */
typedef struct {
    int	ad_ca_num;	/* calibration number; -1 terminates array */
    int ad_ca_shift;	/* shift factor */
    char ad_ca_fullscale[P_LNAME];    /* full scale range */
} AD_CALIB;
extern AD_CALIB ad_calib[SA_MAXCAL];

/*
 * Array holds all valid sampling rates.  Initialized by
 * sig_compute_ad_rates().
 */
typedef struct {
    int	ad_acq_rate;	    /* possible sampling rate */
    int ad_acq_bin_const;   /* constant used in sig_init() to compute sa_frame
			       array */
} AD_ACQ_RATES;
extern AD_ACQ_RATES ad_acq_rates[SA_SPREAD_LOG2+1];
