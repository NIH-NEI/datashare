/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government.  The original
 * versions, REX 1.0-3.12, were developed for the pdp11 architecture and
 * distributed without restrictions.  This version, REX 4.0, is a port of
 * the original version to the Intel 80x86 architecture.  This version is
 * distributed only under license agreement from the National Institutes 
 * of Health, Laboratory of Sensorimotor Research, Bldg 10 Rm 10C101, 
 * 9000 Rockville Pike, Bethesda, MD, 20892, (301) 496-9375.
 *-----------------------------------------------------------------------*
 */

/*
 *	lab.h:  Laboratory configuration defines- digial inputs/outputs.
 * This file is specific per laboratory, although many defines are
 * standard and should not be changed to maintain compatability.
 *
 * NOTE:  this header must be included after "hdr/device.h" to pick
 * up needed macro definitions.
 */

/*
 *-----------------------------------------------------------------------*
 *			Standard Defines
 *-----------------------------------------------------------------------*
 */

/*
 * Digital Input.
 */

/*
 * REX reads 16 bits of digital input every interrupt (msec).  Following
 * defines are args for function 'dio_in()', used to pick up this input.
 * The result is stored in a variable named 'dina' (a #define
 * also allows this variable to be accessed as 'drinput' for backward
 * compatability).  Bits in this variable can then be tested for on/off
 * from Spot files, e.g. "to nextstate on +BAR & drinput".
 */
#define DIN_LOW	    Dio_id(PCDIO_DIO, 0, 0xff)	/* low 8 bits of digital in */
#define DIN_HI	    Dio_id(PCDIO_DIO, 1, 0xff)	/* hi 8 bits of digital in */

/*
 * Definitions for digital input bits.
 */
#define CBAR		0x1	/* chair's bar */
#define EXBAR		0x2	/* experimenter's bar */
#define PSTOP		0x4	/* stop paradigm */
#define RLSTOP		0x8	/* freeze displays */
#define GOBAR		0x10
#define ABORT		0x20	/* REX abort- hardware equivalent
				   a cntrl B */
#define SOL		0x40	/* free reward button */
#define TVWAIT		0x80	/* TVdot display */
#define TVTRL		0xf00	/* TVtrial num code */
#define ACCWAIT		0x1000	/* TVdot accerrelation */
#define UNIT1		0x4000	/* units channel 1 */
#define UNIT0		0x8000	/* units channel 0 */

/*
 * Device to pulse to reset unit latch.
 */
#define LATCH_RESET    Dio_id(PCDIO_DIO, 2, 0x1)

/*
 * Device definitions for d/as that drive scanner mirrors (used by
 * the Xmout, Ymout, and XYmout macros defined in device.h).
 */
#define DAX_ID	    Dio_id(CIO_DA_DA, 0, 0xfff)
#define DAY_ID	    Dio_id(CIO_DA_DA, 1, 0xfff)

/*
 * Default device for 'bit' noun.  This device is used for commands
 * 'set bit' and 'clr bit'.
 */
#define BIT_DEFAULT PCDIO_DIO
