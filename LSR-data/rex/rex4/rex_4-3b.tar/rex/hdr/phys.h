/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government.  The original
 * versions, REX 1.0-3.12, were developed for the pdp11 architecture and
 * distributed without restrictions.  This version, REX 4.0, is a port of
 * the original version to the Intel 80x86 architecture.  This version is
 * distributed only under license agreement from the National Institutes 
 * of Health, Laboratory of Sensorimotor Research, Bldg 10 Rm 10C101, 
 * 9000 Rockville Pike, Bethesda, MD, 20892, (301) 496-9375.
 *-----------------------------------------------------------------------*
 */

/*
 *	Physical memory mapping.
 */

/*
 *	A physical memory address in protected mode (16 bit mode)
 * on the 80X86 architecture is composed of a selector and an
 * offset.  Each component is 16 bits long.  The selector indexes
 * the LDT (Local Descriptor Table) unique to each process.  Therefore,
 * selectors that map the same area in memory may be different for
 * each process.
 */

/*
 * Flags for pa_flag.
 */
#define PA_ALLOC    01		/* segment has been mapped, my selector is
				   valid */

typedef struct {
	pid_t	pa_own_pid;	/* pid of process that owns segment */
	u_int	pa_own_sel;	/* owner's selector for segment */
	u_int	pa_off;		/* offset within segment to location of
				   interest */
	u_int	pa_flag;
	u_int	pa_my_sel;	/* my selector for segment */
#ifdef NEED_FAR
	void far *pa_my_p;	/* pointer to location of interest */
#else
	void *pa_my_p;
#endif	
} PHYSADR;

/*
 *	This structure is written on a temp disk file by REX to
 * publish the addresses of system wide buffer areas.
 */
typedef struct {
	PHYSADR i_bl;	/* INT block */
	PHYSADR r_bl;	/* raw data block */
} PARAM;

/*
 *	Externs used system wide.
 */
extern PARAM param;
extern int paramfd;
void getparam(int fd, PARAM *pm);
#ifdef NEED_FAR
void far *padr_map(PHYSADR *p);
#else
void *padr_map(PHYSADR *p);
#endif
