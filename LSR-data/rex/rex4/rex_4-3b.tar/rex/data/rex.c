/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government.  The original
 * versions, REX 1.0-3.12, were developed for the pdp11 architecture and
 * are in the public domain.  This version, REX 4.0, is a port of the
 * original version to the Intel 80x86 architecture.  This version is
 * copyright (C) 1992 by the National Institutes of Health, Laboratory
 * of Sensorimotor Research, Bldg 10 Rm 10C101, 9000 Rockville Pike,
 * Bethesda, MD, 20892, (301) 496-9375.  All rights reserved.
 *-----------------------------------------------------------------------*
 */

/*
 *	Rex is the first REX process executed.  It establishes and
 * initializes the shared data areas and execs comm.
 * This process doesnt communicate with other REX processes;  it
 * simply waits until comm goes away and then it terminates.
 */

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>
#include <process.h>
#include <signal.h>
#include <string.h>
#include <sys/types.h>
#include <sys/kernel.h>
#include <sys/seginfo.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <i86.h>
#include <fcntl.h>
#include "../hdr/sys.h"
#include "../hdr/phys.h"
#include "../hdr/proc.h"
#include "../hdr/buf.h"
#include "../hdr/ecode.h"
#include "../hdr/cdsp.h"
#include "../hdr/cnf.h"

char commst[]= "command";

PARAM param= {0};
int paramfd=  0;
int status= 0;
INT_BLOCK_P i_b= 0;
RAW_BLOCK_P r_b= 0;

main()
{
	u_int sel_i, sel_r;
	PHYSADR *pa_p;
	pid_t my_pid;
	char *str;
	char pfd[20];
	u_int int_size, raw_size;

	my_pid= getpid();

	/*
	 * Allocate shared segments.
	 */
	int_size= sizeof(INT_BLOCK);
	raw_size= sizeof(RAW_BLOCK);
	if(int_size > 65536) {
	    fprintf(stderr, "INT block is %u bytes, must be <= 65536\n",
		    int_size);
	    exit(1);
	}
	if(raw_size > 65536) {
	    fprintf(stderr, "RAW block is %u bytes, must be <= 65536\n",
		    raw_size);
	    exit(1);
	}
	if((sel_i= qnx_segment_alloc_flags(int_size, _PMF_DMA_SAFE))
		== -1) {
		    perror("rex: I segment alloc");
		    exit(1);
	}
	if((sel_r= qnx_segment_alloc_flags(raw_size, _PMF_DMA_SAFE))
		== -1) {
		    perror("rex: R segment alloc");
		    exit(1);
	}

	/*
	 * Arm all segments.
	 */
	if(qnx_segment_arm(-1, -1, 0) == -1) {
	    perror("rex: Segment arm");
	    exit(1);
	}

	/*
	 * Initialize PARAM structure.
	 */
	pa_p= &param.i_bl;	    /* INT_BLOCK */
	pa_p->pa_own_pid= my_pid;
	pa_p->pa_own_sel= sel_i;
	pa_p->pa_off= 0;
	pa_p->pa_flag= 0;
	pa_p= &param.r_bl;	    /* RAW_BLOCK */
	pa_p->pa_own_pid= my_pid;
	pa_p->pa_own_sel= sel_r;
	pa_p->pa_off= 0;
	pa_p->pa_flag= 0;

	/*
	 * Initializations other than 0.
	 */
	i_b= (void far *)MK_FP(sel_i, 0);
	r_b= (void far *)MK_FP(sel_r, 0);
	_fstrncpy(i_b->i_rxver, RHEADER, P_LVERSION);
	i_b->int_pi= i_b->scrb_pi= i_b->disp_pi= -1;
	i_b->d_rwakecd= ENABLECD;
	i_b->d_wd_disp= D_W_EYE;
	i_b->d_emag= 1;
	i_b->d_omag= 3;
	i_b->evdx= -1;
	i_b->evdump= EDUMPINC;
	
	/*
	 * Write addresses out in file in /tmp.
	 */
	str= "/tmp/param.tmp";
	unlink(str);
	if((paramfd= creat(str,S_IRUSR|S_IWUSR|S_IRGRP|S_IWGRP
			   |S_IROTH|S_IWOTH)) == -1) {
	    perror("Cannot create param file");
	    exit(1);
	}
	if(write(paramfd,&param,sizeof(param)) != sizeof(param)) {
	    perror("Cannot write param file");
	    exit(1);
	}
	close(paramfd);

	/*
	 * Open for reading;  paramfd stays open across fork and exec of
	 * comm, and then for all procs that comm starts.
	 */
	if((paramfd= open(str, 0)) == -1) {
	    perror("Cannot open param file");
	    exit(1);
	}

	/*
 	 * Exec comm.
	 */
	switch(fork()) {

		/*
		 * Exec comm.  Pass param file descriptor.
		 */
	case 0:
		itoa(paramfd, pfd, 10);
		if( execl(commst, commst, pfd, 0) == -1) {
			perror("Cant exec command process");
			exit(1);
		}
	case -1:
		perror("Cant fork to exec command");
		exit(1);
	}

	/*
	 * Ignore signals;  wait for comm to die.
	 */
	signal(S_CNTRLC, SIG_IGN);
	signal(S_CNTRLB, SIG_IGN);
	signal(S_ALERT, SIG_IGN);

#ifdef GOO
{
    struct _seginfo sinfo;

    sleep(2);	/* comm clears screen when Rex starts */
    fprintf(stderr, "Int block: %u, Raw block %u\n", int_size,raw_size);
    fprintf(stderr, "pid of REX: %d, sel_i %#x, sel_r %#x\n",
	    my_pid, sel_i, sel_r);
    if(qnx_segment_info(0, my_pid, sel_i, &sinfo) == -1) perror("info");
    fprintf(stderr, "int: sel %#X, flags %#X\n", sinfo.selector, sinfo.flags);
    fprintf(stderr, "int: addr %#lX, bytes %ld\n", sinfo.addr, sinfo.nbytes);
    if(qnx_segment_info(0, my_pid, sel_r, &sinfo) == -1) perror("info");
    fprintf(stderr, "raw: sel %#X, flags %#X\n", sinfo.selector, sinfo.flags);
    fprintf(stderr, "raw: addr %#lX, bytes %ld\n", sinfo.addr, sinfo.nbytes);
}
#endif
	wait(&status);

	/*
	 * Free segments.
	 */
	if(qnx_segment_free(sel_i) == -1)
	    perror("Cannot free INT_BLOCK segment");
	if(qnx_segment_free(sel_r) == -1)
	    perror("Cannot free RAW_BLOCK segment");
	exit(0);
}
