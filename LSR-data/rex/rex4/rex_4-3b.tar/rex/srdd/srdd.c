/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government.  The original
 * versions, REX 1.0-3.12, were developed for the pdp11 architecture and
 * distributed without restrictions.  This version, REX 4.0, is a port of
 * the original version to the Intel 80x86 architecture.  This version is
 * distributed only under license agreement from the National Institutes 
 * of Health, Laboratory of Sensorimotor Research, Bldg 10 Rm 10C101, 
 * 9000 Rockville Pike, Bethesda, MD, 20892, (301) 496-9375.
 *-----------------------------------------------------------------------*
 */
/*
 * Simple REX data dumper (srdd).
 *
 *	AVH; Jan 81
 *
 *		Modification History
 *
 * 30 Nov 81, AVH:	Largely rewritten.  Now completely checks E and
 *			A files.
 * 11 Feb 82, AVH:	Added error suppression, range on ecode searches,
 *			time reporting to msecs.
 * 01 Nov 82, AVH:	Added argument parsing for multiple files per
 *			invocation.
 * 09 Nov 82, LMO:	Change matrox address to point to nearest monitor
 * 02 Dec 82, AVH:	Prints statistics concerning A records seen. (v2.4)
 * 13 Dec 82, AVH:	Specify an offset from beginning of an A record before
 *			plotting (v2.5)
 * 11 Jan 83, AVH:	Typing cntl b will hardcopy matrox when plotting
 *			(2.6)
 * 7 Sep 83, LMO:	Change to use mxphys(), so it knows about terminals
 * 6 Nov 85, LMO:	Convert to VAX.  Add exit error codes.
 * 28 Jan 87,LMO:	Fix mxphys() call and matrox structure on VAX
 * 24 Apr 88 SCG:	Converted for sun.  Main changes were: negation of
 *			matrox color values to produce black-on-white, and
 *			a problem with the 1st byte in the A-file being read into
 *			a short (adata[256]), (same old byte-ordering problem..)
 * 30 Jul 88 LMO:	fix problem with arsize.  bytes are now swapped by
 *			conversion programs, as they should have been all along!
 * 5aug88 LMO & BJR:	fix sign-extension on short ints for sun. use loword_()
 *			macro
 * 6jan92 BZ, AVH:	converted to ansi, ported to QNX
 * 11may92 AVH:		added timecheck code for event times.
 * 3apr93 LMO		port QNX version back to workstations
 */

#if defined(sun) || defined(sgi)
#define PLOT 0
#else
#define PLOT 1
#endif
char version[] = "SRDD (QNX) V3.4 4Apr93\n";
#define loword_(a)	(unsigned short)(a & 0xffff)

#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <signal.h>
#include "sys.h"
#include "phys.h"
#include "proc.h"
#include "buf.h"
#ifdef __QNX__
#include "matrox.h"
#endif

#define INIT_MASK	020000
#define CANCEL_MASK	040000
#define UNIT1CD		601
#define DEC		0
#define LONG		1

typedef struct {
	char hi;
	char lo;
} * BYTEP;

typedef struct {
	short int hiword;
	short int loword;
} *WORDP;

#define error_M  \
	{if(!eflag) {\
		err= 1;\
		printf("\n-- EV %lu, %s -- ", evnum, efilen);\
	}}

/* Buffer for analog data */

short int adata[8010] = {0};

#define TIMECHECK   1000	/* time in msec for check of drastic
				   reduction in event times */
ANALOGHDR ahd;
EVENT ehd[128];
long evnum;			/* event counter */
long anum;			/* analog file counter */
long prevtime;			/* previous event's time */
int arsize;			/* size of analog header */
int fa, fe;			/* analog and event fd's */
short int xadd;
int aflag;			/* print all events */
int cflag;			/* print cancel events */
int hflag;			/* print header info */
int tflag;			/* print totals info */
int oflag;			/* print all events except those specified
				   by flags */
int rflag;			/* print events with analog records */
int iflag;			/* print init events */
int eflag;			/* supress error reporting */
int pflag;			/* plot analog data */
int uflag;			/* print unit events */
long estart;			/* printing begins with this event */
long astart;			/* printing begins with this analog header */
int code1 = -1;			/* print events with this code */
int code2;
long nextr;			/* file offset of next analog header */
int edone;			/* flag set if event info was printed */
int mcount = 3;			/* number of MAGIC's to look for between
				   bad length analog headers */
int scanA;			/* force scanning of A file event when estart
				   is specified */
int firstescan= 0;		/* set to 0 before first call to escan */
long ccnt;			/* cancels seen */
long icnt;			/* inits */
long ucnt;			/* units */
long scnt;			/* search events */
long a110, ac110;		/* 110 a records and continues */
long a111, ac111;		/* ditto for 111 */
long a112, ac112;		/* ditto for 112 */
long offset = 0;		/* afile offset to begin plotting */
char efilen[80], afilen[80];

/* function prototypes */
void scanfile(void);
void escan(int index);
void ascan(int index);
void eprint(int index);
void aprint(int index);
int aplot(void);
void timepr(long time);
void scopy(char *file, char *out, char ext);
void parse_s(char *ap, void *rp, int type);
void hprint(void);
int cmpsame(char *p1, char *p2, int flag);
void prtotals(void);

char helpst1[] =
"Simple Rex Data Dumper Command Options:\n\
Usage:\tsrdd filenames [-Flags] [es=num] [as=num] [off=num] \
[1c=num] [2c=num]\n\
Filenames are separated by spaces.  It is only necessary to specify one\n\
of the filenames, the E or A file;  the E, A extensions are optional.\n\
The program will also handle both the E and A file specified consecutively,\n\
as when the shell expands wildcards.\n";

char helpst2[] = 
"Flags:\n\
\ta:  Print all events (default \
is print on error only)\n\
\tc:  Print cancel events\n\
\te:  Suppress error reporting\n\
\th:  Print E and A file header info\n\
\ti:  Print init events\n\
\to:  Print events other than inits, cancels, \
analogs, and units\n\
\tp:  Plot A file records, type <cr> between plots\n\
\tr:  Print analog events with A file headers\n\
\tt:  Print totals information for each file\n\
\tu:  Print unit code events\n\
Parameters:\n";

char helpst3[] = 
"\tes (estart):\tStart printing events with event \
'num'\n\
\tas (astart):\tStart printing A file headers with \
header 'num'\n\
\toff (offset):\tOffset from beginning of Afile record to start plotting\n\
\t1c (code 1):\tPrint all events with this ecode\n\
\t2c (code 2):\tPrint events such that 1c <= event \
<= 2c\n\
If an estart is specified and an astart is not, the \
A file is not\n\
scanned until the estart is reached.\n";

void
main(int argc, char *argv[])
{
	char *ap;
	int flagst, argi;
	void do_exit(int sig);

	printf("%s", version);
	if(argc < 2)  {
		printf("%s%s%s", helpst1, helpst2, helpst3);
		exit(1);
	}
	if(argc == 2) tflag= 1;
	signal(SIGINT, do_exit);

	/*
	 *	Process flags and initializations.
	 */
	argc--;
	for(flagst= 2;;flagst++) {	/* find start of flags */
		if(argv[flagst][0] == '-') break;
		if(flagst >= argc) goto ofile;
		}

	for(argi= flagst; argi <= argc; argi++) {
		ap= argv[argi];
		if(*ap == '-') {
			while(*++ap) {
				switch(*ap & 0177) {
				case 'a':
					aflag= 1;
					break;
				case 'c':
					cflag= 1;
					break;
				case 'e':
					eflag= 1;
					break;
				case 'p':
					pflag= 1;
					break;
				case 'u':
					uflag = 1;
					break;
				case 'r':
					rflag= 1;
					break;
				case 'i':
					iflag= 1;
					break;
				case 'o':
					oflag= 1;
					break;
				case 'h':
					hflag= 1;
					break;
				case 't':
					tflag= 1;
					break;
				default:
					printf("Bad flag: -%c\n", *ap);
					exit(1);
				}
			}
		} else {
			switch(*ap & 0177) {
			case 'e':
				parse_s(ap, &estart, LONG);
				break;
			case 'a':
				scanA= 1;
				parse_s(ap, &astart, LONG);
				break;
			case '1':
				parse_s(ap, &code1, DEC);
				break;
			case '2':
				parse_s(ap, &code2, DEC);
				break;
			case 'o':
				parse_s(ap, &offset, LONG);
				break;
			default:
				printf("Bad parameter specification: %s\n",ap);
				exit(1);
			}
		}
	}

    ofile:

#if PLOT
	if( pflag ) {
		void func1(void);

		atexit(func1);
		mxinit(1);
		setmxcolor(MXBRT);
		mxerase(0);
	}
#endif	
	for(argi= 1; argi < flagst; ) {		/* open files and process */
		int sameflag;
		/*
		 * Check if both E and A are specified, as when shell passes
		 * expanded meta characters.  cmpsame() also strips off the A or
		 * E postfix.
		 */
		sameflag= cmpsame(argv[argi], argv[argi+1],
				(argi+1 < flagst ? 1 : 0) );
		if(sameflag) {
			scopy(argv[argi++], efilen, 'E');
			scopy(argv[argi++], afilen, 'A');
		} else {
			scopy(argv[argi], efilen, 'E');
			scopy(argv[argi++], afilen, 'A');
		}
		if((fe= open(efilen, 0)) == -1)  {
			printf("Can't open %s\n", efilen);
			exit(1);
		}
		if((fa= open(afilen, 0)) == -1)  {
			printf("Can't open %s\n", afilen);
			exit(1);
		}
		if(read(fe, adata, 512) != 512)  {
			printf("%s is too short.\n", efilen);
			exit(1);
		}
		if(read(fa, &adata[256], 512) != 512)  {
			printf("%s is too short.\n", afilen);
			exit(1);
		}
		printf("E file %s, A file %s\n", efilen, afilen);

		/* a hdr rec size is in the first byte only if not swapped */
		arsize = adata[256];
		if (arsize == 0) arsize= (int)((BYTEP)&(adata[256]))->hi;
		if (arsize != sizeof(ANALOGHDR)) {
			fprintf(stderr, "analog header size is %d, but should be %d!\n",
				arsize, sizeof(ANALOGHDR));
			exit(1);
		}
		if(hflag) hprint();
		scanfile();
		close(fa);
		close(fe);
		if(tflag) prtotals();
	}
	exit(0);
}

/*
 *	Scan E and A file.
 */

void
scanfile(void)
{
	int count, eindex;

	/*
	 *	Idea:  step down E file and A file together.  When
	 * an event references an A file entry, then check that A
	 * file header.  Also maintain an independent check of the
	 * A file to make sure its record sizes are correct and that
	 * it has no entries not indexed by the E file.
	 */
	evnum= anum= -1;
	icnt= ccnt= ucnt= scnt= 0;
	a110= ac110= a111= ac111= a112 = ac112 = 0;
	nextr= -1L;
	firstescan= 0;
	while((count=read(fe, ehd, 512)) != 0)  {
		count /= 8;
		for(eindex= 0; eindex < count; eindex++)  {

			/*
			 *	Check event.
			 */
			evnum++;
			if(evnum >= estart) {
				scanA= 1;
				escan(eindex);
			}
	
			/*
			 *	Decide if A file is scanned.
			 */
			if(ehd[eindex].e_code < 0) {
				anum++;
				if(scanA && (anum >= astart)) ascan(eindex);
			}
		}
	}
}

/*
 *	Scan events.
 */
void
escan(int index)
{
	EVENT *p;
	int code;
	int err= 0;

	p= &ehd[index];
	code= p->e_code;
	if( loword_(evnum) != p->e_seqnum) {
		error_M;
		if(!eflag) printf("Event seq num differs from expected num.\n");
	}
	if(code >= 0) {
	  if(firstescan == 0) {
	    prevtime= p->e_key;
	    firstescan= 1;
	  } else {
	    if(p->e_key < (prevtime - TIMECHECK)) {
		error_M;
		if(!eflag)
		    printf("Drastic reduction in time from previous event.\n");
	    }
	    prevtime= p->e_key;
	  }
	}

	/*
	 *	Decide whether to print event info.  Always print if
	 * error encountered.
	 */
	if(code < 0) {
	} else if(code & INIT_MASK) {
		icnt++;
		if(iflag) goto print;
	} else if(code & CANCEL_MASK) {
		ccnt++;
		if(cflag) goto print;
	} else if(code == UNIT1CD) {
		ucnt++;
		if(uflag) goto print;
	} else if(code2) {
		if((code >= code1) && (code <= code2)) {
			scnt++;
			goto print;
		}
	}
	else if(code == code1) {
		scnt++;
		goto print;
	}
	else if(oflag) goto print;
	if(err || aflag) goto print;
	edone= 0;
	return;

print:
	edone= 1;
	eprint(index);
}

/*
 *	Scan A file entries.
 */
void
ascan(int index)
{
	ANALOGHDR *dp = &ahd;
	char *p;
	char *np;
	unsigned limit;
	int err= 0;
	int areadnum, mlocal;


	if(nextr >= 0L) if(ehd[index].e_key != nextr) {
		error_M;
		if(!eflag) {
		printf("Event A file pointer not equal to expected\n");
		printf("pointer computed from previous A file header, ");
		printf("expected: %ld\n", nextr);
		}
	}

	/*
	 *	Read A file header.
	 */
	lseek(fa, ehd[index].e_key, 0);
	if(read(fa, &ahd, arsize) != arsize)  {
		error_M;
		if(!eflag) printf("Analog file stops short in header.\n");
	}
	if(dp->aseqnum != loword_(anum)) {
		error_M;
		if(!eflag)
		printf("A header seq num differs from expected num.\n");
	}
	if(dp->amagic != MAGIC)  {
		error_M;
		if(!eflag)
		printf("Bad magic number.\n");
	}
	if(ehd[index].e_code != dp->acode)  {
		error_M;
		if(!eflag)
		printf("E file ecode and A file ecode differ.\n");
	}
	switch(dp->acode) {

		case -110:
			if(dp->acontinue) ac110++;
			else a110++;
			break;
		case -111:
			if(dp->acontinue) ac111++;
			else a111++;
			break;
		case -112:
			if(dp->acontinue) ac112++;
			else a112++;
			break;
	}
	if(dp->alength < 0 || dp->alength > 16002) {
		error_M;
		if(!eflag)
		printf("Bad record size.\n");
		areadnum= 16002;
		nextr= -1;
	} else {
		areadnum= dp->alength;
		nextr= ehd[index].e_key + sizeof(ahd) + dp->alength;
	}

	/*
	 *	Read analog data.  Search for magic numbers not
	 * referenced by E file.
	 */
	if(read(fa, adata, areadnum) != areadnum)  {
		if(areadnum != 16002) {
			error_M;
			if(!eflag)
			printf("Analog record stops short.\n");
		}
	}
	{
		unsigned foo;

		foo= (unsigned) &adata[0];
		limit= foo + areadnum;
	}
	p= (char *) adata;
	mlocal= 0;
	do {
		if(*p++ == MAGIC_B1) {
		  np= p;
		  if(*p++ == MAGIC_B2)
		    if(*p++ == MAGIC_B3)
		      if(*p++ == MAGIC_B4) {
			error_M;
			if(nextr != -1)
			  if(!eflag)
			  printf("Unexpected magic found at offset %ld.\n",
			  	ehd[index].e_key+sizeof(ahd)+(((long)np-1) - (long)adata));
			else {
			  if(!eflag)
			  printf("Next magic found at offset %ld.\n",
				ehd[index].e_key+sizeof(ahd)+(((long)np-1) - (long)adata));
			  if(++mlocal >= mcount) break;
			}
		      }
		  p= np;
		}
	} while((unsigned) p < limit);

	/*
	 *	Print A file entry info?
	 */
	if( (err && !eflag) || rflag) {
		if( ! (edone)) eprint(index);
		else if(err) printf("\n");
		aprint(index);
	}
	if(pflag) {
		if(nextr == -1) {
			printf("Cannot plot record with bad length.\n");
		} else aplot();
	}
}

/*
 *	Print event.
 */
long ltime1;
void
eprint(int index)
{
	EVENT *p;
	int code;

	p= &ehd[index];
	code= p->e_code;
	printf("\nEVENT: %u, expected seq num (unsign) %u, \
(long) %ld\n", p->e_seqnum, loword_(evnum), evnum);
	printf("Type: ");
	if(code < 0) printf("analog, ");
	else if(code & INIT_MASK) {
		printf("init, ");
		code &= ~INIT_MASK;
	}
	else if(code & CANCEL_MASK) {
		printf("cancel, ");
		code &= ~CANCEL_MASK;
	}
	else if(code == UNIT1CD) printf("unit, ");
	else printf("event, ");
	printf("ecode value: (decoded decimal) %d, (actual octal) 0%o.\n",
		code, p->e_code);
	if(code < 0) {
		printf("A file offset: %ld, in block %ld.\n",
			p->e_key, (p->e_key) / 512L);
	} else {
		timepr(p->e_key);
printf("Diff: %ld\n", p->e_key-ltime1);
ltime1= p->e_key;
	}
}

/*
 *	Print A file info.
 */
void
aprint(int index)
{
	ANALOGHDR *p = &ahd;

	printf("A_HEADER: %u, expected seq num (unsign) %u, \
(long) %ld\n", p->aseqnum, loword_(anum), anum);
	printf("Corresponding E file sequence number: (unsign) %u, (long) \
%ld\n", ehd[index].e_seqnum, evnum);
	printf("Ecode %d, cont_flag %d, acount %ld, length %d, next offset %ld\n",
		p->acode, p->acontinue, p->acount, p->alength, nextr);
	timepr(p->atime);
}

#define MASK_1	010000
#define MASK_2	020000
#define MASK_3	040000
#define MASK_12	007777

/*
 * Plot data on matrox.
 */
#pragma off (unreferenced)
int
aplot(void)
{
	short int *p;
	int i;
	short int t;
	char c;
	int count;
	float low, hi, g;
	char buf[100];

#if PLOT
	count= (ahd.alength / 2) - offset;
	if(count <= 0) printf("Offset greater than record size, arecord %ld\n",
						anum);
	p = &adata[offset];
#ifdef GOO
	for (i = 0, low = 30000, hi = -30000; i < count; i++) {
		t = *p;
		if (t > 0) t &= MASK_12;
		else if (t < 0) t |= ~ MASK_12;

		if (t < low) low = t;
		else if (hi < t) hi = t;
		*p++ = t;	/* save for plot */
	}
	g = 511 / (hi - low);
#endif
	p = &adata[offset];
    
	while(count > 0)  {
		mxerase(0);
		mxsize(1);
		mxmove(0, 460);
		mxtext("Alength: ");
		mxtext(itoa(ahd.alength, buf, 10));
		mxtext(", seq: ");
		mxtext(itoa(ahd.aseqnum, buf, 10));
		mxtext(", code: ");
		mxtext(itoa(ahd.acode, buf, 10));
		mxtext("\n");
		mxtext("cont flag: ");
		mxtext(itoa(ahd.acontinue, buf, 10));
		mxtext(", count remaining: ");
		mxtext(itoa(count << 1, buf, 10));
		mxtext(", 1st val: ");
		mxtext(itoa(*p, buf, 10));
		xadd= 0;
		do {
			mxdot(xadd, (*p++ >> 5) + 200);
#ifdef GOO
			mxdot(xadd, (int)(g * (*p++ - low)));
#endif
			if(--count == 0) goto done;
		} while(++xadd < 512);
		mxtext(", last val: ");
		mxtext(itoa(*(p-1), buf, 10));
		while((c=getchar()) != '\n' && c != '\r');
	}
done:	
	mxtext(", last val: ");
	mxtext(itoa(*(p-1), buf, 10));
	while((c=getchar()) != '\n' && c != '\r');
#endif
	return(0);
}
#pragma on (unreferenced)

/*
 *	Process long times.
 */
void
timepr(long time)
{
	int day, hour, mins, sec, msec;
	long ltime= time;

	msec= time % 1000;
	time /= 1000;
	sec= time % 60;
	time /= 60;
	mins= time % 60;
	time /= 60;
	hour= time % 24;
	day= time / 24;
	printf("Time %ld,  %d : %d : %d : %d : %d.\n",
		ltime, day, hour, mins, sec, msec);

}

void
scopy(char *file, char *out, char ext)
{
	while(*file != '\0') *out++ = *file++;
	*out++ = ext;
	*out= '\0';
}

/*
 *	Parse input parameters.
 */
void
parse_s(char *ap, void *rp, int type)
{
	char *p = ap;
	long atol();

	while(*p++ != '=') {
		if(*p == '\0') {
			printf("Bad parameter specification: %s\n", ap);
			exit(1);
		}
	}
	if(type == DEC) *(int *)rp= atoi(p);
	if(type == LONG) *(long *)rp= atol(p);
}

/*
 * Print header info.
 */
void
hprint(void)
{
	printf("E file header-->  Record size: %d\n", adata[0]);
	printf("String: %s\n", &adata[1]);
	printf("A file header-->  Record size: %d\n", adata[256]);
	printf("String: %s\n", &adata[257]);
}

/*
 * Cmpsame: check if both E and A files have been specified.
 * Also strip off E, A postfix if present.
 * Flag is false if less than two filenames remain.

 */
int
cmpsame(char *p1, char *p2, int flag)
{
    if(flag) {
	while(*p1 != '\0' && *p2 != '\0') {
		if(*p1 != *p2) {
			if(*p1 == 'A') {
				*p1= '\0';
				if(*p2 == 'E') {
					*p2= '\0';
					return(1);
				} else return(0);
			}
			if(*p1 == 'E') {
				*p1= '\0';
				if(*p2 == 'A') {
					*p2= '\0';
					return(1);
				} else return(0);
			}
			while(*p1 != '\0') p1++;
			p1--;
			if(*p1 == 'E' || *p1 == 'A') *p1= '\0';
			return(0);
		}
		p1++, p2++;
	}
    }
    while(*p1 != '\0') p1++;
    p1--;
    if(*p1 == 'E' || *p1 == 'A') *p1= '\0';
    return(0);
}
void
prtotals(void)
{
	printf("Totals:\tEvents: %ld\tAnalog (+ continues) %ld\n",
		evnum, anum);
	if(estart == 0 && astart == 0) {
	    printf("-110 records %ld, conts %ld\n", a110, ac110);
	    printf("-111 records %ld, conts %ld\n", a111, ac111);
	    printf("-112 records %ld, conts %ld\n", a112, ac112);
	}
	if(estart == 0) {
		printf("Inits %ld, cancels %ld, units %ld, searched events %ld\n\n",
			icnt, ccnt, ucnt, scnt);
	}
}


#pragma off (unreferenced)
void do_exit(int sig)
#pragma on (unreferenced)
{
    exit(0);
}

void func1(void)
{
#if PLOT
    mxinit(0);
#endif
}
