/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government.  The original
 * versions, REX 1.0-3.12, were developed for the pdp11 architecture and
 * distributed without restrictions.  This version, REX 4.0, is a port of
 * the original version to the Intel 80x86 architecture.  This version is
 * distributed only under license agreement from the National Institutes 
 * of Health, Laboratory of Sensorimotor Research, Bldg 10 Rm 10C101, 
 * 9000 Rockville Pike, Bethesda, MD, 20892, (301) 496-9375.
 *-----------------------------------------------------------------------*
 */

/*
 * Status display and error processing.
 */

#include <stdio.h>
#include <signal.h>
#include "../hdr/sys.h"
#include "../hdr/proc.h"
#include "../hdr/buf.h"
#include "../hdr/ecode.h"
#include "../hdr/tty.h"
#include "../hdr/comm.h"

/*
 * Lengths of fields in status display.
 */
#define ST_LFILE	29
#define ST_LPNUM	25
#define ST_LHOFF	11

static char rexst[P_LVERSION];
static char filest[ST_LFILE];
static char pnumst[ST_LPNUM];

/*
 * Each field printed in the status display is defined by instance of
 * this struct.
 */
static struct status {
	unsign	st_flag;
	int	st_row;		/* row and col address of field */
	int	st_col;
	int	st_len;		/* length of field */
	char 	*st_sp;		/* pointer to string printed in field */
} st[] = {

	/*
	 * Remember: row, col numbers start at 1 not 0.
	 */
	0,1,1,P_LVERSION, rexst,
	0,1,21,11, "Clock ON",
	0,1,32,10, "E Keep",
	0,1,42,10, "A Keep",
	0,1,52,ST_LFILE, filest,
	0,2,1,ST_LPNUM, pnumst,
	0,2,26,ST_LHOFF, "Hist OFF",
	0,0,0,0, NP,
};

/*
 * Indexes to above structures for each field.
 */
#define ST_REX		0	/* Rex name and version */
#define ST_CLOCK	1	/* Clock on indicator */
#define ST_EKEEP	2	/* E keep indicator */
#define ST_AKEEP	3	/* A keep indicator */
#define ST_FILE		4	/* data file name */
#define ST_PNUM		5	/* active int process paradigm number */
#define ST_HOFF		6	/* hist off message */

/*
 * Flag defines.
 */
#define ST_WRITE	01	/* update field */
#define ST_CLEAR	02	/* clear field */

static long oldikey= 0;
static int csflag= 0;	/* current screen flag; contains status of fields
			   currently printed on screen */
static int hflag= 0;	/* state of histogram off field */

/*
 * Print status display at top of screen.  Argument:
 *	0:	Update screen only
 *	1:	Update screen and erase error line
 *	2:	Redraw current status display based on i_b->i_flags.  Screen
 *		must erased prior to call.
 */
#define OBUFSIZ 300

int
status(int flag)
{
	int diff;
	struct status *stp;
	char *p;
	int iflag;
	char *endp, *savp;
	char outbuf[OBUFSIZ];

	if(flag == 2) {
		csflag= hflag= 0;
		st[ST_REX].st_flag= ST_WRITE;
#ifdef NEED_FAR
		_fstufs(i_b->i_rxver, rexst, &rexst[P_LVERSION]);
#else
		stufs(i_b->i_rxver, rexst, &rexst[P_LVERSION]);
#endif
	}

	/*
	 * Determine which fields require updating and set 'st_flag'
	 * accordingly.
	 */
	iflag= i_b->i_flags;
	diff= csflag ^ iflag;
	csflag= iflag;
	if(diff & I_GO)
	    st[ST_CLOCK].st_flag= (iflag & I_GO ? ST_WRITE : ST_CLEAR);
	if(diff & I_EOUT)
	    st[ST_EKEEP].st_flag= (iflag & I_EOUT ? ST_WRITE : ST_CLEAR);
	if(diff & I_AOUT)
	    st[ST_AKEEP].st_flag= (iflag & I_AOUT ? ST_WRITE : ST_CLEAR);
	if(diff & I_FILEOPEN) {
	    if(iflag & I_FILEOPEN) {
#ifdef NEED_FAR
		_fstufs(i_b->inthdr.i_name, st[ST_FILE].st_sp,
			st[ST_FILE].st_sp + st[ST_FILE].st_len);
#else
		stufs(i_b->inthdr.i_name, st[ST_FILE].st_sp,
			st[ST_FILE].st_sp + st[ST_FILE].st_len);
#endif
		st[ST_FILE].st_flag= ST_WRITE;
	    } else st[ST_FILE].st_flag= ST_CLEAR;
	}
	if( ((i_b->d_flags & D_HISTON) == 0)
	&& (hflag == 0) ) {
		st[ST_HOFF].st_flag= ST_WRITE;
		hflag= 1;
	} else if((i_b->d_flags & D_HISTON) && hflag) {
		st[ST_HOFF].st_flag= ST_CLEAR;
		hflag= 0;
	}
	if((oldikey != i_b->i_iev.e_key) || flag) {
	    int pnum, day, hour, minute;
	    long time;

	    oldikey= i_b->i_iev.e_key;
	    if(oldikey == 0) {
		st[ST_PNUM].st_flag= ST_CLEAR;
		goto out;
	    } else st[ST_PNUM].st_flag= ST_WRITE;

	    /*
	     * Assemble paradigm number and time of latest init.
	     */
	    p= st[ST_PNUM].st_sp;
	    endp= p + st[ST_PNUM].st_len;
	    pnum= i_b->i_iev.e_code & ~(0100000|INIT_MASK|CANCEL_MASK);
	    p= stufs("P ", p, endp);
	    p= itoa_RL(pnum, 'd', p, endp);
	    p= stufs(" @ ", p, endp);
	    time= oldikey;
	    time /= 60000;
	    minute= time % 60;
	    time /= 60;
	    hour= time % 24;
	    day= time / 24;
	    if(day) {
		p= itoa_RL(day, 'd', p, endp);
		p= stufs(":", p, endp);
	    }
	    if(hour || day) {
		p= itoa_RL(hour, 'd', p, endp);
		p= stufs(":", p, endp);
	    }
	    p= itoa_RL(minute, 'd', p, endp);
	    fills(' ', ST_PNUM, p, endp);	/* erase rest of field */
	}

out:
	/*
	 * Assemble and print status string in one write to tty.
	 */
	p= outbuf;
	endp= &outbuf[OBUFSIZ];
	savp= p= stufs(tscsav, p, endp);
	for(stp= &st[0]; stp->st_sp != NP; stp++) {
	    if(stp->st_flag & (ST_WRITE|ST_CLEAR)) {
		p= tgscup(stp->st_row, stp->st_col, p, endp);
		if(stp->st_flag & ST_WRITE)
		    p= stufs(stp->st_sp, p, endp);
		else p= fills(' ', stp->st_len, p, endp);
		stp->st_flag= 0;
	    }
	}

	/*
	 * Clear and redraw error line if flag > 0.
	 */
	if(flag) {
	    p= tgscup(T_ERROR, 0, p, endp);
	    p= stufs(tsulon, p, endp);
	    p= fills(' ', 80, p, endp);

	    /*
	     * Some VT100 emulators dont turn off underline when cursor
	     * attributes are restored.
	     */
#ifdef T_Z29
	    p= fills(tsuloff, p, endp);
#endif
	}
	if(savp == p) return(0);
	p= stufs(tscres, p, endp);
	if(p == endp) {
	    rxerr("status(): Status string exceeds output buffer size");
	    return(-1);
	}
	tputs(outbuf);
	return(0);
}

/*
 * Process errors from 'rxerr()'.
 */
#define EFSIZ 300	/* max size of string to write to error file */
#define STSIZ 120	/* max size of string to write to tty */

void
p_rxerr(char *s, int ptx)
{
	char ef[EFSIZ], st[STSIZ];
	char *ep;
	char *p;
	PROCTBL_P pp;
	char *nep;
	extern FILE *errout;

	/*
	 * Reset rerr_erase count to cause error to be erased later.
	 */
	rerr_erase= 0;

	/*
	 * Build string to output to error file first.
	 */
	p= ef;
	ep= &ef[EFSIZ];
	*p++= '[';
	p= itoa_RL(errnum++, 'd', p, ep);	/* error number */
	if(infd || rtlevel) {
#ifdef NEED_FAR
		char far *np;
#else
		char *np;
#endif

		*p++ = ' ', *p++ = '(';
		p= itoa_RL(i_b->i_rtcln, 'd', p, ep);
		*p++ = ',';

		/*
		 * Get current root file name;  account for nesting.
		 */
		if(infd != 0) np= i_b->i_rtname;
		else np= rtsav[rtlevel].rs_rtname;
#ifdef NEED_FAR
		p= (char *)_fstufs(np, p, ep);
#else
		p= stufs(np, p, ep);
#endif
		*p++ = ')';
	}
	*p++= ' ';
#ifdef NEED_FAR
	p= (char *)_fstufs(i_b->ptbl[ptx].p_name, p, ep);
#else
	p= stufs(i_b->ptbl[ptx].p_name, p, ep);
#endif
	*p++= ']';
	*p++= ' ';
	p= stufs(s, p, ep);		/* error message */
	fputs(ef, errout);
	putc('\n', errout);
	fflush(errout);

	/*
	 * Build string to output to screen.
	 */
	p= st, ep= &st[STSIZ];
	p= stufs(tscsav, p, ep);	
	p= stufs(tsulon, p, ep);	
	p= tgscup(T_ERROR, 0, p, ep);	

	/*
	 * Find out how many chars are currently in string and set ep
	 * to restrict printed message to 80 char screen width.  Pad
	 * with spaces to erase any previous message, but keep underline.
	 */
	nep= p+80;
	p= stufs(ef, p, nep);
	p= fills(' ', nep - p, p, ep);	/* pad with spaces */
	*p++ = '\007';			/* bel */
#ifdef T_Z29
	p= stufs(tsuloff, p, ep);
#endif
	p= stufs(tscres, p, ep);
	tputs(st);

	/*
	 * Abort root read processing when errors occur;  abort all nested
	 * reads as well.  This section must be prevented from being reentered.
	 * If sendmsg() encounters an error and calls rxerr() then p_rxerr()
	 * will be called again resulting in an endless loop.  Therefore call
	 * rt_close() for comm first so that test (infd || rtlevel) will be
	 * false if reentered.
	 */
	if(infd || rtlevel) {
		rtlevel= 0;
		i_b->i_rtflag= RT_CLOSE;
		rt_close();

		/*
		 * Dont call rtalert() in order to bypass acknowledgement and 
		 * error handling.
		 */
		for(pp= &PT[1]; pp < &PT[P_NPROC]; pp++) {
			if(pp->p_id == 0) continue;
			if((pp->p_state & P_RUN_ST) == 0) continue;
			sendmsg(pp, G_RTEXEC);	/* no need to wait for ack.
						   for close */
		}
	}
}
