/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government.  The original
 * versions, REX 1.0-3.12, were developed for the pdp11 architecture and
 * distributed without restrictions.  This version, REX 4.0, is a port of
 * the original version to the Intel 80x86 architecture.  This version is
 * distributed only under license agreement from the National Institutes 
 * of Health, Laboratory of Sensorimotor Research, Bldg 10 Rm 10C101, 
 * 9000 Rockville Pike, Bethesda, MD, 20892, (301) 496-9375.
 *-----------------------------------------------------------------------*
 */

/*
 * Comm noun, menus.
 */

#include <stdio.h>
#include <signal.h>
#include "../hdr/sys.h"
#include "../hdr/proc.h"
#include "../hdr/buf.h"
#include "../hdr/menu.h"
#include "../hdr/comm.h"

/*
 * Comm noun table.
 */
NOUN nouns[]= {
	"names",	&n_name,
	"proc",		&n_proc,
	"root",		&n_root,
	"rex",		&n_rex,
	"tty",		&n_tty,
	"trials",	&n_trials,
	"print_debug",	&n_debug,
	"",
};

/*
 * Comm currently has no menus.  access() is not loaded to save core space.
 * If menus are added calls to access() in nmc.c and rt_write() in rtc.c,
 * currently commented out, must be restored.
 */
MENU menus[]= {
NS,
};
