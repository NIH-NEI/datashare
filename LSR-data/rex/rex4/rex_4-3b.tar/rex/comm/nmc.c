/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government.  The original
 * versions, REX 1.0-3.12, were developed for the pdp11 architecture and
 * distributed without restrictions.  This version, REX 4.0, is a port of
 * the original version to the Intel 80x86 architecture.  This version is
 * distributed only under license agreement from the National Institutes 
 * of Health, Laboratory of Sensorimotor Research, Bldg 10 Rm 10C101, 
 * 9000 Rockville Pike, Bethesda, MD, 20892, (301) 496-9375.
 *-----------------------------------------------------------------------*
 */

/*
 * Noun, menu control.
 */

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <signal.h>
#include "../hdr/sys.h"
#include "../hdr/proc.h"
#include "../hdr/buf.h"
#include "../hdr/menu.h"
#include "../hdr/comm.h"
#include "../hdr/tty.h"

#undef  A_DEBUG		/* define for debugging info */

/*
 * Send noun or menu name to process to execute.  If p != NP then
 * only nouns, menus of process p are eligible.  Returns index to ptbl entry
 * that name is sent to.  Comm goes to sleep after name is sent to allow
 * process to take over keyboard.  Receiving process must awaken comm
 * when done.  If verb string 'vstr' is null, the name is assumed to be
 * a menu;  otherwise a noun.  If noerrprt is true, rxerr() will not be
 * called if noun or menu name is not found;  err status will still be returned,
 * however.  This is used by callers that need to handle errors themselves.
 * Error status returns:
 *	-1:	Noun or menu not found
 *	-2:	Error sending G_NMEXEC msg to process (in this case sendmsg
 *		calls rxerr())
 */
int
sendnm(PROCTBL_P p, char *nmstr, char *vstr, char *argstr, int noerrprt)
{
	NAME *np;
	NAME *nprocp= NP, *nstart= NP, *nend= NP;
	int (*func)();
	extern ME_ACCP me_accp;

	if(*vstr == '\0') {
		if(p != NP) nprocp= p->p_menup;
		nstart= &menutbl[0], nend= &menutbl[P_NMENU];
	} else {
		if(p != NP) nprocp= p->p_nounp;
		nstart= &nountbl[0], nend= &nountbl[P_NNOUN];
	}
	if(p != NP) {	/* search only names of this proc */
		for(np= nprocp; np != NP; np= np->na_nextn)
			if(match(nmstr, np->na_name)) break;
	} else {
		for(np= nstart; np < nend; np++) {
		    if(np->na_pp == NP) continue;
		    if(match(nmstr, np->na_name)) {
			p= np->na_pp;

			/*
			 * If this is an int process, but not the currently
			 * running int process, keep looking.
			 */
			if( (p->p_state & P_INTPROC_ST)
			&&  (i_b->int_pi > 0)
			&&  ((p->p_state & P_RUN_ST) == 0) ) continue;
			break;
		    }
		}
	}
	if(np == NP || np == nend) {
		if(noerrprt == 0) rxerr("sendnm(): noun or menu not found");
		return(-1);
	}
	if(p == COMM) {		/* comm's own noun or menu */
	    if(*vstr != '\0') {
		func= nouns[np->na_tblx].n_ptr;
		(*func)(vstr, argstr);

	    /*
	     * Comm currently has no menus; comment out next line to
	     * prevent access() from being loaded.
	    } else access(&me_accp, &menus[np->na_tblx], argstr);
	     */
	    }
	} else {
		while(i_b->i_nindex) sleep(1);	/* wait until free */
		i_b->i_nindex= np->na_tblx;
#ifdef NEED_FAR
		_fstufs(vstr, &i_b->i_verbs, &i_b->i_verbs[P_ISLEN]);
		_fstufs(argstr, &i_b->i_args, &i_b->i_args[P_ISLEN]);
#else
		stufs(vstr, &i_b->i_verbs, &i_b->i_verbs[P_ISLEN]);
		stufs(argstr, &i_b->i_args, &i_b->i_args[P_ISLEN]);
#endif
		clrack_;
#ifdef A_DEBUG
dprintf("-nmc: before sendmsg, v: %s n: %s arg: %s-", vstr, nmstr, argstr);
#endif
		if(sendmsg(p, G_NMEXEC)) {
			i_b->i_nindex= 0;
			return(-2);
		}
#ifdef A_DEBUG
dputs("-nmc: after sendmsg, before waitack-");
#endif
		waitack(0, S_ALERT);
#ifdef A_DEBUG
dputs("-nmc: after waitack-");
#endif
	}
	return(p - &PT[0]);
}

/*
 * Acquire new process' noun, menu names.
 */
void
getnames(PROCTBL_P p)
{
	int index;
	NOUN *cnp= &nouns;		/* comm's own nouns, menus */
	MENU *cmp= &menus;
	NAME *np;
	NAME *nend;
#ifdef NEED_FAR
	NAME *far *prevnp;
#else
	NAME **prevnp;
#endif
	int *countp, i;
	char buf[P_LNAME];

	if(p == NP) return;
	for(i= 0; i < 2; i++) {		/* loop for both nouns and menus */
	    buf[0]= '\0';
	    index= 0;

	    if(i == 0) {
		prevnp= &p->p_nounp;	/* loop 0: nouns */
		np= &nountbl[0];
		nend= &nountbl[P_NNOUN];
		countp= &nnoun;
	    } else {
		prevnp= &p->p_menup;	/* loop 1: menus */
		np= &menutbl[0];
		nend= &menutbl[P_NMENU];
		countp= &nmenu;
	    }

	    for(;;) {
		if(p == COMM)	/* comm's own names */
		    if(i == 0) stufs(cnp++->n_name, buf, &buf[P_LNAME]);
		    else stufs(cmp++->me_name, buf, &buf[P_LNAME]);
		else if( read(p->p_pipe[0], buf, P_LNAME) < 0 ) {

			/*
			 * Check first for interrupted sys call.
			 */
			if(errno == EINTR) continue;
	
			rxerr("getnames(): bad pipe, cannot get nouns, menus");
			sleep(5);
			*prevnp= NP;
			goto out;
		}
		if(buf[0] == '\0') break;
		while(np->na_pp != NP) {	/* find a free slot */
			if(++np == nend) {
				if(i == 0)
				    rxerr("getnames(): noun table overflow");
				else rxerr("getnames(): menu table overflow");
				break;
			}
		}
		*prevnp= np;	/* link in previous pointer */
		prevnp= &np->na_nextn;	/* new pointer */
		np->na_pp= p;
		np->na_tblx= index++;
		(*countp)++;
		stufs(buf, np->na_name, &np->na_name[P_LNAME]);
	    }
	    *prevnp= NP;
	}

out:
	if(p != COMM) {
		close(p->p_pipe[0]);
		close(p->p_pipe[1]);
	}
}

/*
 * Print noun or menu tables by process.
 */
void
tname(char what)
{
	PROCTBL_P p;
	NAME *np;
	int col;
#ifdef NEED_FAR
	char tmp[P_LPROCNAME];
#endif

	tflush_;
	for(p= &PT[0]; p < &PT[P_NPROC]; p++) {
		if(p->p_id == 0) continue;
#ifdef NEED_FAR
	        _fstrncpy(tmp, p->p_name, P_LPROCNAME);
		printf("\n%s recognizes:\n\t", tmp);
#else
		printf("\n%s recognizes:\n\t", p->p_name);
#endif
		col= 0;
		np= (what == 'n' ? p->p_nounp : p->p_menup);
		for(; np != NP; np= np->na_nextn) {
		    printf("%s%s", np->na_name, (col++ < 4 ? "\t" : "\n\t"));
		    if(col > 4) col= 0;
		}
	}
	putchar('\n');
	tflush_;
}
