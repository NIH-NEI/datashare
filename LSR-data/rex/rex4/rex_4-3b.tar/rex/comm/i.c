/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government.  The original
 * versions, REX 1.0-3.12, were developed for the pdp11 architecture and
 * distributed without restrictions.  This version, REX 4.0, is a port of
 * the original version to the Intel 80x86 architecture.  This version is
 * distributed only under license agreement from the National Institutes 
 * of Health, Laboratory of Sensorimotor Research, Bldg 10 Rm 10C101, 
 * 9000 Rockville Pike, Bethesda, MD, 20892, (301) 496-9375.
 *-----------------------------------------------------------------------*
 */

/*
 *	Comm data initializations.
 */

#include <stdio.h>
#include <signal.h>
#include <sys/types.h>
#include "../hdr/sys.h"
#include "../hdr/phys.h"
#include "../hdr/proc.h"
#include "../hdr/buf.h"
#include "../hdr/comm.h"

/*
 * Version indentifier for comm process.
 */
char version[P_LVERSION]= "4.3, 24 Nov 93";

INT_BLOCK_P i_b= 0;
RAW_BLOCK_P r_b= 0;
PARAM param= {0};
int paramfd= 0;
int sysflags= 0;
int nproc= 0;
NAME nountbl[P_NNOUN];
NAME menutbl[P_NMENU];
int nnoun= 0;
int nmenu= 0;
char NS[] = "";
FILE *errout;
int rtlevel, rtflag;
PROCTBL zerop= {0};
int myptx;
RTSAV rtsav[P_RTLMAX];
int errnum= 0;
PROCTBL_P myptp;
int rerr_erase= ERASECNT+1;
int error1= 0, error2= 0, error3= 0;
sigset_t alert_set;
