/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government.  The original
 * versions, REX 1.0-3.12, were developed for the pdp11 architecture and
 * distributed without restrictions.  This version, REX 4.0, is a port of
 * the original version to the Intel 80x86 architecture.  This version is
 * distributed only under license agreement from the National Institutes 
 * of Health, Laboratory of Sensorimotor Research, Bldg 10 Rm 10C101, 
 * 9000 Rockville Pike, Bethesda, MD, 20892, (301) 496-9375.
 *-----------------------------------------------------------------------*
 */

#include <stdio.h>
#include <time.h>
#include <string.h>
#include <signal.h>
#include "../hdr/sys.h"
#include "../hdr/proc.h"
#include "../hdr/buf.h"
#include "../hdr/menu.h"
#include "../hdr/tty.h"
#include "../hdr/comm.h"

#undef  A_DEBUG			/* define for debugging info */

extern error3;

/*
 * Root control.
 */

/*
 * Noun 'root'.
 *
 * Note:  Test for infd != 0 will indicate if a root file is CURRENTLY being
 * read.  Test for (infd || rtlevel) will be true when root file is either
 * currently being read or a read has been nested due to subsequent root
 * read or write.
 */
int
n_root(char *vstr, char *astr)
{
	char pstr[P_ISLEN];
	char tstr[P_ISLEN];
	char *parray[P_NARG];
	char **pbuf= parray;
	RTSAV *rsp;
	PROCTBL_P proc;
#ifdef NEED_FAR
	char rtn_tmp[P_ISLEN];
	char far *p;
	char far *rtn_ep= &i_b->i_rtname[P_ISLEN];
#else
	char *p;
	char *rtn_ep= &i_b->i_rtname[P_ISLEN];
#endif
	time_t tvec;
	extern FILE *rtout;

#ifdef A_DEBUG
dputs("-rtc: entered-");
#endif
	if(match("wm", vstr)) rtflag= RT_WMENU;
	else if(match("ws", vstr)) rtflag= RT_WSTATE;
	else if(match("wa", vstr)) rtflag= RT_WMENU|RT_WSTATE;
	else if(match("r", vstr)) rtflag= RT_READ;
	else if(match("er", vstr)) rtflag= RT_READ|RT_ECHO;
	else {
		badverb();
		return(-1);
	}
	stufs(astr, pstr, &pstr[P_ISLEN]);
	if(parse(1, pstr, pbuf, P_NARG) < 0) return(-1);
	if(*pbuf == NP) {
		rxerr("n_root(): Root filename not specified");
		return(-1);
	}

	/*
	 * If currently reading from a root file, push down current
	 * root info and process new root file;  this can be continued
	 * to depth of P_RTLMAX.  When a nested root finishes, restore
	 * previous root's context and resume where left off.
	 */
	if(infd != 0) {
		if(++rtlevel >= P_RTLMAX) {	/* rtsav[0] is not used */
		    rxerr("n_root: Too many nested reads");
		    return(-1);
		}
		rsp= &rtsav[rtlevel];
		rsp->rs_rtflag= i_b->i_rtflag;
		rsp->rs_rtcx= i_b->i_rtcx;
		rsp->rs_rtseekp= i_b->i_rtseekp;
		rsp->rs_rtcln= i_b->i_rtcln;
#ifdef NEED_FAR
		_fstufs(i_b->i_rtname, rsp->rs_rtname, &rsp->rs_rtname[P_ISLEN]);
#else
		stufs(i_b->i_rtname, rsp->rs_rtname, &rsp->rs_rtname[P_ISLEN]);
#endif
		/*
		 * If new command is to read root file, send message to
		 * all procs to close current root.
		 */
		if(rtflag & RT_READ) {
			i_b->i_rtflag= RT_CLOSE|RT_RNEST;
			if(rtalert(NP) < 0) return(-1);
		}
	}
	i_b->i_rtflag= rtflag | (rtlevel ? RT_RNEST : 0);

	/*
	 * If there are no '/'s in name prepend dir 'rt/'.
	 */
	stufs(*pbuf++, tstr, &tstr[P_ISLEN]);
	if(index_RL('/', tstr) == NP)
#ifdef NEED_FAR
		p= _fstufs("rt/", i_b->i_rtname, rtn_ep);
#else
		p= stufs("rt/", i_b->i_rtname, rtn_ep);
#endif
	else p= i_b->i_rtname;
#ifdef NEED_FAR
	_fstufs(tstr, p, rtn_ep);
#else
	stufs(tstr, p, rtn_ep);
#endif

	/*
	 * Reading root.
	 */
	if(rtflag & RT_READ) {
		i_b->i_rtcx= 512;	/* force initial read */
		i_b->i_rtcln= 0;
		i_b->i_rtseekp= 0;
		return(rtalert(NP));
	}

	/*
	 * Writing root;  open file and write comment with date.
	 */
#ifdef NEED_FAR
	_fstrcpy(rtn_tmp, i_b->i_rtname);
	if((rtout= fopen(rtn_tmp, "a")) == NULL) {
#else
	if((rtout= fopen(i_b->i_rtname, "a")) == NULL) {
#endif
		rxerr("n_root: Cannot create or open root file");
		return(-1);
	}
	tvec= time(NULL);
	fputs("~\n~\n~Root written: ", rtout);
	fputs(ctime(&tvec), rtout);
	fputs("~\n", rtout);
	fflush(rtout);
	fclose(rtout);

	/*
	 * If verb is to write statelist parameters only, send command
	 * just to int.
	 */
	if(rtflag & RT_WSTATE && ( ! (rtflag & RT_WMENU))) {
		if(i_b->int_pi) if(rtalert(&PT[i_b->int_pi]) < 0)
			return(-1);
	} else {
	    proc= NP;
	    i_b->i_rtmenus[0]= '\0';
	    if(*pbuf != NP) {

		/*
		 * Get process name from arg string.
		 */
		if((proc= getptp(*pbuf)) == NP) {
		    rxerr("n_root(): Bad process name specified");
		    return(-1);
		}
		pbuf++;
	    }

	    /*
	     * If specific menus are designated in arg string, copy
	     * menu names to INT_BLOCK from unparsed orignal.
	     */
	    if(*pbuf != NP)
#ifdef NEED_FAR
		_fstufs(&astr[*pbuf - &pstr[0]], i_b->i_rtmenus,
			&i_b->i_rtmenus[P_ISLEN]);
#else
		stufs(&astr[*pbuf - &pstr[0]], i_b->i_rtmenus,
			&i_b->i_rtmenus[P_ISLEN]);
#endif
	    if(rtalert(proc) < 0) return(-1);
	}

	/*
	 * If this write root command came from a root file, restore
	 * and resume previous root.  Only rtflag and root filename were
	 * affected for the write.
	 */
	if(rtlevel) {
		rsp= &rtsav[rtlevel--];
		i_b->i_rtflag= rsp->rs_rtflag;
#ifdef NEED_FAR
		_fstufs(rsp->rs_rtname, i_b->i_rtname, rtn_ep);
#else
		stufs(rsp->rs_rtname, i_b->i_rtname, rtn_ep);
#endif
	}
	return(0);
}

/*
 * Send root exec message to REX processes.  If arg is NP message is sent
 * to all REX processes, otherwise only to specified process.
 */
int
rtalert(PROCTBL_P pp)
{
	PROCTBL_P bp, ep;
	int npflag= 0;

#ifdef A_DEBUG
dputs("-rtalert-");
#endif
	if(pp != NP) {
		bp= pp;
		ep= bp + 1;
	} else {
		bp= &PT[0];
		ep= &PT[P_NPROC];
		npflag= 1;
	}
	for(; bp < ep; bp++) {
	    if(bp->p_id == 0) continue;

	    /*
	     * Do not send root commands to procs that are not in run state.
	     */
	    if((bp->p_state & P_RUN_ST) == 0) continue;
	    if(bp == COMM) {
#ifdef A_DEBUG
dprintf("-in comm switch, i_rtflag %o-", i_b->i_rtflag);
#endif
		if(i_b->i_rtflag & RT_READ) {
		    if(rt_read() < 0) return(-1);
		} else if(i_b->i_rtflag & RT_WMENU) {

		    /*
		     * Comm currently has no menus;  comment out call to
		     * to rt_write() to save core space.
		    if(rt_write() < 0) return(-1);
		     */
		} else if(i_b->i_rtflag & RT_CLOSE) {
		    if(rt_close() < 0) return(-1);
		}
		continue;
	    }
	    clrack_;
	    if(sendmsg(bp, G_RTEXEC) < 0) return(-1);

	    /*
	     * This waitack() might never return if proc doesnt respond.
	     * It cannot be called with timeout option, however, because
	     * a root read may take quite a while if echo is on.
	     */
	    waitack(0, S_ALERT);
	}
	return(0);
}

/*
 * Called from p_cmd() when read of root file completes.
 */
int
rtreof(void)
{
	RTSAV *rsp;

	i_b->i_rtflag= RT_CLOSE | (rtlevel ? RT_RNEST : 0);
	if(rtalert(NP) < 0) return(-1);

	if(rtlevel > 0) {
	    rsp= &rtsav[rtlevel];

	    /*
	     * Restore seekp so that first tgetl() will read full block
	     * into input buffer at point where left off.
	     */
	    i_b->i_rtseekp= (rsp->rs_rtseekp) - (512 - rsp->rs_rtcx);
	    i_b->i_rtcx= 512;		/* force a read by tgetl() */
	    i_b->i_rtcln= rsp->rs_rtcln;
	    i_b->i_rtflag= rsp->rs_rtflag;
#ifdef NEED_FAR
	    _fstufs(rsp->rs_rtname, i_b->i_rtname, &i_b->i_rtname[P_ISLEN]);
#else
	    stufs(rsp->rs_rtname, i_b->i_rtname, &i_b->i_rtname[P_ISLEN]);
#endif

	    /*
	     * Reopen previous root file;  wait until afterwards to
	     * decrement rtlevel when infd will again be non-zero.  This
	     * insures that test (infd || rtlevel) will always be valid
	     * test for root read in progress.
	     */
	    if(rtalert(NP) < 0) return(-1);
	    rtlevel--;
	    return(0);
	}
	return(0);
}
