/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government.  The original
 * versions, REX 1.0-3.12, were developed for the pdp11 architecture and
 * distributed without restrictions.  This version, REX 4.0, is a port of
 * the original version to the Intel 80x86 architecture.  This version is
 * distributed only under license agreement from the National Institutes 
 * of Health, Laboratory of Sensorimotor Research, Bldg 10 Rm 10C101, 
 * 9000 Rockville Pike, Bethesda, MD, 20892, (301) 496-9375.
 *-----------------------------------------------------------------------*
 */

/*
 * Comm interprocess communication.
 * See scribe/alert.c for extensive comments on alert() routines.
 */

#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <errno.h>
#include <i86.h>
#include "../hdr/sys.h"
#include "../hdr/proc.h"
#include "../hdr/buf.h"
#include "../hdr/tty.h"
#include "../hdr/comm.h"

#undef  A_DEBUG		/* diag printing */

/*
 * Following determines which messages are allowed during re-interrupts
 * when comm is asleep.
 */
#define SLEEPMASK	(s_(CM_SLEEP))	/* allow everything (but myself) to
					   re-interrupt during comm sleeps */

#pragma off (unreferenced)
void
alert(int sig)
{
#pragma on (unreferenced)
	PROCTBL_P p= COMM;
	u_int msg, restormask;

	if(p->p_state & P_ALRTBSY_ST) return;
	p->p_state |= P_ALRTBSY_ST;

newscan:
	protect(&p->p_sem);
	msg= p->p_msg & ~p->p_rmask;	/* mask with reinterrupt pri level */
	if(msg == 0) {

		/*
		 * Alert must return from here only.
		 */
		p->p_state &= ~(P_NOSIG_ST|P_ALRTBSY_ST);
		release_(&p->p_sem);
		return;

	} else if(msg & s_(CM_RXERR)) {
		char msgsav[P_ISLEN];
		int ptxsav;

		p->p_msg &= ~s_(CM_RXERR);
		release_(&p->p_sem);
#ifdef NEED_FAR
		_fstufs(i_b->i_errstr, msgsav, &msgsav[P_ISLEN]);
#else
		stufs(i_b->i_errstr, msgsav, &msgsav[P_ISLEN]);
#endif
		ptxsav= i_b->i_errptx;
		i_b->i_errstr[0]= '\0';		/* free i_errstr */
		p_rxerr(msgsav, ptxsav);
		status(0);

	} else if(msg & s_(CM_BADCHILD)) {
		p->p_msg &= ~s_(CM_BADCHILD);
		release_(&p->p_sem);
		sysflags |= C_BADCHILD;

	} else if(msg & s_(CM_SLEEP)) {
		p->p_msg &= ~s_(CM_SLEEP);
		if(i_b->c_flags & C_ASLEEP) {
			release_(&p->p_sem);
			rxerr("alert(): Msg rec'd to sleep while sleeping");
			goto newscan;
		}

		/*
		 * Allow re-interrupts.
		 */
		restormask= (p->p_rmask ^ SLEEPMASK) & SLEEPMASK;
		p->p_rmask |= SLEEPMASK;
		p->p_state &= ~(P_NOSIG_ST|P_ALRTBSY_ST);
		release_(&p->p_sem);
		if(sigprocmask(SIG_UNBLOCK, &alert_set, NULL) == -1)
		    rxerr("alert(): cannot sigprocmask");

		commsleep();		/* put comm to sleep */

		/*
		 * Disable re-interrupts and restore pri mask.
		 */
		if(sigprocmask(SIG_BLOCK, &alert_set, NULL) == -1)
		    rxerr("alert(): cannot sigprocmask");
		p->p_state |= (P_NOSIG_ST|P_ALRTBSY_ST);
		p->p_rmask &= ~restormask;

	} else if(msg & s_(CM_WAKEUP)) {
		p->p_msg &= ~s_(CM_WAKEUP);
		i_b->c_flags &= ~C_ASLEEP;
		release_(&p->p_sem);

	} else if(msg & s_(CM_STATUS)) {
		p->p_msg &= ~s_(CM_STATUS);
		release_(&p->p_sem);
		status(0);		/* print status info on screen */

	} else if(msg & s_(CM_SENDNAME))  {
		p->p_msg &= ~s_(CM_SENDNAME);
		release_(&p->p_sem);
		if( ! (sysflags & C_NAMERDY)) {
			rxerr("alert(): Illegal msg rec'd to acquire nouns");
			goto newscan;
		}
		sysflags &= ~C_NAMERDY;
		sysflags |= C_SENDNAME;

	} else if(msg & s_(CM_AFFIRM)) {
		p->p_msg &= ~s_(CM_AFFIRM);
		release_(&p->p_sem);
		sysflags |= C_AFFIRM;

	} else if(msg & s_(CM_NEG)) {
		p->p_msg &= ~s_(CM_NEG);
		release_(&p->p_sem);
		sysflags |= C_NEG;

	} else {
		p->p_msg &= ~msg;
		release_(&p->p_sem);
		rxerr("alert(): Illegal message received");
	}

	goto newscan;
}

/*
 * Wait for acknowledgement message.
 * There are critical sections involved here, and following sequence of events
 * must be adhered to:
 *
 *	1. clrack_;
 *	2. Initiate event that will cause an acknowledge (usually involves
 *	   sending a message or noun-menu to another process);
 *	3. Call waitack();
 *
 * If timeout is true, dont sleep forever but abort after P_EXWAIT
 * seconds.  This is used in circumstances where it is not certain
 * an acknowledgement will come.
 */
int
waitack(int timeout, int sig)
{
	int scnt= 0, rval;
	sigset_t ack_set, oset;

	sigemptyset(&ack_set);
	sigaddset(&ack_set, sig);
	for(;;)  {

		/*
		 * Critical section:  must block ack signal before
		 * following tests.  The 'sigsuspend' will unblock
		 * the signal.  Want to avoid case where the ack
		 * signal comes between the test and the suspend-
		 * in this case would suspend forever.  
	         */
		if(sigprocmask(SIG_BLOCK, &ack_set, &oset) == -1) {
		    rxerr("waitack(): cannot block signal");
		    rval= -2;
		    break;
		}
		if(sysflags & C_AFFIRM) {
		    rval= 0;
		    break;
		}
		if(sysflags & C_NEG) {
		    rval= -1;
		    break;
		}
		if(timeout) {
		    if(sigprocmask(SIG_UNBLOCK, &ack_set, NULL) == -1) {
			rxerr("waitack(): cannot unblock signal");
			rval= -2;
			break;
		    }
		    sleep(1);
		} else {
		    oset &= ~ack_set;
#ifdef GOO
 		    sigsuspend(&oset);
#else
/*
 * Until bug is fixed in 'sigsuspend', sleep and awake again.
 */
		    if(sigprocmask(SIG_UNBLOCK, &ack_set, NULL) == -1) {
			rxerr("waitack(): cannot unblock signal");
			rval= -2;
			break;
		    }
		    delay(250);
#endif
		}
		if(timeout && (scnt++ >= P_EXWAIT)) {
			rxerr("waitack(): Timeout on wait acknowledge");
			rval= -2;
			break;
		}
	}
	if(sigprocmask(SIG_UNBLOCK, &ack_set, NULL) == -1) {
	    rxerr("waitack(): cannot unblock signal");
	    rval= -2;
	}
	return(rval);
}

/*
 * Sleep until CM_WAKEUP message.
 */
commsleep()
{
	i_b->c_flags |= C_ASLEEP;
	for(;;) {
		sleep(32000);
		if( (i_b->c_flags & C_ASLEEP) == 0) break;
	}
}

/*
 * This routine compensates for a bug in 'sigsuspend'.  It is
 * not currently atomic.  After unblocking a signal, it will
 * allow it to be received before going to sleep.  Therefore,
 * the sleep wont return.
 */
#ifdef GOO
int Sigsuspend(const sigset_t *nmask)
{
sigset_t pmask;
    
    sigpending(&pmask);
    return pmask & ~*nmask ?
            sigprocmask(SIG_SETMASK,nmask,(sigset_t *)0)
            : sigsuspend(nmask);
}
#endif
