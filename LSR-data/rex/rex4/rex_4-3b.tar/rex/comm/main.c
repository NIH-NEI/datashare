/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government.  The original
 * versions, REX 1.0-3.12, were developed for the pdp11 architecture and
 * distributed without restrictions.  This version, REX 4.0, is a port of
 * the original version to the Intel 80x86 architecture.  This version is
 * distributed only under license agreement from the National Institutes 
 * of Health, Laboratory of Sensorimotor Research, Bldg 10 Rm 10C101, 
 * 9000 Rockville Pike, Bethesda, MD, 20892, (301) 496-9375.
 *-----------------------------------------------------------------------*
 */

/*
 * Comm process entered here;  command processing.
 */

#include <sys/types.h>
#include <sys/wait.h>
#include <process.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <setjmp.h>
#include <signal.h>
#include <string.h>
#include "../hdr/sys.h"
#include "../hdr/phys.h"
#include "../hdr/proc.h"
#include "../hdr/buf.h"
#include "../hdr/tty.h"
#include "../hdr/matrox.h"
#include "../hdr/comm.h"

jmp_buf env= {0};
char prompt[] = "> ";
extern char version[];
int ljval= 0;
#ifdef PDP11_TRAP
void onrterr(int sig);
#endif

#pragma off (unreferenced)
main(int argc, char *argv[])
{
#pragma on (unreferenced)
	PROCTBL_P comm_p;
	extern FILE *errout;
	extern int (*p_err)();

#ifdef GOO
	setbuf(stdout, NULL);
#endif

	/*
	 * Open error file.
	 */
	errout= fopen("/tmp/rxerr", "w");

	/*
	 * Get paramfile and map INT_BLOCK.
	 */
	paramfd = atoi(argv[1]);
	getparam(paramfd, &param);
	if((i_b= (INT_BLOCK_P)padr_map(&param.i_bl)) == -1) {
		fprintf(stderr, "Comm: cannot map INT_BLOCK\n");
		exit(1);
	}
	sigemptyset(&alert_set);
	sigaddset(&alert_set, S_ALERT);	    /* set up signal mask for alert */
	signal(S_ALERT, alert);		/* ip communication signal */
	signal(S_DEBUG_PRINT, doutput);

	/*
	 * Make comm's ptbl entry.  NOTE:  comm must always be ptbl[0].
	 */
	comm_p= &PT[0];
	*(comm_p)= zerop;
	comm_p->p_id= getpid();
	comm_p->p_sem= HIGHBIT;		/* init semaphore */
	myptx= 0;			/* comm is always 0 */
	myptp= comm_p;
#ifdef NEED_FAR
	_fstufs("comm", comm_p->p_name, &comm_p->p_name[P_LPROCNAME]);
	_fstufs(version, comm_p->p_version, &comm_p->p_version[P_LVERSION]);
#else
	stufs("comm", comm_p->p_name, &comm_p->p_name[P_LPROCNAME]);
	stufs(version, comm_p->p_version, &comm_p->p_version[P_LVERSION]);
#endif
	p_err= &p_rxerr;	/* init error reporting function */
	getnames(comm_p);
	nproc++;
	rsproc(comm_p, 'r');
	rsproc(newproc("scribe"), 'r');		/* start scribe and disp */
	rsproc(newproc("disp"), 'r');

	signal(S_CNTRLB, oncntrlb);		/* setup signals */
#ifdef GOO
	signal(S_CNTRLC, SIG_IGN);
#endif
#ifdef PDP11_TRAP
	signal(S_RTERR, onrterr);	/* real-time interrupt error */
#endif
	setjmp(env);

	/*
	 * Init screen.
	 */
	if( ! (sysflags & C_QUIT)) n_tty("r", "");

	if(ljval == 1) {
		rxerr("main(): Real-time interrupt error, type 'error rex'");
		ljval= 0;
	}

	/*
	 * Loop processing commands one line at a time.
	 */
	while( ! (sysflags & C_QUIT)) {
		if(echo) tputs(prompt);
		p_cmd();		/* process new command line */
		status( (echo && (rerr_erase++ == ERASECNT) ? 1 : 0) );
	};

	/*
	 * Kill all processes and restore screen.
	 */
	endproc(NP);
	tsetsc(0, 0);
	thome_;
	teall_;
	tflush_;
	fclose(errout);
	mxinit(0);
}

/*
 * Rex processes ignore cntlc.  Cntlb resets interprocess comm.
 * All processes return to a quiescent state.
 * This means that cntlb should not be typed during shell escapes.
 */
void
oncntrlb(int sig)
{
	PROCTBL_P cp= COMM;
	char c[20];
	int tmp;

	tmp= sig;
	signal(S_CNTRLB, oncntrlb);
	cp->p_state |= P_NOSIG_ST;	/* stop IPC */
	cp->p_msg= cp->p_vindex= cp->p_rmask= 0;
	cp->p_sem= HIGHBIT;
	sysflags= 0;
	i_b->c_flags= 0;
	tputs("\nDo you want to exit REX (y == yes) ? ");
	read(0, &c, 20);
	if(c[0] == 'y') {
		sysflags |= C_QUIT;
		longjmp(env, 0);
	}
	cp->p_state &= ~P_NOSIG_ST;

	longjmp(env, 0);
}

#ifdef PDP11_TRAP
/*
 * Trap types.  Encoded in low 5 order bits of rt_eps.
 */
char *ttypes[]=
"bus error (4)",			/* 0 */
"illegal instruction (010)",		/* 1 */
"bpt-trace trap (014)",			/* 2 */
"iot (020)",				/* 3 */
"power fail (024)",			/* 4 */
"emt (030)",				/* 5 */
"system call (034)",			/* 6 */	
"mem err or pirq (0114 or 0240)",	/* 7 */
"floating point (0244)",		/* 8 */
"segmentation violation (0250)",	/* 9 */
"",					/* 10 */
"",					/* 11 */
"",					/* 12 */
"",					/* 13 */
"empty unitialized vector",		/* 14 */
"trap through 0";			/* 15 */

/*
 * If an error occurs from the real-time interrupt routine, the kernel
 * will send the S_RTERR signal to comm.  Catch signal and reset the
 * world.  Pick up info about error and store in error file.
 */
void
onrterr(void)
{
	register PROCTBL_P cp= COMM;
	register PROCTBL_P p;
	struct rt_attarg att;
	struct rt_attarg *ap= &att;
	struct rt_err err;
	register struct rt_err *ep= &err;

	signal(S_RTERR, 1);	/* ignore till done */

	/*
	 * Reset myself.
	 */
	cp->p_state |= P_NOSIG_ST;	/* stop IPC */
	cp->p_msg= cp->p_vindex= cp->p_rmask= 0;
	cp->p_sem= HIGHBIT;
	sysflags= 0;
	i_b->c_flags= 0;
	cp->p_state &= ~P_NOSIG_ST;

	/*
	 * Pick up info about error and place in error file.
	 */
	ap->rt_auadd= ep;
	ap->rt_amode= RT_GETERR;
	if(attach(ap) == -1) printf("comm, onrterr(): cannot attach\n");
	fprintf(errout, "\nInterrupt error type: ");
	switch(ep->rt_etype) {
		case RT_ETRAP:
			fprintf(errout, "Trap- %s\n",
				 ttypes[ep->rt_enps & 017]);
			break;
		case RT_EK6:
			fprintf(errout, "Kernel stack exceeded.\n");
			break;
		case RT_ESIGST:
			fprintf(errout, "Signal request stack exceeded.\n");
			break;
		default:
			fprintf(errout, "Unknown type.\n");
			break;
	}
	fprintf(errout, "Int process PC at time of error %o\n", ep->rt_epc);
	fprintf(errout, "Registers (0-5): 0%o 0%o 0%o 0%o 0%o 0%o\n",
		ep->rt_ereg[0], ep->rt_ereg[1], ep->rt_ereg[2],
		ep->rt_ereg[3], ep->rt_ereg[4], ep->rt_ereg[5] );
	fprintf(errout, "new ps in vector %o, ps at time of error %o\n", 
		ep->rt_enps, ep->rt_eps);
	fprintf(errout, "Sup r6 %o, pid %d, level %d, intcnt %d\n",
		ep->rt_er6, ep->rt_epid, ep->rt_elevel, ep->rt_eintcnt);
	fprintf(errout, "sigreq %d, sigp %o\n", ep->rt_esigreq, ep->rt_esigp);
	fflush(errout);

	/*
	 * Broadcast control B signal to other running REX processes.
	 */
	for(p= &PT[0]; p < &PT[P_NPROC]; p++) {
		if(p == cp) continue;		/* skip myself */
		if(p->p_id && (p->p_state & P_RUN_ST)) {
			kill(p->p_id, S_CNTRLB);
		}
	}
	sleep(2);	/* give some time for them to process cntl B */

	signal(S_RTERR, onrterr);
	ljval= 1;
	longjmp(env, 1);
}

/*
 * Dummy function needed because of attach call used in above function.  Will
 * not be called since comm only picks up errors and doesnt attach.
 */
rt_int(nps)
{
	rt_ret(0, 0);
}

#endif	    /* PDP11_TRAP */

/*
 * Process command input line.
 */
int
p_cmd(void)
{
	PROCTBL_P p;
	int cnt;
	char *dx;
	int err;
	char is[P_ISLEN], nts[P_ISLEN];
	char *argv[P_NARG], *ntargv[P_NARG];

	/*
	 * Get line of input terminated by nl.
	 */
	if((cnt= tgetl(is, &is[P_ISLEN])) < 0) return(-1);
	if(cnt == 0 && infd != 0) {

		/*
		 * If cnt == 0 and reading from root then root is
		 * finished;  close root file.
		 */
		rtreof();
		return(0);
	}

	/*
	 * Input string is parsed twice:  once with null termination and
	 * once without.  Segments of the copy without null termination may then
	 * be passed on as the argstring to subsequent noun, verb processing.
	 */
	stufs(is, nts, &nts[P_ISLEN]);
	cnt= parse(1, nts, ntargv, P_NARG);
	if( (parse(0, is, argv, P_NARG) < 0) || cnt < 0 ) {
		rxerr("p_cmd(): Error on parse of input line");
		return(-1);
	}
	if(cnt == 0) return(0);			/* nothing */
	if(*ntargv[0] == '!') {			/* escape to shell */
		if(ntargv[0][1] != '\0') esc_unix(&argv[0][1]);
		return(0);
	}

	/*
	 * Check first for menu name: 'menuname.process argstr'.  Look
	 * for either a single token (no argstr) or a dot in the first
	 * token.  Note:  order of eval of or's important:  function must
	 * be leftmost or it might not be called if preceding terms satisfy
	 * the if statement.
	 */
	if( ((dx= index_RL('.', ntargv[0])) != NP) || cnt == 1 ) {

	    p= NP;
	    if(dx != NP) {
		if(*(dx+1) != '\0') {
		    if((p= getptp(dx+1)) == NP) {

		    badpname:
			rxerr("p_cmd(): Bad process name");
			return(-1);
		    }
		}
		*dx= '\0';
	    }
	    if((err= sendnm(p, ntargv[0], NS, (cnt > 1 ? argv[1] : NS), 1))
			< 0) {

	    badmname:
		if(err == -1) rxerr("p_cmd(): Bad menu name");
		return(-1);
	    } else return(0);		/* done */

	}

	/*
	 * Check next for 'verb noun.process argstr'.
	 * If a '.' is present second arg must be a valid noun.
	 */
	p= NP;
	if((dx= index_RL('.', ntargv[1])) != NP) {
	    if(*(dx+1) != '\0')
		if((p= getptp(dx+1)) == NP) goto badpname;
	    *dx= '\0';
	}
	if((err= sendnm(p, ntargv[1], ntargv[0], (cnt > 2 ? argv[2] : NS), 1))
			< 0) {

		/*
		 * Error return of -2 indicates error was in sendmsg(), which
		 * calls rxerr().  In this case simply return.
		 */
		if(err == -2) return(-1);
		if((p != NP) || (dx != NP)) {
			if(err == -1) rxerr("p_cmd(): Bad noun");
			return(-1);
		}
	} else return(0);

	/*
	 * Lastly check for 'menuname argstr' with no '.' or '.process'.
	 */
	if((err= sendnm(NP, ntargv[0], NS, (cnt > 1 ? argv[1] : NS), 1))
		>= 0) return(0);	/* done */
	goto badmname;
}

/*
 * Escape to unix.
 */
esc_unix(s)
char *s;
{
	int pid, status, wret;

	if((pid= fork()) == 0) {
		execl("/bin/sh", "sh", "-c", s, 0);
		_exit(127);
	}
	for(;;) {
		wret= wait(&status);
		if(wret == pid) break;
		if(wret == -1) {
			status= wret;
			break;
		}
	}
	return(status);
}
