/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government.  The original
 * versions, REX 1.0-3.12, were developed for the pdp11 architecture and
 * distributed without restrictions.  This version, REX 4.0, is a port of
 * the original version to the Intel 80x86 architecture.  This version is
 * distributed only under license agreement from the National Institutes 
 * of Health, Laboratory of Sensorimotor Research, Bldg 10 Rm 10C101, 
 * 9000 Rockville Pike, Bethesda, MD, 20892, (301) 496-9375.
 *-----------------------------------------------------------------------*
 */

/*
 * Process control.
 */

#include <sys/types.h>
#include <sys/wait.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <process.h>
#include <signal.h>
#include "../hdr/sys.h"
#include "../hdr/proc.h"
#include "../hdr/buf.h"
#include "../hdr/phys.h"
#include "../hdr/tty.h"
#include "../hdr/comm.h"

#undef  A_DEBUG		    /* define for debugging info */

/*
 * Process verbs for noun "process".
 */
void
n_proc(char *vstr, char *astr)
{
	PROCTBL_P p;

	switch(*vstr) {

	case 'l':	/* load a new process (but dont run) */
		newproc(astr);
		break;
	case 'k':	/* kill process */
		if(rsproc( p= getptp(astr), 's')) return;
		endproc(p);
		break;
	case 'r':	/* run a process (do a load if necessary) */
		if( (p= getptp(astr)) == NP) p= newproc(astr);
		if(p != NP) rsproc(p, 'r');
		break;
	case 's':	/* stop a process */
	case 'e':
		rsproc( getptp(astr), 's');
		break;
	case 't':	/* type list of proc names */
		tproc();
		break;
	case 'c':

		/*
		 * Change int process- stop current int process and run
		 * another one.  If either A or E data is being saved
		 * it is set to ignore.
		 */
		if(i_b->i_flags & I_EOUT)
		    sendnm(NP, "Edata", "i", NS, 0);
		if(i_b->i_flags & I_AOUT)
		    sendnm(NP, "Adata", "i", NS, 0);
		if(i_b->i_flags & I_GO)
			sendnm(NP, "clock", "e", NS, 0);
		if(i_b->disp_pi >= 0) {
			if(i_b->d_flags & D_SCACT) {
				sendnm(NP, "dsplay", "c", NS, 0);
			}
		}

		if(i_b->int_pi > 0)
			if(rsproc(&PT[i_b->int_pi], 's')) break;
		if((p= getptp(astr)) == NP) p=newproc(astr);
		if(p == NP) break;
		if(rsproc(p, 'r')) break;
		if(i_b->int_pi > 0)
			sendnm(NP, "statelist", "r", NS, 0);
		break;

	case 'd':	/* debug: print proc table */
		pproc();
		break;
	default:
		badverb();
		break;
	}
}

/*
 * Create a new process.
 */
PROCTBL_P
newproc(char *name)
{
	int z;
	PROCTBL_P p;
	int time, status;

	if(*name == '\0') {
		rxerr("newproc(): Bad process name");
		return(NP);
	}

	/*
	 * Find empty slot.
	 */
	for(p= &PT[0]; p->p_id != 0; ) {
		if(++p == &PT[P_NPROC]) {
			rxerr("newproc(): Process table overflow");
			return(NP);
		}
	}
	if (nnoun == P_NNOUN) {
		rxerr("newproc(): Noun table overflow");
		return(NP);
	}

	*p= zerop;		/* clear entry */
	p->p_sem= HIGHBIT;	/* init sem */
	sysflags &= ~ (C_SENDNAME | C_BADCHILD);
	if(getptp(name) != NP) {
		rxerr("newproc(): Process of same name already loaded");
		return(NP);
	}
#ifdef NEED_FAR
	_fstufs(name, p->p_name, &p->p_name[P_LPROCNAME]);
#else
	stufs(name, p->p_name, &p->p_name[P_LPROCNAME]);
#endif
	sysflags |= C_NAMERDY;		/* ok to accept nouns, menus */

	/*
	 * Fork and exec process and check for errors.
	 */
	z= crproc(p, paramfd);
	if (z < 0) {

		/*
		 * Failure of pipe or fork.
		 */
		if (z == -1) {
			rxerr("newproc(): Cannot make pipes and/or fork");
			sysflags &= ~C_NAMERDY;
			return(NP);
		}

		/*
		 * Child process- error on exec.  Signal comm and exit.
		 */
		else {
			sendmsg(COMM, CM_BADCHILD);
			exit(0);
		}
	}

	/*
	 * Wait until child sends msg that it's ready to send nouns.
	 * Check for time out of 10 seconds.
	 */
	for(time= 0;;time++) {
		if(sysflags & C_SENDNAME) break;
		if(sysflags & C_BADCHILD || time >= 10) {
			if(sysflags & C_BADCHILD)
				rxerr("newproc(): Bad process, cannot run");
			else rxerr("newproc(): Timeout waiting for names");

			/*
			 * Clean up and kill bad child.
			 */
			sysflags &= ~C_NAMERDY;
			close(p->p_pipe[0]);
			close(p->p_pipe[1]);
			if(kill(p->p_id, 9) >= 0) wait(&status);
			p->p_id= 0;		/* free entry */
			return(NP);
		}
		sleep(1);
	}
	getnames(p);
	nproc++;		/* advance process count */
	return(p);
}

/*
 * Kill REX process.  If p == NP kill all processes.
 */
void
endproc(PROCTBL_P p)
{
	PROCTBL_P ep;
	PROCTBL_P bp;
	NAME *np;
	int etime;
	int status;
	char s[P_ISLEN];

	if(p != NP) {
		bp= p;
		ep= p + 1;
	} else {
		bp= &PT[0];
		ep= &PT[P_NPROC];
	}

	/*
	 * Send message to process to terminate.  If for some reason process
	 * is unable to comply kill it.
	 */
	for(etime= 0; ; etime++) {
	    for(p= bp; p < ep; p++) {
		if(p->p_id == 0) continue;
		if(p == COMM) continue;
		if(etime == 0) {	/* first pass:  send kill message */
		    sendmsg(p, G_KILL);
		    continue;
		}
		if(p->p_state & P_EXIT_ST) {

		    /*
		     * Remove process' nouns and menus.
		     */
		    for(np= p->p_nounp; np != NP; np= np->na_nextn) {
			np->na_pp= NP;
			nnoun--;
		    }
		    for(np= p->p_menup; np != NP; np= np->na_nextn) {
			np->na_pp= NP;
			nmenu--;
		    }
		    p->p_id= 0;
		    nproc--;
		    wait(&status);	/* remove DEAD entry from UNIX
					   process table */
		    continue;
		}
		if(etime >= P_EXWAIT) {
#ifdef NEED_FAR
		    char tmp[P_LPROCNAME];

		    _fstrncpy(tmp, p->p_name, P_LPROCNAME);
		    sprintf(s, "endproc(): Explicitly killing %s",
			tmp);
#else
		    sprintf(s, "endproc(): Explicitly killing %s",
			p->p_name);
#endif
		    rxerr(s);
		    p->p_state |= P_EXIT_ST;
		    if(kill(p->p_id, 9) >= 0) wait(&status);
		} else break;
	    }
	    if( (p == ep) && etime ) break;	/* done */
	    if(etime) sleep(1);
	}
}


/*
 * Type list of loaded processes.
 */
void
tproc(void)
{
	int i= 0;
	PROCTBL_P p;

	for(p= &PT[0]; p < &PT[P_NPROC]; p++) {
	    if(p->p_id) {
#ifdef NEED_FAR
		char tmp1[P_LPROCNAME];
		char tmp2[P_LVERSION];
#endif

		i++;
#ifdef NEED_FAR
		_fstrncpy(tmp1, p->p_name, P_LPROCNAME);
		_fstrncpy(tmp2, p->p_version, P_LVERSION);
		printf("%-15s%-10sVer %-21s%d\n",
			tmp1,
			(p->p_state & P_RUN_ST ?"running" : "stopped"),
			tmp2,
			p->p_id);
#else
		printf("%-15s%-10sVer %-21s%d\n",
			p->p_name,
			(p->p_state & P_RUN_ST ?"running" : "stopped"),
			p->p_version,
			p->p_id);
#endif
	    }
	}
	printf("\n%d currently loaded processes, space remaining for %d more\n",
		i, P_NPROC - i);
	tflush_;
}

/*
 * Get pointer to proc table entry.
 */
PROCTBL_P
getptp(char *name)
{
	PROCTBL_P p;

	for(p= &PT[0]; p < &PT[P_NPROC]; p++) {
		if(p->p_id == 0) continue;
#ifdef NEED_FAR
		if(_fstrcmp(name, p->p_name) == 0) break;
#else
		if(strcmp(name, p->p_name) == 0) break;
#endif
	}
	if(p == &PT[P_NPROC]) {

		/*
		 * Check for ".int", the default for the current
		 * int process.
		 */
		if((strcmp(name, "int") == 0)
		&& (i_b->int_pi >= 0)) p= &PT[i_b->int_pi];
		else p= NP;
	}
	return(p);
}

/*
 * Set process to run or stop state.
 */
int
rsproc(PROCTBL_P p, char state)
{
	int rs;

	if(p == NP) {
		rxerr("rsproc(): Bad process name");
		return(-1);
	}
	if(state == 'r') {
		if(p->p_state & P_RUN_ST) return(0);
		if(p == COMM) {		/* no handshaking necessary */
			p->p_state |= P_RUN_ST;
			return(0);
		}
		clrack_;
		if(sendmsg(p, G_RUN)) return(-1);	/* proc is dead */
#ifdef A_DEBUG
dputs("-rsproc: before wack:run-");
#endif
		if(rs= waitack(1, S_ALERT)) {
		    if(rs == -1)
			rxerr("rsproc(): Process denies run request");
		    return(-1);
		}
#ifdef A_DEBUG
dputs("-rsproc: after wack:run-");
#endif
		p->p_state |= P_RUN_ST;
		return(0);
	}
	if(state == 's') {
		if( ! (p->p_state & P_RUN_ST)) return(0);
		if(p == COMM) {
			p->p_state &= ~P_RUN_ST;
			return(0);
		}
		clrack_;
		if(sendmsg(p, G_STOP) == 0) {
#ifdef A_DEBUG
dputs("-rsproc: before wack: stop-");
#endif
		    if((rs= waitack(1, S_ALERT)) == -1) {
			rxerr("rsproc(): Process denies stop request");
			return(-1);
		    }
#ifdef A_DEBUG
dputs("-rsproc: after wack: stop-");
#endif
		    p->p_state &= ~P_RUN_ST;
		    if(rs == -2) return(-1);
		    return(0);
		} else {
		    p->p_state &= ~P_RUN_ST;
		    return(-1);
		}
	}
}

/*
 * Fork and exec a new REX process.  Returns:
 *	new process id if successful
 *	-1 for failure of parent to open pipes
 *	-2 for failure of child
 */
int
crproc(PROCTBL_P p, int paramfd)
{
	int z, pindex;
#define CRP_SSIZ 10
	char pfd_asc[CRP_SSIZ], ptx_asc[CRP_SSIZ];
#ifdef NEED_FAR
	int ptmp[2];
	char ntmp[P_LPROCNAME];

	if(pipe(ptmp) < 0) return(-1);
	p->p_pipe[0]= ptmp[0], p->p_pipe[1]= ptmp[1];
#else    
	if(pipe(&p->p_pipe) < 0) return(-1);
#endif
	if((z = fork()) == -1) {

		/*
		 * Cant fork.
		 */
		close(p->p_pipe[0]);
		close(p->p_pipe[1]);
		return(-1);
	}

	if (z == 0) {	/* child process */

		/*
		 * Have to send index to ptbl, not pointer.  Proc
		 * may map I_B with another register.
		 * Also fill in pid in proc array for child;  it may
		 * run before the parent and might need its pid before
		 * the parent could copy it in.
		 */
		p->p_id= getpid();
		pindex= p - &PT[0];
		itoa_RL(pindex, 'd', ptx_asc, &ptx_asc[CRP_SSIZ]);
		itoa_RL(paramfd, 'd', pfd_asc, &pfd_asc[CRP_SSIZ]);
#ifdef NEED_FAR
		_fstrcpy(ntmp, p->p_name);
		if(execl(ntmp, ntmp, pfd_asc, ptx_asc, 0) < 0) {
#else
		if(execl(p->p_name, p->p_name, pfd_asc, ptx_asc, 0) < 0) {
#endif
			close(p->p_pipe[0]);
			close(p->p_pipe[1]);
			return(-2);
		}
	}
	else return(z);
}

/*
 * Print entire proc table for debugging purposes.
 */
void
pproc(void)
{
	PROCTBL_P p;
	int i= 0;
#ifdef NEED_FAR
	char tmp_pn[P_LPROCNAME];
	char tmp_vr[P_LVERSION];
	char tmp_er[P_ISLEN];
#endif


	for(p= &PT[0]; p < &PT[P_NPROC]; p++, i++) {
	    printf("Proctbl[%d]: ", i);
	    if(p->p_id) {
	    	printf("state %o, sem %o, msg %o, rmask %o\n", p->p_state,
	    		p->p_sem, p->p_msg, p->p_rmask);
	    	printf("nounp %o, menup %o, vindex %o\n", p->p_nounp,
	    		p->p_menup, p->p_vindex);
#ifdef NEED_FAR
		_fstrncpy(tmp_pn, p->p_name, P_LPROCNAME);
		_fstrncpy(tmp_vr, p->p_version, P_LVERSION);
	    	printf("%s %s\n", tmp_pn, tmp_vr);
#else
	    	printf("%s %s\n", p->p_name, p->p_version);
#endif
	    } else printf("Unallocated.\n");
	}
	
	printf("comm sysflags %o, nproc %d, nnoun %d, nmenu %d\n",
		sysflags, nproc, nnoun, nmenu);
	printf("rtflag %0, rtlevel %d, errnum %d\n", rtflag, rtlevel, errnum);
	printf("c_flags %o, i_flags %o, d_flags %o,\n",
		i_b->c_flags, i_b->i_flags, i_b->d_flags);
	printf("rtflag %o, rtcx %d, rtseek %d, rtcln %d\n",
		i_b->i_rtflag, i_b->i_rtcx, i_b->i_rtseekp, i_b->i_rtcln);
#ifdef NEED_FAR
	_fstrncpy(tmp_er, i_b->i_errstr, P_ISLEN);
	printf("errptx %o, errst: %s\n", i_b->i_errptx, tmp_er);
#else
	printf("errptx %o, errst: %s\n", i_b->i_errptx, i_b->i_errstr);
#endif
	printf("ptbl base %o, size %d, int_pi %o, scrb_pi %o, disp_pi %o\n",
		&i_b->ptbl, sizeof(PROCTBL), i_b->int_pi, i_b->scrb_pi,
		i_b->disp_pi); 

	tflush_;
}
