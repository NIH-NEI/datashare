/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government.  The original
 * versions, REX 1.0-3.12, were developed for the pdp11 architecture and
 * distributed without restrictions.  This version, REX 4.0, is a port of
 * the original version to the Intel 80x86 architecture.  This version is
 * distributed only under license agreement from the National Institutes 
 * of Health, Laboratory of Sensorimotor Research, Bldg 10 Rm 10C101, 
 * 9000 Rockville Pike, Bethesda, MD, 20892, (301) 496-9375.
 *-----------------------------------------------------------------------*
 */

#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "../hdr/sys.h"
#include "../hdr/proc.h"
#include "../hdr/buf.h"
#include "../hdr/tty.h"
#include "../hdr/comm.h"

/*
 * Noun processing for comm.
 */

/*
 * Process verbs for noun "tty".
 */
#pragma off (unreferenced)
void
n_tty(char *vstr, char *astr)
{
#pragma on (unreferenced)

	switch(*vstr) {
	case 'r':		/* reset and reinitialize */
		tansi_;
		teall_;
		tuloff_;
		tsetsc(T_SCTOP, T_SCBOT);
		ttop_;
		tflush_;
		status(2);
		break;
	case 's':	/* set */
	case 'c':	/* clear */
		tescroll_;
		tflush_;
		status(1);
		break;
	default:
		badverb();
		break;
	}
}

/*
 * Process verbs for noun "name".
 */
void
n_name(char *vstr, char *astr)
{
	switch(*vstr) {
	case 't':	/* type list of names */
	    if(*astr == '\0' || *astr == 'm') {
		fputs("\n				MENUS", stdout);
		tname('m');
	    }
	    if(*astr == '\0' || *astr == 'n') {
		fputs("\n				NOUNS", stdout);
		tname('n');
	    }
	    break;
	default:
		badverb();
		break;
	}
}

/*
 * Process verbs for noun 'rex'.
 */
#define BUFSIZ_RL 512
#pragma off (unreferenced)
int
n_rex(char *vstr, char *astr)
{
#pragma on (unreferenced)
	int fd;
	char buf[BUFSIZ_RL];
	int count;
	char *sp;

	switch(*vstr) {
	case 'h':	/* help */
	case 'e':	/* errors */
		if(*vstr == 'e') sp= "/tmp/rxerr";
		else sp= "help";
		if( (fd=open(sp,0)) == -1) {
			rxerr("n_rex(): Cannot open requested file");
			return(-1);
		}
		while((count=read(fd, buf, BUFSIZ_RL)) > 0) write(1, buf, count);
		close(fd);
		break;

	case 'q':	/* quit */
		if(i_b->i_flags & I_GO) {
			rxerr("n_rex(): End clock before quitting");
			break;
		}
		sysflags |= C_QUIT;
		break;
	default:
		badverb();
		break;
	}
}

/*
 *	Type trial totals.
 */
#pragma off (unreferenced)
void
n_trials(char *vstr, char *astr)
{
#pragma on (unreferenced)

	switch(*vstr) {
	case 't':
		printf("Total trial data for all paradigms:\n");
		printf("Correct %d, wrong %d, total %d\n",
			i_b->inthdr.i_correct, i_b->inthdr.i_wrong,
			i_b->inthdr.i_correct + i_b->inthdr.i_wrong);
		tflush_;
		break;
	case 'c':
		i_b->inthdr.i_correct= i_b->inthdr.i_wrong= 0;
		printf("Trial totals cleared.\n");
		tflush_;
		break;
	default:
		badverb();
		break;
	}
}

/*
 * Process verbs for noun "print_debug".
 * Sends signal "S_DEBUG_PRINT" to specified process to print out
 * contents of inmemory debug buffer.
 */
#pragma off (unreferenced)
void
n_debug(char *vstr, char *astr)
{
#pragma on (unreferenced)

	PROCTBL_P p;
	
	/*
	 * Takes arguments "comm", "scribe", "disp", "int".
	 */
	switch(*vstr) {
	case 'c':
	    p= COMM;
	    break;
	case 's':
	    p= SCRB;
	    break;
	case 'd':
	    p= DISP;
	    break;
	case 'i':
	    p= INT;
	    break;
	default:
	    badverb();
	    return;
	}
	kill(p->p_id, S_DEBUG_PRINT);
}
