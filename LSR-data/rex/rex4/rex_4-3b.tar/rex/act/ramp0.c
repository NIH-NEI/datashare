/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government.  The original
 * versions, REX 1.0-3.12, were developed for the pdp11 architecture and
 * distributed without restrictions.  This version, REX 4.0, is a port of
 * the original version to the Intel 80x86 architecture.  This version is
 * distributed only under license agreement from the National Institutes 
 * of Health, Laboratory of Sensorimotor Research, Bldg 10 Rm 10C101, 
 * 9000 Rockville Pike, Bethesda, MD, 20892, (301) 496-9375.
 *-----------------------------------------------------------------------*
 */

/*
 * Actions to control ramp generator.
 */
#include <stdio.h>
#include <i86.h>
#include <sys/types.h>
#include "../hdr/sys.h"
#include "../hdr/cnf.h"
#include "../hdr/proc.h"
#include "../hdr/buf.h"
#include "../hdr/menu.h"
#include "../hdr/device.h"
#include "../hdr/ramp.h"
#include "../hdr/ecode.h"
#include "../hdr/int.h"

/*
 * Specify new ramp.  Since this call uses 7 args it cannot currently 
 * be called as an action, but must be called from an action.
 */
int
ra_new(int len, int ang, int vel, int xoff, int yoff, int ecode, int type)
{
	int menu= m_ramenu;

	_disable();
	if(menu && (m_ralen != NULLI)) ra_len= m_ralen;
	else if(len != NULLI) ra_len= len;
	if(menu && (m_raang != NULLI)) ra_ang= m_raang;
	else if(ang != NULLI) ra_ang= ang;
	if(menu && (m_ravel != NULLI)) ra_vel= m_ravel;
	else if(vel != NULLI) ra_vel= vel;
	if(menu && (m_raxoff != NULLI)) ra_xoff= m_raxoff;
	else if(xoff != NULLI) ra_xoff= xoff;
	if(menu && (m_rayoff != NULLI)) ra_yoff= m_rayoff;
	else if(yoff != NULLI) ra_yoff= yoff;
	if(menu && (m_ecode != NULLI)) ra_ecode= m_ecode;
	else if(ecode != NULLI) ra_ecode= ecode;
	if(menu && (m_type != NULLI)) ra_type= m_type;
	else if(type != NULLI) ra_type= type;
	_enable();
	return(0);
}

/*
 * Cause the computation of parameters for a ramp.  This action doesnt
 * start the ramp.  When ramp computation is completed, RA_CDONE is set
 * in rampflag.
 */
int
ra_compute(void)
{
	rampflag= 0;		/* essential- next state will be testing
				   for RA_CDONE probably */
	rcompute();
	return(0);
}

/*
 * Initiate ramp.  If flag is true there will be a 40msec delay after the
 * mirrors move to the starting position to allow them to settle.  Also,
 * if ra_type & RA_NO25MS is not true, there will be a 25msec acceleration
 * start up time.  In any case RA_STARTED is set in rampflag when the
 * ramp has started and is over the start position, taking into account
 * any of the aforementioned delays.  At this point, for example, the
 * light on the mirror can be turned on.
 * Arguemnt 'device' is a device to turn off when the ramp completes.  If
 * 0 it is ignored.
 */
int
ra_start(long flag, DIO_ID device)
{
	ra_device= device;
	if(flag) ra_state= RA_DELST;
	else ra_state= RA_NODEL;
	return(0);
}

/*
 * Stop ramp.  If flag is true, return mirrors to 0,0.
 */
int
ra_stop(long flag)
{
	int returncd= 0;

	rampflag &= ~RA_STARTED;
	if(ra_state != RA_OFF) {
		ra_state= RA_OFF;
		ra_timeleft= 0;
#ifdef RA_PHI
		ra_phiflag =& ~RA_PHIGO;
#endif
		if(ra_device) dio_off(ra_device);
		returncd= RDONECD;
	}
	if(flag) {
		mr_mov(0,0);
	}
	return(returncd);
}

/*
 *	Called to move mirrors to starting position of next ramp.
 */
int
ra_tostart(void)
{
	if(ra_state != RA_OFF) ra_stop(0);
	mr_mov(ra_x.ra_pos, ra_y.ra_pos);
	return(0);
}

/*
 *	Used to control phi tracking paradigms.  Switches
 * ra_device to phi device and starts phi blinking.
 */
#ifdef CC_RAPHI
int
phistart(void)
{
	ra_device= ra_phidev;
	ra_phiflag |= RA_PHIGO;
	return(0);
}

/*
 *	Ends phi blinking.
 */
int
phiend(void)
{
	ra_phiflag &= ~RA_PHIGO;
	dio_off(ra_device);
	return(0);
}
#endif
