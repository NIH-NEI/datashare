/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government.  The original
 * versions, REX 1.0-3.12, were developed for the pdp11 architecture and
 * distributed without restrictions.  This version, REX 4.0, is a port of
 * the original version to the Intel 80x86 architecture.  This version is
 * distributed only under license agreement from the National Institutes 
 * of Health, Laboratory of Sensorimotor Research, Bldg 10 Rm 10C101, 
 * 9000 Rockville Pike, Bethesda, MD, 20892, (301) 496-9375.
 *-----------------------------------------------------------------------*
 */

/*
 * Action to specify eye offsets.
 */
#include <stdio.h>
#include <i86.h>
#include <sys/types.h>
#include "../hdr/sys.h"
#include "../hdr/cnf.h"
#include "../hdr/proc.h"
#include "../hdr/buf.h"
#include "../hdr/menu.h"
#include "../hdr/device.h"
#include "../hdr/int.h"

int
off_oeye(long hoff, long voff)
{
	int menu= m_offmenu;

	_disable();
	if(menu && (m_oeho != NULLI)) oeho= m_oeho << TEN_TO_IC;
	else if(hoff != NULLI) oeho= hoff << TEN_TO_IC;
	if(menu && (m_oevo != NULLI)) oevo= m_oevo << TEN_TO_IC;
	else if(voff != NULLI) oevo= voff << TEN_TO_IC;
	_enable();
	return(0);
}
