/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government.  The original
 * versions, REX 1.0-3.12, were developed for the pdp11 architecture and
 * distributed without restrictions.  This version, REX 4.0, is a port of
 * the original version to the Intel 80x86 architecture.  This version is
 * distributed only under license agreement from the National Institutes 
 * of Health, Laboratory of Sensorimotor Research, Bldg 10 Rm 10C101, 
 * 9000 Rockville Pike, Bethesda, MD, 20892, (301) 496-9375.
 *-----------------------------------------------------------------------*
 */

/*
 *	Actions used to control ramp durations.  One should study
 * a ramp paradigm to fully understand how these functions are used.
 */
#include <stdio.h>
#include <i86.h>
#include <sys/types.h>
#include "../hdr/sys.h"
#include "../hdr/cnf.h"
#include "../hdr/proc.h"
#include "../hdr/buf.h"
#include "../hdr/menu.h"
#include "../hdr/state.h"
#include "../hdr/device.h"
#include "../hdr/ecode.h"
#include "../hdr/ramp.h"
#include "../hdr/int.h"

extern STATE stimeramp;

/*
 *	Computes time remaining until specified percentage of
 * ramp duration has elapsed.  Places correct preset and random
 * (if specified) in state called "timeramp".  This state should
 * be in a separate set that will set bit RA_TIMEDONE when time
 * has elapsed.  Then this flag can be tested by more than
 * one state.
 */
int
ramptset(long presetper, long randper)
{
	long lpreset, lrandom;
	unsigned preset, random;

	rampflag &= ~RA_TIMEDONE;
	presetper= 100 - presetper;
	lpreset= (long)presetper * ra_duration;
	preset= lpreset / 100;
	if(ra_timeleft <= preset) {	/* time has already elapsed */
		stimeramp.preset= 0;
		stimeramp.random= 0;
		rampflag |= RA_TIMESTART;	/* start timer state set */
		return(0);
	}
	stimeramp.preset= (ra_timeleft - preset) * ra_urate;
	if(randper) {
		lrandom= (long)randper * ra_duration;
		random= lrandom / 100;
		stimeramp.random= random * ra_urate;
	} else stimeramp.random= 0;
	rampflag |= RA_TIMESTART;
	return(0);
}

/*
 *	Function called from state set timing ramp to set RA_TIMEDONE
 * flag.  This bit is being tested by main paradigm state set.
 */
int
ramptd(void)
{
	rampflag |= RA_TIMEDONE;
	rampflag &= ~RA_TIMESTART;	/* stop state set until next time */
	return(0);
}
