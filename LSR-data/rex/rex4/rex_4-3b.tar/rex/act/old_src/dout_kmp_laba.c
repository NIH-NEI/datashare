/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government, is in the
 * public domain, and cannot be copywrited.  For further information
 * contact:  Laboratory of Sensorimotor Research, National Eye Institute,
 * National Institutes of Health, Bldg 10 Rm 6C420, Bethesda, MD, 20205.
 *-----------------------------------------------------------------------*
 */

#include <stdio.h>
#include <i86.h>
#include <conio.h>
#include <sys/types.h>
#include "../hdr/sys.h"
#include "../hdr/proc.h"
#include "../hdr/menu.h"
#include "../hdr/cnf.h"
#include "../hdr/device.h"

/*
 * Actions to control digital output interfaces.
 */

/*
 *-----------------------------------------------------------------------*
 *			Blue Box on DR11
 *-----------------------------------------------------------------------*
 */
/*
 * Action to turn blue box outputs on or off.  Must remember the state of
 * each card since ALL outputs are affected by an access.
 * Blue Box is connected to a DR11.
 */
#ifdef BBOX_DOUT

static int cards[] = {0,1 << 8,2 << 8,3 << 8,4 << 8, 5 << 8, 6<<8, 7 << 8,
	8 << 8, 9 << 8, 10 << 8};

int
doutaon(int x)
{
	int y;

	if (shorthi_(x) < sizeof(cards) / 2){
		y = cards[shorthi_(x)] |= shortlo_(x);
	}
#ifdef KMPIO12_DOUT
	    outp(KM1_PB, shorthi_(y));
	    outp(KM1_PA, shortlo_(y));
	    inp(KM1_PC);
	    outp(KM1_PC, 0x1);
	    inp(KM1_PC); inp(KM1_PC); inp(KM1_PC);
	    outp(KM1_PC, 0x0);
#endif
	return(0);
}

int
doutaoff(int x)
{
	int y;

	if ( shorthi_(x) < sizeof(cards) / 2) {
		y = cards[shorthi_(x)] &= ~(shortlo_(x));
	}
#ifdef KMPIO12_DOUT
	    outp(KM1_PB, shorthi_(y));
	    outp(KM1_PA, shortlo_(y));
	    inp(KM1_PC);
	    outp(KM1_PC, 0x1);
	    inp(KM1_PC); inp(KM1_PC); inp(KM1_PC);
	    outp(KM1_PC, 0x0);
#endif
	return(0);
}
#endif

