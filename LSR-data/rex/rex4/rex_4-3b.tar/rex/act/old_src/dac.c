/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government.  The original
 * versions, REX 1.0-3.12, were developed for the pdp11 architecture and
 * are in the public domain.  This version, REX 4.0, is a port of the
 * original version to the Intel 80x86 architecture.  This version is
 * copyright (C) 1992 by the National Institutes of Health, Laboratory
 * of Sensorimotor Research, Bldg 10 Rm 10C101, 9000 Rockville Pike,
 * Bethesda, MD, 20892, (301) 496-9375.  All rights reserved.
 *-----------------------------------------------------------------------*
 */

/*
 * dac.c  subroutines to control Grant 204A d/a board
 *   which has 8 bit i/o port which is bit selectable 
 *   input or output; make bits input by writing a 0 to them;
 *   make output by writing 1 to them.
 */

#include "../hdr/sys.h"
#include "../lhdr/cnf.h"
#include "../hdr/device.h"

#ifdef GT_204A
g204set()
{
	DAC_A->word = 0;
	DAC_B->word = 0;
	DAC_C->word = 0;
	DAC_D->word = 0;
	DAC_IOPT->word = 0;
	return(0);
}
#endif
