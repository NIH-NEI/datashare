/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government, is in the
 * public domain, and cannot be copywrited.  For further information
 * contact:  Laboratory of Sensorimotor Research, National Eye Institute,
 * National Institutes of Health, Bldg 10 Rm 6C420, Bethesda, MD, 20205.
 *-----------------------------------------------------------------------*
 */

/*
 * Specify control flag or absolute position of eye window.
 */

#include "../hdr/sys.h"
#include "cnf.h"
#include "../hdr/device.h"
#include "../hdr/ramp.h"
#include "../hdr/idsp.h"
#include "../hdr/int.h"

wd_set(ctlval, xpos, ypos)
{
	register int menu= m_wdmenu;
	register int saveps;
	register WINDISP *wp= &windisp[CU_WIND];

	saveps= PSW->word;
	spl7L_;
	if(menu && (m_wdxpos != NULLI)) wdxpos= m_wdxpos << TEN_TO_IC;
	else if(xpos != NULLI) wdxpos= xpos << TEN_TO_IC;
	if(menu && (m_wdypos != NULLI)) wdypos= m_wdypos << TEN_TO_IC;
	else if(ypos != NULLI) wdypos= ypos << TEN_TO_IC;
	if(menu && (m_wdctl != NULLI)) wdctl= m_wdctl;
	else if(ctlval != NULLI) wdctl= ctlval;

	if(wdctl == WD_OFF) {
		if(wp->wd_flag & WDI_ON) wp->wd_flag |= WDI_TURNOFF;
	} else {
	    switch(wdctl) {

	    case WD_MIR:		/* window follows current mir pos */
		wdxptr= &mrxcur;
		wdyptr= &mrycur;
		break;

	    case WD_APOS:	    /* window is at specified abs. coords. */
		wdxptr= &wdxpos;
		wdyptr= &wdypos;
		break;

#ifdef CC_RAMP
	    case WD_RAMP:		/* window follows output of ramp gen */
		wdxptr= &ra_x.ra_pos;
		wdyptr= &ra_y.ra_pos;
		break;
#endif

#ifdef CC_EXP
	    case WD_EXP:		/* window follows output of exp gen */
		break;
#endif

#ifdef CC_SINE
	    case WD_SIN:		/* window follows output of sin gen */
		break;
#endif

	    }

	    /*
	     * Turn on cursor if previously off.
	     */
	    if( ! (wp->wd_flag & WDI_ON)) wp->wd_flag |=(WDI_OLDINVALID|WDI_ON);
	}

	PSW->word= saveps;
	return(0);
}
