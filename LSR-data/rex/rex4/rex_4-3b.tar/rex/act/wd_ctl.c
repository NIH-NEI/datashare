/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government.  The original
 * versions, REX 1.0-3.12, were developed for the pdp11 architecture and
 * distributed without restrictions.  This version, REX 4.0, is a port of
 * the original version to the Intel 80x86 architecture.  This version is
 * distributed only under license agreement from the National Institutes 
 * of Health, Laboratory of Sensorimotor Research, Bldg 10 Rm 10C101, 
 * 9000 Rockville Pike, Bethesda, MD, 20892, (301) 496-9375.
 *-----------------------------------------------------------------------*
 */

/*
 * Action to specify control flag and type of eye windows.
 */
#include <stdio.h>
#include <i86.h>
#include <sys/types.h>
#include "../hdr/sys.h"
#include "../hdr/proc.h"
#include "../hdr/buf.h"
#include "../hdr/menu.h"
#include "../hdr/cnf.h"
#include "../hdr/device.h"
#include "../hdr/ramp.h"
#include "../hdr/idsp.h"
#include "../hdr/int.h"
#include "../hdr/cdsp.h"

/*
 * Display process needs to be notified if some of the bits
 * in d_wd_disp change.  The following mask determines which bits, if
 * changed, will cause notification.
 */
#define DISP_NOTIFY	(D_W_GRID|D_W_FRAME)

int
wd_ctl(long ctlval, long type, long disp)
{
	int menu= m_wdmenu;
	static int disp_sav;

	_disable();
	if(menu && (m_wdctl != NULLI)) wdctl= m_wdctl;
	else if(ctlval != NULLI) wdctl= ctlval;
	if(menu && (m_wdtype != NULLI)) wdtype= m_wdtype;
	else if(type != NULLI) wdtype= type;
	if(menu && (m_wddisp != NULLI)) i_b->d_wd_disp= m_wddisp;
	else if(disp != NULLI) i_b->d_wd_disp= disp;

        switch(wdtype) {

	    case WD_MIR:	    /* window follows current mir pos */
		wdxptr= &mrxcur;
		wdyptr= &mrycur;
		break;

	    case WD_APOS:	    /* window is at specified abs. coords. */
		wdxptr= &wdxpos;
		wdyptr= &wdypos;
		break;

#ifdef CC_RAMP
	    case WD_RAMP:	    /* window follows output of ramp gen */
		wdxptr= &ra_x.ra_pos;
		wdyptr= &ra_y.ra_pos;
		break;
#endif

	    case WD_JOY:	    /* window follows joystick */
		wdxptr= &joyh;
		wdyptr= &joyv;
		break;
        }

	/*
	 * Set cursors on/off.
	 */
	wd_scur(wdctl, i_b->d_wd_disp);

	/*
	 * See if disp needs to be notified.
	 */
	if(DISP_NOTIFY & (i_b->d_wd_disp ^ disp_sav)) {
	    disp_sav= i_b->d_wd_disp;	
	    _enable();
	    if(inside_int) to_disp_(DS_WDNEW);
	    else sendmsg(DISP, DS_WDNEW);
	} else {
	    disp_sav= i_b->d_wd_disp;	
	    _enable();
	}
	return(0);
}
