/*
 *-----------------------------------------------------------------------*
 * NOTICE:  This code was developed by the US Government.  The original
 * versions, REX 1.0-3.12, were developed for the pdp11 architecture and
 * distributed without restrictions.  This version, REX 4.0, is a port of
 * the original version to the Intel 80x86 architecture.  This version is
 * distributed only under license agreement from the National Institutes 
 * of Health, Laboratory of Sensorimotor Research, Bldg 10 Rm 10C101, 
 * 9000 Rockville Pike, Bethesda, MD, 20892, (301) 496-9375.
 *-----------------------------------------------------------------------*
 */

/*
 * Action to specify size of window for other eye.  Size is taken to be
 * distance in tenths of degree from center of window.
 */
#include <stdio.h>
#include <i86.h>
#include <sys/types.h>
#include "../hdr/sys.h"
#include "../hdr/cnf.h"
#include "../hdr/proc.h"
#include "../hdr/buf.h"
#include "../hdr/menu.h"
#include "../hdr/device.h"
#include "../hdr/idsp.h"
#include "../hdr/int.h"

int
wd_osiz(long xsiz, long ysiz)
{
	int menu= m_wdmenu;

	_disable();
	if(menu && (m_wdoxsiz != NULLI)) wdoxsiz= m_wdoxsiz << TEN_TO_IC;
	else if(xsiz != NULLI) wdoxsiz= xsiz << TEN_TO_IC;
	if(menu && (m_wdoysiz != NULLI)) wdoysiz= m_wdoysiz << TEN_TO_IC;
	else if(ysiz != NULLI) wdoysiz= ysiz << TEN_TO_IC;

	/*
	 * Cause cursor to be redrawn to new size.
	 */
	windisp[CU_OWIND].wd_flag |= WDI_NEWSIZ;

	_enable();
	return(0);
}
