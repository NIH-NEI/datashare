/* Y o u r   D e s c r i p t i o n                       */
/*                            AppBuilder Photon Code Lib */
/*                                         Version 1.14C */

/* Standard headers */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

/* Toolkit headers */
#include <Ph.h>
#include <Pt.h>
#include <Ap.h>

/* Local headers */
#include "ph_ras.h"
#include "abimport.h"
#include "proto.h"

extern LsrTig lsrTig;
extern int dataStarted;

int iconified = 0;

int manageWin( PtWidget_t *widget, ApInfo_t *apinfo, PtCallbackInfo_t *cbinfo )
{
	PtArg_t args[2];
	SELECTIONS *selections;
	PhWindowEvent_t *winEvent;
	int i;

	/* eliminate 'unreferenced' warnings */
	widget = widget, apinfo = apinfo, cbinfo = cbinfo;
	winEvent = (PhWindowEvent_t *)cbinfo->cbdata;

	switch(winEvent->event_f) {
	case Ph_WM_CLOSE:
		release_(&myptp->p_sem);
		myptp->p_state |= P_EXIT_ST;
		myptp->p_id = 0;
		exit(EXIT_SUCCESS);
		break;
	case Ph_WM_HIDE:
		if(iconified == 0) {
			iconified = 1;

			/* shut off raster processing */
			PtSetArg(&args[0], Pt_ARG_TIMER_INITIAL, 0, 0);
			PtSetArg(&args[1], Pt_ARG_TIMER_REPEAT, 0, 0);
			PtSetResources(ABW_rastersTimer, 2, args);
		}
		break;
	case Ph_WM_RESTORE:
	case Ph_WM_RESIZE:
	case Ph_WM_MAX:
		iconified = 0;

		/* turn on raster processing  */
		PtSetArg(&args[0], Pt_ARG_TIMER_INITIAL, 1000, 0);
		PtSetArg(&args[1], Pt_ARG_TIMER_REPEAT, 500, 0);
		PtSetResources(ABW_rastersTimer, 2, args);

		/* reset the tig scaling factors */
		calcScale();

		/* set the flag to clear the tig window */
		lsrTig.clear = 1;

		/* set the new data flag in all classes */
		selections = getSelections();
		for(i = 0; i < selections->nClasses; i++) selections->classSet[i].new = 1;

		/* call the raster draw function */
		drawRasters();
		break;
	}

	return( Pt_CONTINUE );
}

int exposeWin( PtWidget_t *widget, ApInfo_t *apinfo, PtCallbackInfo_t *cbinfo )
{
	PtArg_t args[2];
	PtArg_t arg;
	SELECTIONS *selections;
	int scale;
	int i;

	/* eliminate 'unreferenced' warnings */
	widget = widget, apinfo = apinfo, cbinfo = cbinfo;

	/* turn on raster processing  */
	if(dataStarted == 1) {
		PtSetArg(&args[0], Pt_ARG_TIMER_INITIAL, 1000, 0);
		PtSetArg(&args[1], Pt_ARG_TIMER_REPEAT, 500, 0);
		PtSetResources(ABW_rastersTimer, 2, args);
	}

	/* reset the tig scaling factors */
	calcScale();

	/* set the flag to clear the tig window */
	lsrTig.clear = 1;

	/* set the new data flag in all classes */
	selections = getSelections();
	for(i = 0; i < selections->nClasses; i++) selections->classSet[i].new = 1;

	/* call the raster draw function */
	drawRasters();

	return( Pt_CONTINUE );
}

